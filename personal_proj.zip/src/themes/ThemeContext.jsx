import {createContext,useContext,useState} from 'react';

const ThemeContext=createContext();

export const useThemeMode=()=>useContext(ThemeContext);

export const ThemeModeProvider=({children})=>{
    const [mode,setMode]=useState('light');

    const toggleTheme=()=>{
        setMode((prev)=>(prev==='light'?'dark':'light'));
    };

    return (
        
        <ThemeContext.Provider value={{mode,toggleTheme}}>
{children}
        </ThemeContext.Provider>
       
    )
}