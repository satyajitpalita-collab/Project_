import { useAtom } from "jotai";
import { apiCall } from "../interceptors";
import {  getThreadFromThreadIdQueryAtom, getThreadFromThreadIdQuerySignature, agentChatAtom, modeAtom, threadIdAtom } from '../../helpers';


export const useChatHistory=()=>{
    const [chatHistory,setChatHistory]=useAtom(agentChatAtom);

      const fetchHistory = async () => {
        const response = await apiCall.get('/get-threads/')
        const data = await response?.data
    
        console.log("###",data)
        // const transformed = data.map((data) => ({
        //   id: data?.thread_id,
        //   text: data?.title,
        // }));
        setChatHistory(data);
      }
    
    return {fetchHistory}
}