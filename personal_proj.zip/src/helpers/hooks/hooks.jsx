//import { getBaseURLIntelliQ, getBaseURLMedRFE } from "../configLoader";

export const useAppUrl=()=>{
  const runtimeEnv = typeof window !== "undefined" && window.ENV;

const source = runtimeEnv ? window.ENV : process.env;
   // const APP_NAME=window.ENV.REACT_APP_NAME
 return {
   API_BASE_URL:source.REACT_APP_API_BASE_URL,
   AUTH_MODE:source.REACT_APP_AUTH_MODE,
   ENV_MODE :source.REACT_APP_ENV,
   APP_NAME :source.REACT_APP_NAME,
   PI_URL:source.REACT_APP_PMINTEL_URL
 }
}