// import { useState, useEffect, useRef } from 'react';

// export const useSSE = () => {
//   const [message, setMessage] = useState(null);
//   const eventSourceRef = useRef(null);

//   const startStreaming = (url) => {
  
//     // If an EventSource already exists, close it before starting a new one
//     if (eventSourceRef.current) {
//       eventSourceRef.current.close();
//     }
    
//     const eventSource = new EventSource(url); 
//     eventSourceRef.current = eventSource;
//       console.log({message:eventSource})
//     eventSource.onmessage = (event) => {
//       console.log({event})
//       setMessage((prev)=>prev+event.data);
//     };

//     eventSource.onerror = (error) => {
//       console.error('EventSource failed:', error);
//       eventSource.close();  
//     };
//   };
  
  
//   const closeStreaming = () => {
//     if (eventSourceRef.current) {
//       console.log('Closing SSE connection');
//       eventSourceRef.current.close();
//       eventSourceRef.current = null;  
//     }
//   };

//   // Cleanup function for when the component unmounts
//   useEffect(() => {
//     return () => {
//       closeStreaming();
//     };
//   }, []);

//   return { message, startStreaming,eventSourceRef, closeStreaming };
// };

// export default useSSE

import { useAtom } from 'jotai';
import { useState, useEffect, useRef } from 'react';
import { useDispatch } from 'react-redux';
import { abortcontrollerRefAtom, durationAtom, durationRef, prevDurationRef, prevTrackIndexRef } from '..';
import { useChatHistory } from './useChatHistory';



export const useSSE = () => {
  const [message, setMessage] = useState([]);
  const [duration,setDuration]=useAtom(durationAtom);
  const [abortcontrollerRef,setAbortcontrollerRef]=useAtom(abortcontrollerRefAtom);
   
  const {fetchHistory}=useChatHistory()
  const eventSourceRef = useRef(null);
  const controllerRef = useRef(null); // For fetch AbortController

  const processStream = async (url,body) => {
    // 1. Use AbortController for cleanup
    const controller = new AbortController();
    controllerRef.current = controller;
    setAbortcontrollerRef(controller)

    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Accept': 'text/event-stream',
          'content-type': 'application/json',
          // Include any other necessary headers (like auth tokens)
        },
        body:JSON.stringify(body),
        signal: controller.signal, // Link controller to fetch request
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      // 2. Get the stream reader
      const reader = response.body.getReader();
   
      const decoder = new TextDecoder('utf-8');
      let buffer = '';

      // 3. Read the stream continuously
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        
        // 4. Process the buffer to extract complete SSE events
        // This simple regex handles standard 'data:' and 'event:' formats
        const events = buffer.split('\n\n'); 
        buffer = events.pop(); // Keep incomplete event in buffer

        for (const eventString of events) {
          const eventArr = eventString.split("\n");
          const dataMatch = eventString.split(/data:\s*(.*)/);
          const eventMatch = eventString.split(/event:\s*(.*)/); 
          if (dataMatch) {
            const data = dataMatch[1];
            const event= eventMatch[1];
            if(event=='response.thinking'){
              if(prevDurationRef.current != 'response.thinking'){
                console.log("prev", prevDurationRef.current)
                const now = new Date(Date.now()).getTime()
                durationRef.current.push({start: now, end: 0, round: durationRef.current.length + 1})
                prevDurationRef.current = 'response.thinking';
              }
            }
            else if(event=='response.tool_result'){
              if(prevDurationRef.current == 'response.thinking'){
                const last = durationRef.current[durationRef.current.length - 1]
                if(last && !last.end){
                  const now = new Date(Date.now()).getTime()
                  last.end = now
                  prevDurationRef.current = 'response.tool_result';
                  setDuration((prev) => prev.map((ele,index) => {
                    if(index ==prevTrackIndexRef.current){
                      return [...durationRef.current]
                    }
                    return ele
                  }))
                }
               
              }
            }  
            // Update the React state with the received data
            // console.log({data,event:(data && typeof data === 'object')?JSON.parse(event):event}) 
            // console.log({data:JSON.parse(data)},typeof data )
            if(data==="[DONE]"){
              closeStreaming()
              setMessage([]) 
              return ;
            }
            setMessage((prev) => { 
                // return [ ...prev,{ data:(data && typeof data === 'object')?JSON.parse(data):data, event} ];
                return [ ...prev,{ data:(data && JSON.parse(data))?JSON.parse(data):data, event} ];
            })
           
        }
      } 
    }
  } catch (error) {
      if (error.name !== 'AbortError') {
        console.error("Fetch stream error:", error);
      }
    }
  };

  const startStreaming = (url,body) => { 
    // Close existing streams before starting a new one
    closeStreaming();
    processStream(url,body); 
  };
  
  const closeStreaming = () => {
    console.log('Closing SSE connection (using fetch workaround)');
    if (controllerRef.current) {
      controllerRef.current.abort(); // Abort the fetch request
      controllerRef.current = null;
    }
    setAbortcontrollerRef(null)
    fetchHistory()
    // Clear the message state if needed
    // setMessage(null); 
  };

 


  // Cleanup function for when the component unmounts
  useEffect(() => {
    return () => {
      closeStreaming();
    };
  }, []);

  // Note: message state will accumulate all the 'data:' payloads
  return { message, startStreaming, closeStreaming };
};

export default useSSE;