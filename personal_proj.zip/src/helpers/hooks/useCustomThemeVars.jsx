import { useTheme } from '@mui/material/styles';

/**
 * A custom hook to provide theme-dependent colors and styles.
 * @returns {object} An object containing bgColor, bgColorAssist, textColor, and boxShadow.
 */
export const useCustomThemeVars = () => {
  const theme = useTheme();

  // Determine colors and styles based on the current theme mode ('dark' or 'light')
  const bgColor = theme.palette.mode === 'dark' ? '#1A3673' : '#E3F4FD';
  const bgColorAssist = theme.palette.mode === 'dark' ? '#231E33' : '#FFF';
  const textColor = theme.palette.mode === 'dark' ? '#FFF' : '#231E33';
  const boxShadow = theme.palette.mode === 'dark' ? '' : '0px 0px 7px #898080';

  // Return the calculated variables
  return {
    theme, // You can also return the theme object itself if needed
    bgColor,
    bgColorAssist,
    textColor,
    boxShadow,
  };
};
