import { useNavigate } from "react-router-dom";
import { useAppUrl } from "./hooks";
import { config } from "../../oktaConfig";
import OktaAuth from "@okta/okta-auth-js";

export const useLogout=()=>{
    
    const {APP_NAME} = useAppUrl();
    const navigate=useNavigate()
    const oktaAuth = (config.oktaConfig && config.oktaConfig.issuer) ? new OktaAuth(config.oktaConfig):null;
  
    const logout=async()=>{
      if(APP_NAME === 'intelliq'){
         
         localStorage.removeItem("temitope");
         localStorage.removeItem("token");
         
         // navigate("/");
         
         }
      else if(APP_NAME === 'pmintel'){
         
         // await oktaAuth.signOut();
         // await oktaAuth.signOut({
         //   postLogoutRedirectUri: 'https://pgmintel.edagenaiuat.awsdns.internal.das/login/' // Optional redirect URI
         // });
         await oktaAuth?.tokenManager.clear(); 
         // window.location.href=window.location.origin + '/';
      }
    }
    return {logout};
}