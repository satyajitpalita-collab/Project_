import { useOktaAuth } from "@okta/okta-react";
import { useNavigate } from "react-router-dom";
//import { useAppUrl } from "./hooks";
 
export const useLogin=()=>{
  const { oktaAuth } = useOktaAuth() || {};
  const navigate = useNavigate();
   
    const handleLogin = async () => {
      console.log(oktaAuth);
      // if(!oktaAuth){
      //   return;
      // }
       try {
      await oktaAuth?.signInWithRedirect(); 
    } catch (err) {
      console.error('Login failed:', err); 
    }
     
   
      };
      return {handleLogin}
}