import {atom} from 'jotai';
import {atomWithQuery} from 'jotai-tanstack-query';
import { createRef } from 'react';
import { AgentThread, getThreadFromThreadId} from '../service/ApiDataService';
import { apiCall } from './interceptors';

export const dataRecordAtom=atom([]);

export const titleAtom=atom('IntellIQ');

export const chatHistoryAtom=atom([]);

export const agentChatAtom=atom([])

export const chartAtom=atom(null);

export const myPrompts=atom([]);

export const myPromptDrawer=atom([]);

export const selectedFilterAtom=atom("All Prompts");

export const copyMyPromptAtom=atom([]);

export const allDataPromptAtom=atom([]);

export const runPromptAtom=atom('');

export const modeAtom=atom('light');

export const chatLogAtom=atom([]);

export const displayPromptsAtom=atom('');

export const loadingAtom=atom(false);

export const graphAtom= atom([]);

export const sqlResponseAtom= atom('');

export const chatLoadingAtom=atom(false);

export const threadIdAtom =atom(null)

export const agentProgressToggleAtom=atom(false)

export const agentMessageQueryAtom = atomWithQuery((get) => {
    return {
      ...getAgentThreadDataQuerySignature(),
      enabled: false,

      retry: false
    };
  });
  export const getAgentThreadDataQuerySignature = () => {
     // const endpoint = `${ENV.API_URL_CHART_VIEW}/measures/all`;
      return {
        queryKey: ['measures'],
        queryFn: async () => AgentThread(),
      };
    };

export const messageIdAtom= atom(0);

export const durationAtom = atom([])
export const durationRef = createRef();
export const prevDurationRef = createRef();
export let trackIndexRef = createRef();
export let prevTrackIndexRef = createRef();
durationRef.current = []
prevDurationRef.current = null
trackIndexRef.current = 0
prevTrackIndexRef.current = -1


//abortcontroller ref

export const abortcontrollerRefAtom=atom(null)
export let progRef = createRef();

//  

  export const getThreadFromThreadIdQueryAtom = atomWithQuery((get) => { 
       const threadIdValue=get(threadIdAtom) 
    return {
      queryKey: ['getThreadFromThreadId', threadIdValue],
      queryFn: async ({ queryKey }) => { 
           // Access the threadId from the second element of the queryKey array
          const currentThreadId = queryKey[1]; 
          // Ensure we don't call the function if the ID is missing/null/undefined
          if (!currentThreadId) {
              throw new Error("Thread ID is missing in query key");
          }
          
          // Call your external fetching function with the correct ID
          return getThreadFromThreadId(currentThreadId);
        },
      enabled: threadIdValue?.length>0, 
      staleTime: 0, 
      retry: false
    };
  });