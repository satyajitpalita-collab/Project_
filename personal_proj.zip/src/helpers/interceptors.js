import axios from "axios";  

 const runtimeEnv = typeof window !== "undefined" && window.ENV;
 const source = runtimeEnv ? window.ENV : process.env;

export const apiCall = axios.create({
    baseURL:source.REACT_APP_API_BASE_URL
}) 