import { loadingAtom } from "./helpers"
import { store } from "./jotaiStore";
import axios from "axios";

let request=0
//const pendingRequest=new Set()

const setLoading=(loading)=>{
    store.set(loadingAtom,loading);
    console.log('from 9 axios',loading);
    
}
 axios.interceptors.request.use((config) => {
    console.log('line 15','dummy test');
    if (!config.headers["Disable-Loader"]) {
        request=request+1;
      setLoading(true);
    }
    
    // console.log(config.url);
    // if(pendingRequest.has(config.url)){
    //     return new Promise(()=>{});
    //     // Promise.reject({message:"XYZ"})
    // }
    // pendingRequest.add(config.url);
    return config;
  },(error)=>{
      request=Math.max(0,request-1);
      setLoading(request>0);
      return Promise.reject(error);
  });

 axios.interceptors.response.use(
    (response) => {
        request=Math.max(0,request-1);
        //setLoading(request>0);
        if(request>0){
            setLoading(true)
        }
        else{
            // setTimeout(() => {
                setLoading(false);
            // }, 3000);
           
        }
        // pendingRequest.delete(response.config.url);
        return response;
    },
    (error) => {
        request=Math.max(0,request-1);
        setLoading(request>0);
        // if(error.config?.url){
        //     pendingRequest.delete(error.config.url)
        // }
        return Promise.reject(error);
    }
  );