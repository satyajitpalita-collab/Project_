// app/store.js
import { configureStore } from '@reduxjs/toolkit';
import createThreadSlice from './slices/createThreadSlice';

export const store = configureStore({
  reducer: {
    createThread: createThreadSlice,
  },
  // Redux Toolkit automatically adds thunk middleware
});