

// features/auth/authSlice.js
import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { apiCall } from '../../helpers/interceptors';
import { API_STATUS } from '../../const/constant';

const initialState= {
    threadData: null,
    status:API_STATUS.NONE 
  }

// Define your async thunk
export const createThread = createAsyncThunk(  'createThread',   async (credentials, { rejectWithValue }) => {
    try { 
      const response = await  apiCall.get("/create-thread/")  
      return response?.data; // This will become the `payload` of the fulfilled action
    } catch (error) {
      return rejectWithValue(error.message); // This will become the `payload` of the rejected action
    }
  }
);

const createThreadSlice = createSlice({
  name: 'createThread',
  initialState: {
    threadData: null,
    messageId:null,
    status:API_STATUS.NONE 
  },
  reducers: {
   resetThreadSlice:(state)=>{ return initialState},
   storeMessageId:(state,{payload})=>{
      state.messageId=payload
   }
  },
  extraReducers: (builder) => {
    builder
      .addCase(createThread.pending, (state) => {
        state.status=API_STATUS.PENDING
      })
      .addCase(createThread.fulfilled, (state, action) => {
        state.status=API_STATUS.SUCCESS
        state.threadData = action.payload;
      })
      .addCase(createThread.rejected, (state, action) => {
        state.status=API_STATUS.ERROR
        state.error = action.payload; // The error message from rejectWithValue
      });
  },
});

export const { resetThreadSlice ,storeMessageId } = createThreadSlice.actions;
export default createThreadSlice.reducer;