import React,{useEffect, useState} from 'react';
import { ThemeModeProvider } from './themes/ThemeContext';
import AppRoutes from './routes/AppRoutes';
import { useAppUrl } from './helpers/hooks/hooks';
import { Provider } from 'react-redux'
import { store } from './redux/store';
import { useLocation } from 'react-router-dom';



function App() { 
  const {APP_NAME}=useAppUrl(); 
  const {location} =useLocation()
  // useEffect(() => {
  //   const requestInterceptor = axios.interceptors.request.use((config) => {
  //     if (!config.headers["Disable-Loader"]) {
  //       setLoading(true);
  //     }
  //     return config;
  //   });

  //   const responseInterceptor = axios.interceptors.response.use(
  //     (response) => {
  //       setLoading(false);
  //       return response;
  //     },
  //     (error) => {
  //       setLoading(false);
  //       return Promise.reject(error);
  //     }
  //   );

  //   return () => {
  //     axios.interceptors.request.eject(requestInterceptor);
  //     axios.interceptors.response.eject(responseInterceptor);
  //   };
  // }, [axios.interceptors.request, axios.interceptors.response]);

  useEffect(()=>{
    console.log({location})
  },[location])

  useEffect(()=>{
      if(APP_NAME === 'intelliq'){
        document.title='IntelliQ'
      }
      else if(APP_NAME === 'pmintel'){
      document.title= 'Program Intelligent Query'
      }
  },[])
 
 return(
   <ThemeModeProvider>
      <Provider store={store}>
      {/* <Backdrop
            sx={{
              color: '#fff',
              zIndex: (theme) => theme.zIndex.modal + 1,
              display: 'flex',
              justifyContent: 'center',
            }}
            open={loading}
          >
            <div style={{ display: 'flex', alignItems: 'center', flexDirection: 'column' }}>
              <CircularProgress />
              <div>Loading....</div>
            </div>
          </Backdrop> */}
      <AppRoutes/>
    </Provider>
      </ThemeModeProvider>
 )
}

export default App;