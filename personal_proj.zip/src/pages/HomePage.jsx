import React,{useEffect} from 'react';
import '../App.css';
import Layout from '../layout/Layout';
import {Box,Card,Typography,Button,Avatar, Paper} from "@mui/material";
import EqualizerIcon from '@mui/icons-material/Equalizer';
import FormatListBulletedIcon from '@mui/icons-material/FormatListBulleted';
import PaidIcon from '@mui/icons-material/Paid';
import { useNavigate } from 'react-router-dom';
import backgroundImage from '../images/bimage.jpg';
import { useAtom } from "jotai";
import { titleAtom } from "../helpers";
import { useAppUrl } from '../helpers/hooks/hooks';

// const styles = () => ({
//     root: { borderRadius: 20, borderColor: "#000", padding: 50 }
//   });
const HomePage = () => {
    // const [,setTitle] = useAtom(titleAtom);
    const {PI_URL}=useAppUrl();
    const apps=[{
        id:1,
        name:"Cost of Care Intelligent Query",
        subheading:"Chatbot app for EDM COC",
        icon:<PaidIcon/>,
        disabled:false,
        default:false,
        onClick: ()=>{
            // sessionStorage.setItem('Application', 'IntelliQ');
            // setTitle('Cost of Care IQ');
            navigate("/login"); 
        }
    },{
        id:2,
        name:"Financials Intelligent Query",
        subheading:"Coming Soon ...",
        icon:<EqualizerIcon/>,
        disabled:true,
        default:true,
    },{
        id:3,
        name:"Program Intelligent Query",
        subheading:"Chatbot app for Program Intelligence",
        icon:<FormatListBulletedIcon/>,
        disabled:false,
        default:false,
        onClick: ()=>{
            // sessionStorage.setItem('Application', 'MedRFP');
            // setTitle('Programs Intelligent Query');
           window.open(PI_URL,'_blank','noopener,noreferrer');
        }
    },
    ]
   const navigate = useNavigate();
   // const [selectedBtn,setSelectedBtn]=useState(1);   
    const btnId= apps.find(btn=>btn.default)?.id;

    const rows=[];
    for (let i=0;i<apps.length;i+=2){
        rows.push(apps.slice(i,i+2));
    }

    useEffect(()=>{
        localStorage.removeItem("temitope");
        localStorage.removeItem("token");
        localStorage.removeItem("initials");
           localStorage.removeItem("profileName");
           localStorage.removeItem("fullName");
           localStorage.removeItem("activeId");
        
     },[])
    // const navigateToChat=()=>{
    //     navigate("/chat");
    // }
return(
     <Layout>
       <Box sx={{height:"130vh",width:"100%",position:"relative"}}>
    <Box sx={{
        height:"77vh",
        // backgroundColor:"primary.main",
        backgroundImage:`url(${backgroundImage})`,
        backgroundSize:"cover",
        backgroundPosition:"center",
        color:"white",
        display:"flex",
        gap:8,
        // flexDirection:"column",
        alignItems:"center",
        justifyContent:"center",
        textAlign:"center",
        // position: "relative",
        //textAlign:"left",
        px:6,
        zIndex:1
    }}>
        <Box sx={{
            width:"90%",
            maxWidth:1500,
            display:"flex",
            justifyContent:"space-between",
            alignItems:"center"
        }}>
        <Box >
        <Typography variant='h3' fontWeight="bold" >Welcome To IntellIQ</Typography>
        <Typography variant='h6' mt={2}>A comprehensive solution build on Snowflake Cortex Analyst for transforming natural language inquiries into accurate SQL queries on EDM, COC, RFR and Program Intelligence applications.</Typography>
        </Box>
        {/* <Box sx={{marginLeft:"60px"}}>
        <img src={AiButton} alt="AiButton" style={{height:"250px",width:"320px",marginBottom:"50px"}}/>
        </Box> */}
        </Box>
    </Box>
    <Box sx={{
        // height:"50%",
        top:"67vh",
        width:"100%",
        // mt:-10,
        // px:2,
        display:"flex",
        justifyContent:"center",
        //marginTop:"10px",
        zIndex:1,
        position:"absolute"
    }}>
<Card sx={{width:"100%",maxWidth:1500,height:"60vh",p:4,boxShadow:6,display:"flex",flexDirection:"column",overflowY:"auto"}}>
    {/* <Typography variant="h5" fontWeight="bold" textAlign="center" > 
    Available Apps
    </Typography> */}
    <Box sx={{display:"flex",flexWrap:"wrap",gap:2,height:"80%",justifyContent:"center",mt:2}}>
    {rows.map((row,rowIndex)=>(
       <Box key={rowIndex} display="flex" gap={2}>
           {row.map(app=>(
               <Paper
               key={app.id}
               //variant="outlined"
               elevation={4}
               sx={{
                    // width:200,
                    // height:150,
                   // minHeight:"120px",
                //    flex:"1 1 calc(33.33% - 16px)",
                   height: '170px',
                   p:3,
                   borderRadius:4,
                   //borderColor:"primary.main",
                   //width:"1200px",
                   //boxShadow:"none",
                   display:"flex",
                   //flexDirection:"column",
                   alignItems:"center",
                   justifyContent:"space-between",
                   // width:"100%"
               }}
               >
       <Box sx={{display:"flex", alignItems:"center",gap:2}}>
           
       <Avatar sx={{backgroundColor:"primary.main"}}>
           {app.icon}
                       {/* <AppsIcon /> */}
                   </Avatar>
                   <Box textAlign="left">
                   <Typography  variant="h6"  
                   sx={{ 
                   fontSize: '1.3rem',
                   fontWeight:'400'
                   }} 
                   gutterBottom>
                       {app.name}
                   </Typography>
                   <Typography  variant="body1" sx={app.subheading.toLowerCase().startsWith('coming soon')?{
                       wordBreak:"true",
                       fontSize: '1.1rem',
                       display:'inline-block',
                       // background: 'linear-gradient(90deg,#2196f3 0%,#21cbf3 100%)',
                       // WebkitBackgroundClip:'text',
                       // WebkitTextFillColor:'transparent',
                       animation:'slideFade 2s ease-in-out infinite',
                       '@keyframes slideFade':{
                           '0%':{opacity:0.6,transform:'translateX(0)'},
                           '50%':{opacity:1,transform:'translateX(50px)'},
                           '100%':{opacity:0.6,transform:'translateX(0px)'},
                       },
                       }:{}}  gutterBottom>
                           {app.subheading.toLowerCase()==='coming soon ...' ? <>
                           Coming Soon
                           <Box component="span" fontWeight="bold">...</Box>
                           </>: app.subheading }
                       
                   </Typography>
                   </Box>
                   </Box>
                   <Box 
                   // sx={{marginLeft: '155px'}}
                   >
                       
                   <Button
                   key={app.id} 
                   variant="contained" 
                   size="large" 
                   //sx={{textTransform:"none",width:'130px'}} 
                   disabled={app.disabled}
                   onClick={app.onClick}
                   sx={{
                       marginLeft:app.id===btnId? '185px':'160px', 
                       textTransform:'none',
                       width:'130px'
                   }}
                   //onClick={()=>setSelectedBtn(app.id)}
                   >
                   Open App
                   </Button>
                   </Box>
               
       {/* </Box> */}
               </Paper>
       
           ))}
           </Box>
   ))}
    </Box>
</Card>
    </Box>
    </Box> 
      {/* <div>hello</div> */}
     </Layout>
)
}

export default HomePage;