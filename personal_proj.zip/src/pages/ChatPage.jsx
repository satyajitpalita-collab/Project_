import React, { useRef,useEffect } from 'react';
import '../App.css';
import Dashboard from '../../src/components/Dashboard';
import { fetchToken } from "../components/Auth";
import { useNavigate } from "react-router";
// import logo from '../../src/images/logo.png';
import user from '../../src/images/user.png';
import chatbot from '../../src/images/chatbot.png';
import Layout from '../layout/Layout';
//import { useThemeMode } from '../themes/ThemeContext';
import { ThemeProvider,CssBaseline,createTheme } from '@mui/material';
//import { getBaseURLIntelliQ,getBaseURLMedRFE } from "../configLoader";
import { modeAtom } from '../helpers';
import { useAtom } from 'jotai';
import { useAppUrl } from '../helpers/hooks/hooks';

const ChatPage = () => {

  const navigate = useNavigate();
  let token=localStorage.getItem("token");
 // const token = fetchToken();
  // const API_DEV_URL=process.env.REACT_APP_BASE_URL;
  // const API_UAT_URL=process.env.REACT_APP_UAT_URL;
  // const API_PROD_URL=process.env.REACT_APP_PROD_URL;
  //const baseUrlIntelliQ = useAppUrl();
  const {API_BASE_URL,APP_NAME} =useAppUrl();
  const runSqlQuery= APP_NAME==='intelliq' ? 'run_sql_query_with_user' : 'run_sql_query';
  const dashboardRef = useRef();
  const[mode,setMode]=useAtom(modeAtom);
  
  // const {mode}=useThemeMode();
  // if(!token) {
  //   navigate("/");
  // }

  useEffect(()=>{
    if(!token && APP_NAME === 'pmintel'){
        navigate('/');
    }
})
const handleResetClick=()=>{
    if(dashboardRef.current){
      dashboardRef.current.resetThings();
    }
  }
  const theme=createTheme({
    palette:{
      mode,
      background:{
        default: mode==='dark' ? '#07093C':'#FFF' ,
        paper: mode==='dark'? 'rgba(227, 244, 253, 0.25)':'#FFF'
      },
      text:{
        primary: mode === 'dark' ? '#FFF':'#000000'
      }
    }
  })

  return (
    
      <Layout handleResetClick={handleResetClick}
       // logo={logo}
        // themeColor="#1a3673"
        // title="IntelliQ"
        >
          <ThemeProvider theme={theme}>
      <CssBaseline/>
      <Dashboard
        // logo={logo}
        // themeColor="#1a3673"
        // title="IntelliQ"
       // theme={theme}
        ref={dashboardRef}
        newChatButtonLabel="New Chat"
        apiPath="/get_llm_response/"
        //apiPath={`${API_BASE_URL}/get_llm_response/`}
        sqlUrl={`/${runSqlQuery}/`}
        appCd="Chat_bot"
        chatbotImage={chatbot}
        userImage={user}
        chatInitialMessage="Hello there, I am your Chat Assistant. How can I help you today?"
        //suggestedPrompts={suggestedPrompts}
        // customStyles={{
        //   container: {},
        //   appBar: {},
        //   logo: {},
        //   drawer: {},
        //   newChatButton: {},
        //   main: {},
        //   chat: {
        //     inputContainer: {},
        //     input: {},
        //     chatContainer: {},
        //   },
        // }}
      />
      </ThemeProvider>
      </Layout>
    
  );
};



export default ChatPage;
