import React, { useEffect, useState } from 'react';
import { useNavigate } from "react-router";
import { fetchToken, setToken } from "../components/Auth";
//import axios from "axios";
import './Login.css';
// import '../App.css';
import {Backdrop, CardContent, CircularProgress} from '@mui/material';
import backgroundImage from '../assets/images/Login.jpg';
import {Box,Typography,TextField,Button,Card} from '@mui/material';
import logo from '../../src/images/logo.png';
import chatgpt from '../../src/assets/images/ChatGPT.png';
import aws from '../../src/assets/images/AWS.png';
import azure from '../../src/assets/images/Azure.png';
import gcp from '../../src/assets/images/GCP.png';
import { useLocation } from 'react-router-dom';
//import { getBaseURLIntelliQ } from "../configLoader";
import { useAppUrl } from '../helpers/hooks/hooks';
import { IQPIfetch, IQPIlogin } from '../service/ApiDataService';


export default function Login() {
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading,setLoading]=useState(false);
  // const API_DEV_URL=process.env.REACT_APP_BASE_URL;
  // const API_UAT_URL=process.env.REACT_APP_UAT_URL;
  // const API_PROD_URL=process.env.REACT_APP_PROD_URL;
 // const baseUrl = getBaseURLIntelliQ();
  const {API_BASE_URL} =useAppUrl();
  const location = useLocation();

  useEffect(()=>{
     localStorage.removeItem("temitope");
     localStorage.removeItem("token");
     localStorage.removeItem("initials");
        localStorage.removeItem("profileName");
        localStorage.removeItem("fullName");
        localStorage.removeItem("activeId");
     
  },[])
  

  //check to see if the fields are not empty
  const handleLogin = async (event) => {
    event.preventDefault();
    console.log("handle login triggered");
   // navigate("/disclaimer");
    try{
      if(username && password){
      setLoading(true);
      // const form = event.currentTarget;
      const formData = new FormData();
      formData.append("username",username);
      formData.append("password",password)
      const response = await IQPIlogin(formData,'/login');
      // console.log(response);
      if (response.data.access_token) {
        setToken(response.data.access_token);
        const token = fetchToken();
        localStorage.setItem('token',token);
        // const userData = await axios.get(`${API_BASE_URL}/profile`, {headers: {"Authorization": `Bearer ${token}`}});
        const userData = await IQPIfetch(token,'/profile');
        const input=userData.data.given_name;
        const parts=input.split(",");
        const name=parts[1];
        // should probably just setItem userData and access that object for needed things eg initials)
        // JSON.stringify, JSON.parse
        localStorage.setItem("initials", userData.data.given_name.charAt(0) + userData.data.surname.charAt(0));
        localStorage.setItem("profileName",name);
        localStorage.setItem("fullName",input);
        localStorage.setItem("activeId", userData.data.ha_id);
        const directRoutePath = location.state?.from?.pathname;
        if(directRoutePath){
          navigate(directRoutePath);
        }else {
         setUsername('');
         setPassword('');
         navigate("/disclaimer");

      
        }
      }
      else {
        setError("Invalid username or password");
      }
    }
    }
    catch(error) {
      if (error.response && error.response.status === 401) {
        setError('Invalid username or password');
      } else {
        setError('An error occurred. Please try again.');
      }
    }finally{
      setLoading(false);
      // setUsername('');
      // setPassword('');
    }    
  };

  return (
    <Box sx={{
      display: "grid", gridTemplateColumns:"3fr 1fr", height: '133vh', backgroundImage: `url(${backgroundImage})`,
      backgroundSize: "cover",
      backgroundPosition: "center",
      // justifyContent: "center",
      // alignItems: "center"
    }}>
      <Backdrop
        sx={{
          color: '#fff',
          zIndex: (theme) => theme.zIndex.modal + 1,
          display: 'flex',
          justifyContent: 'center',
        }}
        open={loading}
      >
        <div style={{ display: 'flex', alignItems: 'center', flexDirection: 'column' }}>
          <CircularProgress />
          <div>Logging in</div>
        </div>
      </Backdrop>
      
      <Box sx={{ display:"flex",p:4 ,color:"white",flexDirection:"column",justifyContent:'center',alignItems:"center"}}>
      <img src={logo} alt="Logo" style={{width:200,position:"absolute",top:"15%",right:"67%" }}/>
      <Box sx={{display:"flex",justifyContent:"flex-start",flexDirection:"column",width:"600px",gap:"12px"}}>
        <Typography variant="h2" >Intelligent Inquiry</Typography>
        <Typography variant="h5" >
          The Intelligent Inquiry platform is an advanced solution for managing cost of care.
          Featuring an AI driven chatbot,it supports various teams with tailored insights,optimizing
          cost and imporoving patient outcomes. 
          </Typography>
        </Box>
        <Box sx={{ display:"flex", justifyContent:'center',alignItem:"center",textAlign:"center" ,gap:14,marginTop:"30px"}}>
        <img src={chatgpt} alt="chatgpt" style={{width:50, }}/>
        <img src={gcp} alt="gcp" style={{width:50, }}/>
        <img src={azure} alt="azure" style={{width:50, }}/>
        <img src={aws} alt="aws" style={{width:50, }}/>
        
        </Box>
      </Box>
      <Box sx={{display:"flex",p:4 ,justifyContent:"center",alignItems:"center",marginRight:"30px",marginTop:"30px"}}>
        <Card sx={{width:'100%',height:"500px",borderRadius:3}}>
          <CardContent sx={{height: "100%",display: "flex",flexDirection: "column",justifyContent: "space-evenly"}}>
            
      <Typography variant="h5" sx={{textAlign:"center"}}>Login</Typography>
      <Box sx={{display:"flex",flexDirection: "column",gap:"10px"}}> 
        <Typography variant="outline1">Username</Typography>
      <TextField required  variant="outlined" 
      size="small" 
      fullWidth 
      value={username}
      onChange={(e) => setUsername(e.target.value)}
/>
      
        <Typography variant="outline1">Password</Typography>
      <TextField required variant="outlined" size="small"
      type="password"
      value={password}
      onChange={(e) => setPassword(e.target.value)}
       fullWidth/>
      </Box>
      <Box > 
      {error && <p className="error-message">{error}</p>}
    <Button variant="contained" color="primary" sx={{textTransform:"none"}}
    onClick={handleLogin}
     fullWidth >
        Login
      </Button>
      </Box>
      </CardContent>
      </Card>
      </Box>
    </Box>

    
  );
};