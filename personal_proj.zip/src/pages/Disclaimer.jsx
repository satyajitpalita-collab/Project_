// function that navigates to chatapp (like in Login.js)
// also text on top w/ ok-button onclick to that function
import React, { useState, useEffect, useRef } from 'react';
import { Box, Paper, Typography, Button, CircularProgress, Backdrop } from "@mui/material";
import { useNavigate } from "react-router"; 
import Layout from "../layout/Layout";
import {useOktaAuth} from '@okta/okta-react';
//import config from '../oktaConfig';
import axios from 'axios';
import { fetchToken, setToken } from "../components/Auth";
//import { getBaseURLIntelliQ, getBaseURLMedRFE } from '../configLoader';
import { useAppUrl } from '../helpers/hooks/hooks';
import { IQPIlogin } from '../service/ApiDataService';
import OktaAuth from '@okta/okta-auth-js';
import { config } from '../oktaConfig';
import ErrorPage from '../components/ErrorPage';
import { useLogout } from '../helpers/hooks/useLogout';

const oktaA = (config.oktaConfig && config.oktaConfig.issuer) ? new OktaAuth(config.oktaConfig):null;
export default function Disclaimer() {

    const navigate = useNavigate();
    const { authState, oktaAuth } = useOktaAuth();
    const [loading,setLoading]=useState(false); 
    //const authCode=config.sso.authCode;
  const [userInfo,setUserInfo] = useState(null);
 // const baseUrl = useAppUrl();
 const timerRef=useRef(null);
 const {API_BASE_URL,AUTH_MODE} =useAppUrl();
 const [showError,setShowError]=useState(false);
 const {logout} =useLogout() 

//  setTimeout(()=>{
//      if(!localStorage.getItem("fullName")){
//     setOpenAlert(true);
//      }
//  },3000);

  useEffect(() => {
    if(authState?.isAuthenticated && AUTH_MODE==="sso"){

      const fetchUserInfo = async()=>{
        setLoading(true);
        const userInfo = await oktaAuth.getUser();
        setUserInfo({
          name: userInfo.name,
          //email: userInfo.email,
          domainID: userInfo.domainID
        });
        localStorage.setItem("profileName", userInfo.name);
        localStorage.setItem("fullName", userInfo.name);
        console.log('user info',userInfo);
       // setLoading(false);
      }
    //   const getToken=async()=>{
    //     const accessToken = await oktaAuth.getAccessToken();
    //     console.log('token',accessToken);
    //   }
        fetchUserInfo();
      //  getToken();
      }
    },[authState?.isAuthenticated, oktaAuth,AUTH_MODE]);
   
    useEffect(() => {
        
        const timer=setTimeout(()=>{
            console.log('from line 89',userInfo?.name)
            if(!userInfo?.name){
                 navigate("/error");
                // return <Navigate to='/error' replace/>;
          // setOpenAlert(true);
         // setShowError(true);
            }
        },6000);
        return ()=>clearTimeout(timer);
    }, [userInfo]);

    const fetchTokenForEmail=async()=>{
        console.log('from disclaimer 44',userInfo?.domainID);
        if(userInfo?.domainID){
            try {
                const formData = new FormData();
                formData.append("username", userInfo?.domainID);
                formData.append("password"," ")
                const response = await IQPIlogin(formData,'/login');
                if (response.data.access_token) {
                    //const token= oktaAuth.getAccessToken();
                    setToken(response.data.access_token);
                    const token = fetchToken();
                    localStorage.setItem('token',token);
                    
                }
                else {
                    console.error("No token with domainID:");
                }
            } catch(error) {
                console.error("Error fetching token with domainId:", error);
            }
        }
    }


    const acceptDisclaimer = async() => {
        await fetchTokenForEmail();
        navigate("/chat");
        
    };

    const rejectDisclaimer = async() => {
        // await oktaA.signOut();
        // oktaA.tokenManager.clear();
        logout()
        navigate("/logout")
        // navigate("/");
    };

        // const theme = createTheme({
    //     palette: {
    //       primary: {
    //         main: themeColor,
    //       },
    //     },
    //   });
    return (
        <Layout >
           
        <Box sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            height: "132vh",
            backgroundColor: "#f4f4f4"
        }}>
            <Paper elevation={3} sx={{
                padding: "40px",
                textAlign: "center",
                maxWidth: "800px",
                width: "90%",
                minHeight: "250px"
            }}>
                <Typography variant="h3" sx={{ marginBottom: "22px", }}>
                    Disclaimer
                </Typography>
                <Typography variant="body1" sx={{ marginBottom: "30px", fontSize: "20px" }}>
                GenAI powered tools may occasionally produce incomplete or inaccurate answers. 
                For important decisions, do not rely solely on the tools responses. 
                Always validate generated responses against the trusted sources
                </Typography>
                <Box sx={{
                    display: "flex",
                    justifyContent: "center",
                    gap: "20px"
                }}>
                    <Button variant="contained" color="success"
                        sx={{ padding: "10px 20px", marginTop: "20px", fontSize: "16px" }} onClick={acceptDisclaimer}>
                        Accept
                    </Button>
                    <Button variant="contained" color="error"
                        sx={{ padding: "10px 20px", marginTop: "20px", fontSize: "16px" }} onClick={rejectDisclaimer}>
                        Reject
                    </Button>
                </Box>
            </Paper>

        </Box>
        {!userInfo && (
        <Backdrop
        sx={{
          color: '#fff',
          zIndex: (theme) => theme.zIndex.modal + 1,
          display: 'flex',
          justifyContent: 'center',
        }}
        open={true}
      >
        <div style={{ display: 'flex', alignItems: 'center', flexDirection: 'column' }}>
          <CircularProgress />
          <div>Fetching User Info...</div>
        </div>
      </Backdrop>
        )}
        </Layout>
        
    )
}