
import { Box } from "@mui/system";
import Layout from "../layout/Layout";
import { IoIosInformationCircle } from "react-icons/io";
import { Button, Link, Paper, Typography } from "@mui/material";
import { useNavigate } from "react-router-dom";
import { useLogin } from "../helpers/hooks/useLogin";
import { useAppUrl } from "../helpers/hooks/hooks";
import { useEffect } from "react";
import axios from "axios";
import useSSE from "../helpers/hooks/useSSE";

 export default function Logout(){
    const navigate=useNavigate()
    const {startStreaming,message,closeStreaming ,eventSourceRef}=useSSE("http://localhost:5000/sse")
    const {handleLogin}=useLogin()||{};
    const {APP_NAME} = useAppUrl();

    const handleLogout=()=>{ 
       
        if(APP_NAME === 'pmintel'){ 
            localStorage.removeItem("okta-token-storage");
            localStorage.removeItem("okta-cache-storage");
            handleLogin();
           
        } else{
            localStorage.clear();
             navigate("/")         
        }
    }

    const fetchSSE=()=>{
        startStreaming() 
    }
    
    const handleStop=()=>{
        console.log("close")
        closeStreaming()
        
    }

    const handleStsrtEvent=()=>{
        fetchSSE()
    }

    useEffect(()=>{
        console.log({eventSource:eventSourceRef.readyState})
    },[eventSourceRef])

    useEffect(()=>{ 
        localStorage.clear();

        return  ()=>{
            eventSourceRef.close()
        }
    },[])
    
    return(
        < >
        <Box sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            height: "132vh",
            backgroundColor: "#f4f4f4"
        }}>
            <Paper elevation={3} sx={{
                padding: "40px",
                textAlign: "left",
                maxWidth: "800px",
                width: "90%",
                minHeight: "250px"
            }}>
                <Typography variant="h4" sx={{ marginBottom: "22px", }}>
                    Logged out
                </Typography>
                <Box sx={{background:"#E9F2FF", padding:"16px"}}>
                  <Typography variant="h6" sx={{ display: "flex", alignItems: "center", marginBottom: "16px", fontWeight:"700" ,gap:"6px" }}>
                    <IoIosInformationCircle color="#1D7AFC" fontSize={"26px"} fontWeight={"700"}  />
                    You've been logged out.
                   </Typography>  
                   {/* <Typography variant="body1" sx={{ marginBottom: "16px", fontSize: "20px" }}>
                     You've been logged out of application. 
                   </Typography> */}
                   <Typography variant="body1" sx={{ marginBottom: "16px", fontSize: "20px" }}>
                    Didn't mean to log out? <Link onClick={handleLogout} sx={{":hover":{cursor:"pointer"}}}> Log in again.</Link> 
                   </Typography>
                </Box>
                {message}
            </Paper>
                <button onClick={handleStsrtEvent}>start</button>
                <button onClick={handleStop}>stop</button>
        </Box>
        
         </>
    )
 }
