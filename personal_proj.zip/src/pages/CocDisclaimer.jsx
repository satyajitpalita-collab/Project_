// function that navigates to chatapp (like in Login.js)
// also text on top w/ ok-button onclick to that function
import React from 'react';
import { Box, Paper, Typography, Button } from "@mui/material";
import { useNavigate } from "react-router";
import Layout from "../layout/Layout";


export default function CocDisclaimer() {

    const navigate = useNavigate();
   
  //const [userInfo, setUserInfo] = useState(null);

  
    //const isLogout=true;

    const acceptDisclaimer = () => {
        navigate("/chat");
    };

    const rejectDisclaimer = () => {
        navigate("/");
    };
    
    // const theme = createTheme({
    //     palette: {
    //       primary: {
    //         main: themeColor,
    //       },
    //     },
    //   });
    return (
        <Layout >
           
        <Box sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            height: "132vh",
            backgroundColor: "#f4f4f4"
        }}>
            <Paper elevation={3} sx={{
                padding: "40px",
                textAlign: "center",
                maxWidth: "800px",
                width: "90%",
                minHeight: "250px"
            }}>
                <Typography variant="h3" sx={{ marginBottom: "22px", }}>
                    Disclaimer
                </Typography>
                <Typography variant="body1" sx={{ marginBottom: "30px", fontSize: "20px" }}>
                GenAI powered tools may occasionally produce incomplete or inaccurate answers. 
                For important decisions, do not rely solely on the tools responses. 
                Always validate generated responses against the trusted sources
                </Typography>
                <Box sx={{
                    display: "flex",
                    justifyContent: "center",
                    gap: "20px"
                }}>
                    <Button variant="contained" color="success"
                        sx={{ padding: "10px 20px", marginTop: "20px", fontSize: "16px" }} onClick={acceptDisclaimer}>
                        Accept
                    </Button>
                    <Button variant="contained" color="error"
                        sx={{ padding: "10px 20px", marginTop: "20px", fontSize: "16px" }} onClick={rejectDisclaimer}>
                        Reject
                    </Button>
                </Box>
            </Paper>

        </Box>
        
         </Layout>
        
    )
}