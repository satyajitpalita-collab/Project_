import { store } from './jotaiStore';
import './axiosSetup';
import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import { BrowserRouter } from 'react-router-dom';
import { Provider } from 'jotai';
import Spinner from './Spinner';


// import { loadAppConfigs } from './configLoader';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <>
  <Provider store={store}>
  <Spinner/>
  <BrowserRouter>
  <App />
  </BrowserRouter>
  </Provider>
  </>
 
);
// loadAppConfigs().then(() => {
//   root.render(
//     <BrowserRouter>
//       <App />
//     </BrowserRouter>
//   );
// }).catch((err) => {
//   console.error('Failed to load app configuration: ', err);
// });

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();