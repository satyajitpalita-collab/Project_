import React,{useState,forwardRef,useImperativeHandle} from 'react';
import { useAtom } from 'jotai';
import {Dialog,DialogTitle,DialogContent,DialogActions,Button, IconButton,Box} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import TextField from '@mui/material/TextField';
import {myPrompts, selectedFilterAtom} from '../helpers/index.js';
import { v4 as uuidv4 } from 'uuid';
import axios from 'axios';
import { useEffect } from 'react';
//import { getBaseURLIntelliQ, getBaseURLMedRFE } from "../configLoader";
import { useAppUrl } from '../helpers/hooks/hooks.jsx';
import { IQPIpost } from '../service/ApiDataService.js';

const MyPrompts=forwardRef(({openMyPrompt,onCloseMyPrompt,openMyPromptAlert,setOpenMyPromptAlert,
  itemDraft,editModal,setEditModal,setMsg},ref)=>{

  
  // const categories = [
  //   'Membership',
  //   'Claims',
  //   'KPI',
  //   'Trend',
  //   'Dimensions',
  // ];

  // const result=[
  //   'SQL',
  //   'Table'
  // ]
  
    // const BootstrapDialog = styled(Dialog)(({ theme }) => ({
    //     '& .MuiDialogContent-root': {
    //       padding: theme.spacing(2),
    //     },
    //     '& .MuiDialogActions-root': {
    //       padding: theme.spacing(1),
    //     },
    //     '& .MuiPaper-root .MuiDialog-paper': {
    //       boxShadow: '0px 13px 19px -13px #00000053',
    //       borderRadius: '8px',
    //     },
    //     '.dialog-box': {
    //       boxShadow: 'none',
    //     },
    //   }));

      // const options = [
      //   { value: 'membership', label: 'Membership' },
      //   { value: 'dimension', label: 'Dimensions' },
      //   { value: 'claims', label: 'Claims' }
      // ]

    const [input, setInput] = useState('');
    const [myPromp,setMyPrompts]=useAtom(myPrompts);
    // const [allData,setAllData]=useAtom(allDataPromptAtom);
    // const [copyMyPrompt,setCopyMyPrompt]=useAtom(copyMyPromptAtom);
    const [selectedFilter,setSelectedFilter]=useAtom(selectedFilterAtom);
    // const [age, setAge] = useState('');
    // const [value,setValue]=useState('Category');
    const token=localStorage.getItem('token');
    // const API_DEV_URL=process.env.REACT_APP_BASE_URL;
    //const baseUrlIntelliQ = useAppUrl();
    const {API_BASE_URL} =useAppUrl();
    // const selectRef=useRef(null);
    const [category, setCategory] = useState([]);
    const [resultType,setResultType]=useState([]);
    const [editInput,setEditInput]=useState('');
    

    useImperativeHandle(ref,()=>({
      clearInput:()=>setInput(''),
    }));

    useEffect(()=>{
     if(itemDraft?.prompt){
       setEditInput(itemDraft?.prompt);
     }
    },[itemDraft?.prompt])

  // const handleCategoryChange = (event) => {
  //   const {
  //     target: { value },
  //   } = event;
  //   setCategory(
  //     // On autofill we get a stringified value.
  //     typeof value === 'string' ? value.split(',') : value,
  //   );
  // };
//console.log('from myprompt item',item)
  // const handleTypeChange = (event) => {
  //   const {
  //     target: { value },
  //   } = event;
  //   setResultType(
  //     // On autofill we get a stringified value.
  //     typeof value === 'string' ? value.split(',') : value,
  //   );
  // };

    // const handleChange = (event) => {
    // setAge(event.target.value);
    // };

    const handleSubmit=async()=>{
        console.log(input,'from line 14');
        let newMessage;
        console.log(itemDraft);
        if(editModal){
          newMessage=[{
            id:itemDraft.id,
            prompt:editInput,
            category:"None"
          }]
          
          const response=await IQPIpost(newMessage,token,'/updateDraftPrompts/');
           
        setMsg("Prompts updated successfully in My Prompts");
        }
        else{
          const id = uuidv4(); 
          newMessage=[{
              id:id,
              prompt:input,
              category:"None"
            }]
            //  if (selectedFilter!=="My Prompts"){
              
              const response= await IQPIpost(newMessage,token,'/addDraftPrompts/');
              setMsg("Prompts added successfully in My Prompts");
        }
       
          // if(response.status==200){
          setOpenMyPromptAlert(true);
          setSelectedFilter("My Prompts");
          setMyPrompts((prev)=>[newMessage[0],...prev]);
          setInput('');
          setEditInput('');
          onCloseMyPrompt();
         
          //}
          // }
          // else{
          //  // setMyPrompts((prev)=>[newMessage[0],...prev]);
          //   setCopyMyPrompt((prev)=>[newMessage[0],...prev]);
          //   setAllData((prev)=>[newMessage[0],...prev]);
          // }
       
        // if(selectedFilter==="My Prompts"){

        //}
        
       
    }

return(
<Dialog open={openMyPrompt} onClose={onCloseMyPrompt} maxWidth='md'
    // PaperProps={{
    // sx:{
    //     p:2,
        // position:"relative",
        // width:"800px !important",
       // maxWidth:"90vw",
        // minHeight:"300px",
        // display:"flex",
        // flexDirection:"column"
    // }
// }}
sx={{
"& .MuiDialog-paper":{
    width: '80%',
    height:'400px'
}
}}
>
    {/* <Box display="flex" justifyContent="space-between" alignItems="center"> */}
        <DialogTitle sx={{display: 'flex', justifyContent:'space-between',fontSize: "24px",fontStyle: "normal",fontWeight: 600}}>New Prompts
        <IconButton sx={{marginRight:'18px'}}><CloseIcon onClick={()=>{
          setInput('');
          setEditModal(false);
          setEditInput('');
          onCloseMyPrompt();
         }}/></IconButton>
        </DialogTitle>
        {/* </Box> */}
        <DialogContent sx={{'& .MuiTextField-root': { m: 1,mt:2} }}>
        
        {/* <TextField  
        fullWidth
        value={input}
        id='inputChatTxtFld'
        placeholder="Add Prompt" 
        InputProps={{
            sx:{
                '& .MuiInputBase-input': {
                    padding: '30px',
                    fontSize: '13px',
                    fontWeight: 'bold',
                    // color: themeColor,
                    // borderColor: themeColor
                  },
            }
        }}
        onChange={(e) => {
            setInput(e.target.value);
            
          }}
        /> */}
         <TextField
          id="outlined-multiline-static"
          label="Prompt Description"
          multiline
          rows={2}
          defaultValue="Type your Prompt"
          sx={{width:'95%'}}
          value={editModal ? editInput:input}
        //id='inputChatTxtFld'
        //placeholder="Add Prompt" 
        InputProps={{
            sx:{
                '& .MuiInputBase-input': {
                    padding: '16px 14px',
                    fontSize: '1.2rem',
                    fontFamily:'"OpenSans",sans-serif',
                    //fontWeight: 'bold',
                    // color: themeColor,
                    // borderColor: themeColor
                  },
                '.& .MuiInputLabel-root':{
                  height: 60,
                  lineHeight: '2.4375em !important'
                }
            }
        }}
          onChange={(e) => {
            
            if(editModal){
              setEditInput(e.target.value);
            }
            else{
              setInput(e.target.value);
            }
          }}
        />
        {/* <Box sx={{marginTop:"20px"}}>
        <FormControl sx={{ m: 1, width: 300 }}>
        <InputLabel id="demo-multiple-chip-label">Category</InputLabel>
        <Select
          labelId="demo-multiple-chip-label"
          id="demo-multiple-chip"
          single
          value={category}
          onChange={handleCategoryChange}
          input={<OutlinedInput id="select-multiple-chip" label="Chip" />}
          renderValue={(selected) => (
            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
              {selected.map((value) => (
                <Chip key={value} label={value} />
              ))}
            </Box>
          )}
         
        >
          {categories.map((name) => (
            <MenuItem
              key={name}
              value={name}
              
            >
              {name}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
      <FormControl sx={{ m: 1, width: 300 }}>
        <InputLabel id="demo-multiple-chip-label">Result Type</InputLabel>
        <Select
          labelId="demo-multiple-chip-label"
          id="demo-multiple-chip"
          multiple
          value={resultType}
          onChange={handleTypeChange}
          input={<OutlinedInput id="select-multiple-chip" label="Chip" />}
          renderValue={(selected) => (
            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
              {selected.map((value) => (
                <Chip key={value} label={value} />
              ))}
            </Box>
          )}
         
        >
          {result.map((name) => (
            <MenuItem
              key={name}
              value={name}
              
            >
              {name}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
       
      </Box> */}
        </DialogContent>
        <DialogActions>
        <Box sx={{width:"100%",mt:2, p:2,display:"flex",justifyContent:"space-between",alignItems:"center",}}>
        <Button 
            variant="outlined" 
            size="medium" 
            color="primary"
            onClick={()=>{
               // onhandleTry(item.prompt);
               setInput('');
               setEditModal(false);
               setEditInput('');
                onCloseMyPrompt();
                
            }} 
            >Cancel</Button>
            <Button 
            variant="contained" 
            size="small" 
            color="primary"
            sx={{marginRight:"20px"}}
            onClick={handleSubmit}
            >
          Save
        </Button>
        </Box>
        
        </DialogActions>
       
    </Dialog>
    )
});

export default MyPrompts;