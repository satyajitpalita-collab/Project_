import React,{useState,useEffect,useRef} from 'react';
import {Drawer,IconButton,Box,Stack,Button,Tooltip, DialogTitle, DialogContent, Dialog, DialogActions, TableContainer, Table, TableHead, TableRow, TableCell, Collapse, TableBody, Paper, TablePagination, Typography} from '@mui/material';
// import {ExpandLess,ExpandMore,Home,Info,Settings} from '@mui/icons-material';
import PromptSection from './SuggestedPrompts';
import collapseicon from '../../src/assets/CustomButtons/collapse.png';
import expandicon from '../../src/assets/CustomButtons/Uncollapse.png';
import home from '../../src/assets/CustomButtons/Home.png';
//import lightmode from '../../src/assets/CustomButtons/LightMode.png';
import lightmode from '../../src/assets/CustomButtons/NightMode.png';
import userguide from '../../src/assets/CustomButtons/UserGuide.png';
import table from '../../src/assets/CustomButtons/table.png';
import prompt from '../../src/assets/CustomButtons/Prompt.png';
import deletechat from '../../src/assets/CustomButtons/deletechat.png';
import darkmode from '../../src/assets/CustomButtons/LightMode.png';
import expanddark from '../../src/assets/CustomButtons/expanddark.png';
import collapselight from '../../src/assets/CustomButtons/collapselight.png';
import axios from "axios";
import { useNavigate } from "react-router";
import CloseIcon from '@mui/icons-material/Close';
// import { useThemeMode } from "../themes/ThemeContext";
import Divider from '@mui/material/Divider';
//import { getBaseURLIntelliQ, getBaseURLMedRFE } from "../configLoader";
//import { setThemeMode } from 'flowbite-react/dist/types/theme-store';
import { chatLogAtom, modeAtom } from '../helpers';
import { useAtom } from 'jotai';
import { useAppUrl } from '../helpers/hooks/hooks';
import { IQPIfetch } from '../service/ApiDataService';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';
const drawerWidth = 400;
const collapsedWidth=60;


const ChatDrawer=({isCollapsed,setIsCollapsed,onPromptClick,onTryFromChild,handleNewChat})=>{
    const [favorites,setFavorites]=useState([]);
    const [chatLog, setChatLog] = useAtom(chatLogAtom);
    const [tableMetadata,setTableMetadata]=useState([]);
    const [page, setPage] = useState(0);
// const API_DEV_URL=process.env.REACT_APP_BASE_URL;
    // const API_PROD_URL=process.env.REACT_APP_PROD_URL;
  //const baseUrlIntelliQ = useAppUrl();
    const token=localStorage.getItem('token');
    const navigate = useNavigate();
    const toggleDrawer=()=>setIsCollapsed(!isCollapsed);
    // const [open, setOpen] = useState(false);
    const[mode,setMode]=useAtom(modeAtom)
   // const {mode,toggleTheme}=useThemeMode();
    // const dashboardRef = useRef();
    const {API_BASE_URL,APP_NAME}=useAppUrl();
    const[open,setOpen]=useState(false);
    
    const toggleSrc= isCollapsed ? mode==='dark' ? expanddark : expandicon : mode==='dark'? collapselight : collapseicon

    const drawerStyles={
        width: isCollapsed ? collapsedWidth : drawerWidth,
        transition:'width 0.3s',
        overflowX:'hidden',
        whitespace:'nowrap',
        display:'flex',
        flexDirection:'column',
        justifyContent:'space-between',
        height:'100%'
    };

    const toggleTheme=()=>{
      setMode((prev)=>(prev==='light'?'dark':'light'));
    }
    console.log('Dummy change for build');

    useEffect(()=>{
    
        fetchFavorites();
        fetchMetadata();
        },[]);
      
        const fetchFavorites=async()=>{
          const response= await IQPIfetch(token,'/extractFavouritePrompts/');
        const favData=response.data.favouritePrompts;
        //setFavorites(favData);
        //console.log(favData);
        const data = [];
             favData.forEach(element => {
              const x = data.find((item) => item.id===element.id);
              if(!x){
                  data.push(element)
              }
          });
          setFavorites(data);
        //   console.log(favorites);
      }

      const fetchMetadata=async()=>{
        const response= await IQPIfetch(token,'/getmetadata');
        const obj={
          description: response.data.description,
          tables:response.data.tables.sort((a,b)=>b.columns.length-a.columns.length)
        }
       //console.log(response.table);
        setTableMetadata(obj);
       
      }
      
      const handleChangePage = (event, newPage) => {
        setPage(newPage);
      };

      const handleHome=()=>{
        if(APP_NAME === 'intelliq'){
        navigate("/disclaimer");
        setChatLog([]);
        }
        else{
          navigate("/");
        }
      }

      const managePrompts=()=>{
       // setOpen(true);
        navigate("/promptlibrary");
      }

      const userGuide = () => {

        const intelliqFile="IntelliQ EDM-COC User Guide Updated.pdf";
        const medRfpFile="PI EDM-COC User Guide Updated.pdf"

        const fileUrl= APP_NAME==="intelliq" ? intelliqFile : medRfpFile;

        // using Java Script method to get PDF file
          fetch(fileUrl).then((response) => {
              response.blob().then((blob) => {
              
                  // Creating new object of PDF file
                  const fileURL =
                      window.URL.createObjectURL(blob);
                      
                  // Setting various property values
                  let alink = document.createElement("a");
                  alink.href = fileURL;
                  alink.target = "_blank";
                  alink.rel = "noopener noreferrer";
                  //alink.download = "UserGuide.pdf";
                  alink.click();
              });
          });
        };
    
        // const handleResetClick=()=>{
        //     if(dashboardRef.current){
        //       dashboardRef.current.resetThings();
        //     }
        //   }
    //   const handleTryFromChild=(prompt)=>{
    //     // console.log('line 147',prompt);
    //     // setInputChatField(prompt);
    //    }

      //  const handleClose = () => {
      //   setOpen(false);
      //   fetchFavorites();
      // };

    return(
        <>
        <Drawer
        variant="permanent"
        sx={{
            backgroundColor:'background.paper',
            color:'text.primary',

            flexShrink:0,
            '& .MuiDrawer-paper': drawerStyles,
        }}
        >
<Box sx={{ flexGrow: 1, overflowY: 'auto' }} className="hide-scrollbar">
    <Box display="flex" justifyContent="flex-end" p={1} sx={{marginTop:"65px"}}>
<Button onClick={toggleDrawer} >
{/* {isCollapsed ? <img src={expandicon} alt="expand" style={{width:30, }} style={{marginLeft:"20px"}}/> */}
      <img src={toggleSrc} alt="collapse" style={{width:30,marginLeft:"20px" }} />
</Button>
    </Box>
    <PromptSection
      // sections={suggestedPrompts}
      favoritesData={favorites}
      onPromptClick={onPromptClick}
      isCollapsed={isCollapsed}    
      />
    {/* <PromptSection isCollapsed={isCollapsed}/> */}
</Box>
<Box sx={{ flexShrink: 0 }}>
  <Divider variant="middle" sx={{backgroundColor:"#CCC"}}/>
<Box p={2}>
{/* <PromptLibrary
         open={open} onClose={handleClose} onTryFromChild={onTryFromChild}
          /> */}
          
<Stack
direction={isCollapsed?"column":"row"}
spacing={3}
alignItems="center"
justifyContent="center"
>
<Tooltip title="Home" placement="top" 
componentsProps={{
  tooltip: {
    sx: {
     fontSize:'16px',
    },
  },
}}
slotProps={{popper: { modifiers: [{ name: "offset", options: { offset: [15,0] },},],},}}>
<img src={home} alt="gcp" style={{width:40, cursor: "pointer" }} onClick={handleHome}/>
</Tooltip>
<Tooltip title="Prompt Library" placement="top"
componentsProps={{
  tooltip: {
    sx: {
     fontSize:'16px',
    },
  },
}} 
slotProps={{popper: { modifiers: [{ name: "offset", options: { offset: [20,0] },},],},}}>
<img src={prompt} alt="gcp" style={{width:40, cursor: "pointer" }} onClick={managePrompts}/>
</Tooltip>
<Tooltip title="Metadata" placement="top"
componentsProps={{
  tooltip: {
    sx: {
     fontSize:'16px',
    },
  },
}}
slotProps={{popper: { modifiers: [{ name: "offset", options: { offset: [50,0] },},],},}}>
<img src={table} alt="gcp" style={{width:40, cursor: "pointer", }} onClick={()=>setOpen(true)}/>
</Tooltip>
<Tooltip title="User Guide" placement="top"
componentsProps={{
  tooltip: {
    sx: {
     fontSize:'16px',
    },
  },
}}
slotProps={{popper: { modifiers: [{ name: "offset", options: { offset: [50,0] },},],},}}>
<img src={userguide} alt="gcp" style={{width:40, cursor: "pointer", }} onClick={userGuide}/>
</Tooltip>

<IconButton onClick={toggleTheme} color="inherit">

{mode!=='dark' ? 
<Tooltip title="Dark Mode" placement="top"
componentsProps={{
  tooltip: {
    sx: {
     fontSize:'16px',
    },
  },
}} 
slotProps={{popper: { modifiers: [{ name: "offset", options: { offset: [80,0] },},],},}}>
<img src={darkmode} alt="gcp" style={{width:40, }} /></Tooltip> : 

<Tooltip title="Light Mode" placement="top"
componentsProps={{
  tooltip: {
    sx: {
     fontSize:'16px',
    },
  },
}} 
slotProps={{popper: { modifiers: [{ name: "offset", options: { offset: [80,0] },},],},}}>
<img src={lightmode} alt="gcp" style={{width:40, }}/>
</Tooltip>
}

</IconButton>
<Tooltip title="Clear Chat" placement="top"
componentsProps={{
  tooltip: {
    sx: {
     fontSize:'16px',
    },
  },
}}
slotProps={{popper: { modifiers: [{ name: "offset", options: { offset: [60,0] },},],},}}>
<img src={deletechat} alt="gcp" style={{width:40, cursor: "pointer" }} onClick={handleNewChat}/>
</Tooltip>

</Stack>
</Box>
</Box>

        </Drawer>
        <Dialog open={open} onClose={()=>setOpen(false)} maxWidth={'lg'}
    PaperProps={{
    sx:{
        p:2,
        position:"relative",
        width:"1300px !important",
       
        height:"900px",
        display:"flex",
        flexDirection:"column"
    }
}}
>
    <Box display="flex" justifyContent="space-between" alignItems="center">
        <DialogTitle sx={{fontSize: "24px",fontStyle: "normal",fontWeight: 600}}>Metadata</DialogTitle>
        <IconButton onClick={()=>setOpen(false)} sx={{marginRight:'18px'}}><CloseIcon /></IconButton>
        </Box>
        <Typography variant="subtitle1" color="text.secondary" sx={{paddingLeft:"18px"}}>
         {/* Below is the semantic model or metadata used in this application. */}
         {tableMetadata?.description}
        </Typography>
        
        <DialogContent sx={{overflow:"hidden"}}>
          {tableMetadata?.tables && (
        <TableContainer component={Paper} elevation={0} sx=
        {{border:"1px solid rgb(224 224 224)",
        height:"600px",
        '&:: -webkit-scrollbar':{
          width:'8px' ,
          
        },
        '&::-webkit-scrollbar-track': {
          background: "transparent",
          borderRadius:'4px'
        },
        '&::-webkit-scrollbar-thumb': {
          background: '#888',
          borderRadius:'4px',
          minHeight:'10px',
        },
        }} >
      <Table sx={{tableLayout:"fixed"}}>
        <TableHead>
          <TableRow >
            <TableCell sx={{width:'33%',"&:not(:last-child)":{borderRight:"1px solid rgb(224 224 224)"}}}>Table</TableCell>
            <TableCell sx={{width:'33%',"&:not(:last-child)":{borderRight:"1px solid rgb(224 224 224)"}}}>Column</TableCell>
            <TableCell sx={{width:'33%'}}>Synonyms</TableCell>
            {/* <TableCell sx={{width:'25%'}}>Cortex Search</TableCell> */}
          </TableRow>
        </TableHead>
        <TableBody>
{(tableMetadata?.tables).slice(page * 2, page * 2 + 2).map((row) =>
row.columns.map((col, index) => (
<TableRow key={row.table_name + col.name}>

                {index === 0 && (
                  <TableCell rowSpan={row.columns.length} sx={{"&:not(:last-child)":{borderRight:"1px solid rgb(224 224 224)"}}}>
                    {row.table_name}
                  </TableCell>
                )}
<TableCell sx={{whiteSpace:"normal",wordWrap:"break-word","&:not(:last-child)":{borderRight:"1px solid rgb(224 224 224)"}}}>
  {col?.cortex_search_service_name ? (<>{col.name}<span style={{fontSize:"23px",fontWeight:"900",color:"#097969",marginLeft:"5px"}}>
    *
    </span></>) : col.name}
  </TableCell>
<TableCell sx={{"&:not(:last-child)":{borderRight:"1px solid rgb(224 224 224)"}}}>{col.synonyms.join(", ")}</TableCell>
{/* <TableCell sx={{whiteSpace:"normal",wordWrap:"break-word"}}>{col?.cortex_search_service_name}</TableCell> */}
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </TableContainer>
    )}
    <Typography mt={2}><span style={{fontSize:"23px",fontWeight:"900",color:"#097969",marginRight:"5px"}}>
    *
    </span> represents that those columns have Cortex search names</Typography>
    <TablePagination
        component="div"
        count={tableMetadata?.tables ? tableMetadata?.tables.length:0}
        page={page}
        rowsPerPage={2}
        rowsPerPageOptions={[]}
        onPageChange={handleChangePage}
      />

      
        </DialogContent>

        <DialogActions>
        {/* <Box sx={{width:"100%",mt:2, p:2,display:"flex",justifyContent:"space-between",alignItems:"center",}}>
        <Button 
            variant="outlined" 
            size="medium" 
            color="primary"
            onClick={()=>setOpen(false)}
            >Cancel</Button>
            
        </Box> */}
        </DialogActions>
    </Dialog>
        </>
        
    )

};

export default ChatDrawer;