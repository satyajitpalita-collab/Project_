import { useAtom, useAtomValue } from 'jotai';
import React, { useEffect, useRef } from 'react';
import { useAppUrl } from '../../helpers/hooks/hooks'; 
import Layout from '../../layout/Layout';
import {  getThreadFromThreadIdQueryAtom, getThreadFromThreadIdQuerySignature, agentChatAtom, modeAtom, threadIdAtom } from '../../helpers';
import { createTheme, CssBaseline, ThemeProvider } from '@mui/material';
import Dashboard from '../Dashboard';
import user from '../../../src/images/user.png';
import chatbot from '../../../src/images/chatbot.png';
import AgendDashboard from './components/AgentDashboard';
import { apiCall } from '../../helpers/interceptors';
import { getThreadFromThreadId } from '../../service/ApiDataService';
import { useChatHistory } from '../../helpers/hooks/useChatHistory';
 

const IndexAgentChat = () => {
  
  const {fetchHistory}=useChatHistory()
  const {API_BASE_URL,APP_NAME} =useAppUrl();
  const runSqlQuery= APP_NAME==='intelliq' ? 'run_sql_query_with_user' : 'run_sql_query';
  const dashboardRef = useRef();
  const[mode,setMode]=useAtom(modeAtom);
  const [chatHistory,setChatHistory]=useAtom(agentChatAtom);
  
  // const {mode}=useThemeMode();
  // if(!token) {
  //   navigate("/");
  // }

    const handleResetClick=()=>{
    if(dashboardRef.current){
      dashboardRef.current.resetThings();
    }
  }
  const theme=createTheme({
    palette:{
      mode,
      background:{
        default: mode==='dark' ? '#07093C':'#FFF' ,
        paper: mode==='dark'? 'rgba(227, 244, 253, 0.25)':'#FFF'
      },
      text:{
        primary: mode === 'dark' ? '#FFF':'#000000'
      }
    }
  })

 
  useEffect(()=>{
    fetchHistory() 
  },[])

 

  return (
    
      <Layout handleResetClick={handleResetClick}
       // logo={logo}
        // themeColor="#1a3673"
        // title="IntelliQ"
        >
          <ThemeProvider theme={theme}>
      <CssBaseline/>
      <AgendDashboard
        // logo={logo}
        // themeColor="#1a3673"
        // title="IntelliQ"
       // theme={theme}
        ref={dashboardRef}
        newChatButtonLabel="New Chat"
        apiPath="/get_llm_response/"
        //apiPath={`${API_BASE_URL}/get_llm_response/`}
        sqlUrl={`/${runSqlQuery}/`}
        appCd="Chat_bot"
        chatbotImage={chatbot}
        userImage={user}
        chatInitialMessage="Hello there, I am your Chat Assistant. How can I help you today?"
        //suggestedPrompts={suggestedPrompts}
        // customStyles={{
        //   container: {},
        //   appBar: {},
        //   logo: {},
        //   drawer: {},
        //   newChatButton: {},
        //   main: {},
        //   chat: {
        //     inputContainer: {},
        //     input: {},
        //     chatContainer: {},
        //   },
        // }}
      />
      </ThemeProvider>
      </Layout>
    
  );
};



export default IndexAgentChat;
