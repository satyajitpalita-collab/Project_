import { Box, Paper, Typography } from "@mui/material";
import { abortcontrollerRefAtom, getThreadFromThreadIdQueryAtom, threadIdAtom } from "../../../helpers";
import { useAtom, useAtomValue } from "jotai";
import { useEffect, useState } from "react";
import { styled } from '@mui/material';
import Tooltip, { tooltipClasses } from '@mui/material/Tooltip';
 
export const categorizeThreads = (threads) => {
    const now = new Date();
    const todayStr = now.toISOString()?.slice(0, 10);
     
    // Calculate yesterday's date
    const yesterdayDate = new Date(now);
    yesterdayDate.setDate(now.getDate() - 1);
    // Format "yesterday" as "YYYY-MM-DD"
    const yesterdayStr = yesterdayDate?.toISOString()?.slice(0, 10);
 
    const categories = {
        Today: [],
        Yesterday: [],
        Older: []
    };
 
    threads.forEach(thread => {
        const threadDateStr = thread?.created_at?.slice(0, 10);
 
        if (threadDateStr === todayStr) {
            categories?.Today.push(thread);
        } else if (threadDateStr === yesterdayStr) {
            categories?.Yesterday.push(thread);
        } else {
            categories?.Older.push(thread);
        }
    });
 
    return categories;
};
 
 
const AgentChatList = ({ data, onPromptClick, bgColor, textColor }) => {
    const organizedData = categorizeThreads(data);
    const [threadId, setThreadId] = useAtom(threadIdAtom);
     const [abortcontrollerRef,setAbortcontrollerRef]=useAtom(abortcontrollerRefAtom);
   
    const { refetch } = useAtomValue(getThreadFromThreadIdQueryAtom)
 
 
    console.log(organizedData.Older, "organizedData")
 
    return (
        <div className="slim-scrollbar" style={{ height: "75vh", overflowY: "scroll" }}>
            {
                Object.keys(organizedData).map((categoryName) => {
                    const threadsInGroup = organizedData[categoryName];
 
                    if (threadsInGroup.length === 0) return null;
 
                    return (
                        <Box key={categoryName} sx={{ mb: 3 }}>
                            <Typography
                                variant="subtitle1"
                                sx={{ ml: 1, mt: 2, mb: 1, fontWeight: 'bold', color: (categoryName === 'Today' ||
                                     categoryName === 'Yesterday' || categoryName === 'Older')? '#636363' : textColor
                                     }}
                            >
                                {categoryName}
                            </Typography>
 
                            {
                                threadsInGroup.map((chat) => (
                                    <Box key={chat?.thread_id} sx={{ mb: 1 }}>
                                        <Tooltip
                                            title={chat?.title}
                                            placement="right"
                                            slotProps={{
                                                popper: {
                                                    sx: {
                                                        [`& .${tooltipClasses.tooltip}`]: {
                                                            maxWidth: 400,
                                                            fontSize: 14,
                                                        },
                                                    }
                                                }
                                            }}
                                        >
                                            <Box
                                                sx={{
                                                     p: threadId===chat?.thread_id?1:0.3,
                                                cursor: abortcontrollerRef && threadId!==chat?.thread_id?"not-allowed":"pointer",
                                                textAlign: "left",
                                                fontSize: threadId===chat?.thread_id?"0.98rem":'1rem',
                                                backgroundColor:threadId===chat?.thread_id?"#324c86f5": "#ffff",
                                                fontWeight: '500',
                                                fontFamily:"'Inter','Roboto',\"Helvetica Neue\",'Arial','sans-serif'",
                                                borderRadius: 2,
                                                color:threadId===chat?.thread_id?"#fff": textColor,
                                                '&:hover': {
                                                    backgroundColor: threadId!==chat?.thread_id&&'#E6EFE9', // Change background color on hover
                                                    color: threadId!==chat?.thread_id&&textColor, // Change text color on hover
                                                    fontSize: threadId===chat?.thread_id?"0.96rem":'0.87rem',
                                                    }
                                                }}
                                                className="truncate"
 
                                                onClick={() => {
                                                    if(abortcontrollerRef && threadId!==chat?.thread_id){
                                                        return ;
                                                    }
                                                    if (threadId !== chat?.thread_id) {
                                                        setThreadId(chat?.thread_id)
                                                        refetch()
                                                    }
                                                }}
                                            >
                                                <span>{chat?.title}</span>
                                            </Box>
                                        </Tooltip>
                                    </Box>
                                ))
                            }
                        </Box>
                    )
                })
            }
        </div>
 
    )
}
 
 
export default AgentChatList;
 