import { Box, Typography } from "@mui/material"
import AgentAccordianComponent from "./AgentAccordianComponent"
import { durationAtom, durationRef, prevDurationRef, prevTrackIndexRef, trackIndexRef } from "../../../helpers"
import { useEffect, useState } from "react"
import { useAtom } from "jotai"
 
export default function AgentThinkingComponent(agentThinkingProps){
    const {data,event, index}=agentThinkingProps
    const isLoading=event==="response.thinking.delta"?true:false
   const [myDurationInd] = useState(trackIndexRef.current)
    const [myPrevDurationInd] = useState(prevTrackIndexRef.current)
    const [duration, setDuration] = useAtom(durationAtom)
    const [dSnap, setdSnap] = useState(null)
    let dsec = 0
    // useEffect(() =>{
    //     const currDu = duration[prevTrackIndexRef.current][myDurationInd]
    //     if(currDu?.end){
    //         setdSnap({...currDu})
    //     }
    // }, [duration[prevTrackIndexRef.current][myDurationInd]?.end])
    // if(dSnap){
    //     dsec = Math.abs(dSnap.end - dSnap.start)/1000
    // }
    // console.log("REFCURRENT---> ",duration[prevTrackIndexRef.current][trackIndexRef.current])
     return(
        <>
          {/* <Box sx={{display: 'flex', justifyContent: 'space-between', alignItems: 'center'}}>
              <Typography sx={{fontSize:'18px',fontWeight:600}}>Round {myDurationInd + 1}</Typography>
              <Typography sx={{fontSize:'16px',fontWeight:400}}>Duration {(Math.abs(duration[myPrevDurationInd][myDurationInd]?.end -
                duration[myPrevDurationInd][myDurationInd]?.start)/1000) || 0}s</Typography>
            </Box>
          <AgentAccordianComponent title={"Thinking"} index={index} isLoading={isLoading} >
          <Typography variant="subtitle1" >{data?.text}</Typography>
            </Box> */}
          <AgentAccordianComponent title={"Thinking"} index={index} isLoading={isLoading}>
              <Typography variant="subtitle1" >{data?.text}</Typography>
          </AgentAccordianComponent>
    </>
    )
}