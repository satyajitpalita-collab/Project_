import { DataGrid } from "@mui/x-data-grid";
import AgentChartDataGrid from "./AgentChartDataGrid";

export default function AgentTableComponent(agentTableComponentProps) {
  const { data: agentDataTableObj } = agentTableComponentProps;
  const { data, resultSetMetaData } = agentDataTableObj;
  const columnsArr = resultSetMetaData?.rowType?.map((tableData) => {
    return {
      field: tableData.name,
      headerName: tableData.name,
      width: 150,
      editable: false,
    };
  });

  const rowsDataArr = data?.map((rowData,rowIndex) => {
    const namesArr = resultSetMetaData?.rowType?.map((item) => {
      return item?.name;
    });

    // Use reduce to build a single object for the row
    return rowData.reduce((obj, value, index) => {
      const key = namesArr[index];
      if (key) { 
        obj[key] = value;
      }
      return {id:rowIndex,...obj};
    }, {});
  });

  return (
    <> 
      <AgentChartDataGrid columns ={columnsArr} rows={rowsDataArr}/>
    </>
  );
}
