import { Typography } from "@mui/material";
import AgentAccordianComponent from "./AgentAccordianComponent";
import ReactJson from '@microlink/react-json-view';
import AgentSqlComponent from "./AgentSqlComponent";
import AgentTableComponent from "./AgentTableComponent";
import AgentTextComponent from "./AgentTextComponent";
import React from "react";

function AgentToolResultComponent(agentThinkingProps) {
  const { data } = agentThinkingProps;   
  return (
    <AgentAccordianComponent title={"Tool Result"}>
      <>
        {data?.content?.map((item) => {
         return  Object.keys(item?.json).map((type,index)=>{ 
            const data = item?.json[type]   
            switch(type){
              case "sql":
                return(<AgentSqlComponent data={data} keys={index}/>)
              case "result_set":
                return(<AgentTableComponent data={data} keys={index}/>)
              case "text":
                return(<AgentTextComponent data={data} keys={index} initiator="tool_result"/ >)
              case "warnings":
                return(<Typography variant="subtitle1"> 
                  <ReactJson
                          keys={index}
                          src={item?.json}
                          theme="rjv-default" // Applies the Monokai color scheme
                          name={false} // Hides the root node name by default
                          indentWidth={4} // Sets indentation (e.g., 2 spaces)
                          collapsed={false} // Keeps data expanded by default
                          
                          displayObjectSize={false} // Shows item count for arrays/objects
                          displayDataTypes={false} // Shows data types (string, int, etc.)
                          enableClipboard={true} // Allows copying data to clipboard
                          sortKeys={false} // Keeps original key order
                        />  
                </Typography>)
              case "charts":
                  return (
                <Typography variant="subtitle1"> 
                  <ReactJson
                          keys={index}
                          src={item?.json}
                          theme="rjv-default" // Applies the Monokai color scheme
                          name={false} // Hides the root node name by default
                          indentWidth={4} // Sets indentation (e.g., 2 spaces)
                          collapsed={false} // Keeps data expanded by default
                          
                          displayObjectSize={false} // Shows item count for arrays/objects
                          displayDataTypes={false} // Shows data types (string, int, etc.)
                          enableClipboard={true} // Allows copying data to clipboard
                          sortKeys={false} // Keeps original key order
                        />  
                </Typography>
              );
              
            }
          })
       
     
        })}
      </>
    </AgentAccordianComponent>
  );
}

export default React.memo(AgentToolResultComponent)