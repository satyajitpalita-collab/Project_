import { VegaEmbed } from "react-vega"
import { parseJson } from "../helper/helpers"
import AgentAccordianComponent from "./AgentAccordianComponent"

export function AgentHighChartComponent(agentChartComponentProps){
    const {data}=agentChartComponentProps 
    const spec=JSON.parse(agentChartComponentProps?.data?.chart_spec) 
    
    return (
          <AgentAccordianComponent title={"Charts"}>
            {
               (spec)&&(
                <VegaEmbed spec={spec}   />
               )
            }
        </AgentAccordianComponent>
    ) 

}