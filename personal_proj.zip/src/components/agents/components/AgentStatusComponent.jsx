import React from "react";
import { PulseLoader } from "react-spinners"; 

function AgentStatusComponent(agentStatusProps) {
    const { data } = agentStatusProps;

    return (
        <div style={{ marginBottom: "8px"  }}>
           {/* Apply the CSS class to the container of the text and loader */}
           <p className="status-message no-wrap " style={{ display: "flex",fontSize:"18px", justifyContent: "fles-start", alignItems: "center", gap: "8px" ,wordWrap:"unset"}}>
               {data?.message+" "}
               <PulseLoader color="#1a3673" size={4} /> 
           </p>
        </div>
    );
}

export default React.memo(AgentStatusComponent)