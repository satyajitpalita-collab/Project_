import React from 'react';
import { Typography, Box, List, ListItem, ListItemText } from "@mui/material";
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm'; // Plugin to support GitHub Flavored Markdown (like lists)


const H2Renderer = ({ children }) => (
  <Typography 
    variant="h6" // 'h6' is typically smaller than the default 'h2' style
    //fontWeight={"580"}
    component="h2" // Ensure it renders as an actual <h2> HTML tag for semantics
    sx={{ 
        marginTop: 2, 
        marginBottom: 1,
        fontWeight:"bold",
        // Optional: Specific font size override if 'h6' is still too big
        fontSize: '1.2rem', 
    }}
  >
    {children}
  </Typography>
);

// Custom component to render paragraphs using MUI Typography
const ParagraphRenderer = ({ children }) => (
  <Typography variant="body2" sx={{fontWeight: '500',
  fontFamily:"'Inter','Roboto',\"Helvetica Neue\",'Arial','sans-serif'",fontSize:'1rem'}} gutterBottom>
    {children}
  </Typography>
);

// Custom component to render unordered lists using MUI List
const UnorderedListRenderer = ({ children }) => (
  // Apply MUI List styling that resembles standard bullet points
  <List sx={{ listStyleType: 'disc', py: 0, pl: 2, fontWeight: '500',
  fontFamily:"'Inter','Roboto',\"Helvetica Neue\",'Arial','sans-serif'"}} disablePadding>
    {children}
  </List>
);

// Custom component to render list items using MUI ListItem/ListItemText
const ListItemRenderer = ({ children }) => (
  // Use a Box for the actual bullet point display within the list context
  <ListItem sx={{ display: 'list-item', padding: 0 }} disablePadding>
    <ListItemText sx={{ margin: 0 }}>
      {/* Ensure children inside the list item also use Typography styles if they are plain text */}
      <Typography component="span" variant="body2" sx={{fontWeight: '500',
  fontFamily:"'Inter','Roboto',\"Helvetica Neue\",'Arial','sans-serif'",fontSize:'1rem'}}>
        {children}
      </Typography>
    </ListItemText>
  </ListItem>
);


export default function AgentTextComponent({ data ,initiator='global'}) {
  const textContent = initiator==='tool_result'?data:data?.text  ;  
  return (
    <Box> 
      <ReactMarkdown
        // Pass the entire text content to react-markdown
        children={textContent}

        // Use remarkGfm plugin for better list handling if needed
        remarkPlugins={[remarkGfm]}

        // Define custom components (renderers) for specific HTML elements
        components={{
          p: ParagraphRenderer,
          ul: UnorderedListRenderer,
          li: ListItemRenderer,
          h2: H2Renderer, 
          // You can also define 'strong' or 'b' here if you want to use a specific MUI component for bold
          strong: ({children}) => <Typography component="strong" variant="body1" fontWeight="bold">{children}</Typography>,
        }}
      />
    </Box>
  );
}
