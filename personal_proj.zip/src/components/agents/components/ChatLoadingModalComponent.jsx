import { Avatar, Paper } from "@mui/material"
import { useCustomThemeVars } from "../../../helpers/hooks/useCustomThemeVars"
import { PulseLoader } from "react-spinners"
import { Box } from "@mui/system"
import ChatBotFeedback from "../../ChatBotFeedback"
import bot from '../../../../src/assets/ChatPageIcon/bot.png'; 

export function ChatLoadingModalComponent(){
     const {  bgColor,    bgColorAssist,    textColor,    boxShadow } =useCustomThemeVars ()
    return(
        <>
        <Box   sx={{ display: 'flex', justifyContent: 'flex-start'  , marginBottom: '28px', marginTop: '25px'}}>
            <Box sx={{ 
             display: 'flex',
             flexDirection:  "row" ,
             alignItems:"flex-start",
             justifyContent: "flex-start",
            }}> 
                    <Avatar src={bot} alt="Chatbot" sx={{ mr: 2, width: 40, height: 32}} />
                    <Paper elevation={2} sx={{ backgroundColor: bgColorAssist , padding: '14px', borderRadius: '15px', maxWidth: '1150px', textWrap:'wrap', boxShadow: boxShadow, color: textColor, paddingRight:  '60px', paddingTop:'30px'  ,minWidth: '1150px'}}>
                        <Box sx={{ paddingBottom: '12px'}}>
                         <PulseLoader color="#1a3673" size={6} />     
                        </Box>
                          <ChatBotFeedback 
                           disableCopy={true}
                           disableDownload={true}
                        response="response"
                        userId="user123"
                        queryId="chat.queryId"
                    />     
                    </Paper> 
            </Box>
        </Box>
       
     
        </>
    )
}