import { Typography } from "@mui/material";
import AgentAccordianComponent from "./AgentAccordianComponent";
import ReactJson from "@microlink/react-json-view";

export default function AgentToolUseComponent(agentThinkingProps) {
  const { data } = agentThinkingProps;
 
  return (
    <AgentAccordianComponent title={"Tool Use"}>
      <Typography variant="subtitle1"> 
        <ReactJson
            src={data}
            theme="rjv-default" // Applies the Monokai color scheme
            name={false} // Hides the root node name by default
            indentWidth={4} // Sets indentation (e.g., 2 spaces)
            collapsed={false} // Keeps data expanded by default
            displayObjectSize={false} // Shows item count for arrays/objects
             displayDataTypes={false} // Shows data types (string, int, etc.)
             enableClipboard={true} // Allows copying data to clipboard
           sortKeys={false} // Keeps original key order
         />   
      </Typography>
    </AgentAccordianComponent>
  );
}
