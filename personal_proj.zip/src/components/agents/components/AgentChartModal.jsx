import React, { useState,useEffect } from 'react';
import Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';
import exporting from 'highcharts/modules/exporting';
import exportData from 'highcharts/modules/export-data'; // Optional for CSV export
import offlineExporting from 'highcharts/modules/offline-exporting'; // Import offline exporting module
import variablePie from 'highcharts/modules/variable-pie'; // Import the variable-pie module
import highchartsMore from 'highcharts/highcharts-more';
import VisibilityIcon from "@mui/icons-material/Visibility";
import {useAtom} from 'jotai';  
import {
  IconButton,
  Box,
  MenuItem,
  Select,
  InputLabel,
  FormControl,
  Typography,
  ListItemText,
} from '@mui/material';
import Checkbox from '@mui/material/Checkbox';
import { chartAtom, graphAtom } from '../../../helpers';
import { getXYAxisFromSpec } from '../helper/helpers';

// Initialize exporting and additional chart modules
exporting(Highcharts);
exportData(Highcharts); // Optional, for CSV export
offlineExporting(Highcharts); // Initialize offline exporting
variablePie(Highcharts); // Initialize variable-pie module
highchartsMore(Highcharts);

const AgentChartModal = ({ visible, onClose,spec, chartType='line',chartData = [],title,id }) => {
 
  const {xAxisKey,yAxisKey}=getXYAxisFromSpec(spec,chartType)
  const [scrollToBottom, setScrollToBottom] = useState(false);
  const [key,setkey]=useState(0);
 
  // Ensure chartData is an array, otherwise fallback to an empty array
  const validData = Array.isArray(chartData) && chartData.length > 0 ? chartData : [];

  const fieldTypes = validData.length > 0 ? Object.fromEntries(
    Object.entries(validData[0]).map(([key, value]) => [key, typeof value])
  ) : {};

  // Extract keys for x-axis and y-axis options, default to empty array if no valid data
  const dataKeys = validData.length > 0 ? Object.keys(validData[0]) : []; 
  //Group data by selected xaxis and sum yaxis
  const aggregatedData = validData.reduce((acc, item) => {
    const xValue = item[xAxisKey];
    if(!acc[xValue]) {
      acc[xValue] = { [xAxisKey]: xValue };
      yAxisKey.forEach(key => {
        acc[xValue][key] = 0;
      });
    }
    yAxisKey.forEach(key => {
      const val = parseFloat(String(item[key] ?? '').replace(/[^0-9.]/g, ''));
    // const val=parseFloat(String(item[key].startsWith('$')) ? item[key].replace(/[^0-9.]/g, ''):item[key]);
      if(!isNaN(val)) {
        acc[xValue][key] += val;
      }
    });
    return acc;
  }, {});

  const groupedData = Object.values(aggregatedData); 
  // Limit data to top 10 items
  const limitedData = groupedData.length > 0 ? groupedData.slice(0, 10) : [];

  const limitedDataBar = validData;
  
  // let seriesKey = Object.keys(limitedDataBar[0]).find(key => key !== xAxisKey && key !== yAxisKey[0]);
  // let seriesKey = Object.keys(limitedDataBar[0]).filter(key => key !== xAxisKey && key !== yAxisKey[0]);
  // let seriesKeyYear=seriesKey.find(key => key.toLowerCase().includes('year') && validData[0][key].toString().length===4);
  // seriesKey=seriesKeyYear ? seriesKeyYear : seriesKey[0]?seriesKey[0]:'';
  
  // let uniqueX = [...new Set(limitedDataBar.map(ele => ele[xAxisKey]))].slice(0,10).sort(
  //     seriesKey === 'year' || seriesKey.includes('year') ? (a, b) => a - b : (a, b) => a.toString().localeCompare(b.toString())
  // );
  // let uniqueSeries = [...new Set(limitedDataBar.map(ele => ele[seriesKey]))].slice(0,10).sort(
  //     seriesKey === 'year' || seriesKey.includes('year') ? (a, b) => a - b : (a, b) => a.toString().localeCompare(b.toString())
  // );
  // Handle cases where there's no valid data
  const hasSufficientData = validData.length > 0 && xAxisKey && yAxisKey.length > 0;

  // Define chart options based on the selected chart type
  const getChartOptions = () => {
    const titleText = `Showing only top ${chartType==='bar' ? '10':limitedData.length} data points`;
   
    switch (chartType) {
      case 'arc':
        return {
          chart: { type: 'variablepie' },
          title: { text: titleText },
          credits: { enabled: false },
          series: [{
            minPointSize: 10,
            innerSize: '20%',
            zMin: 0,
            name: 'data',
            data: limitedData.map(item => ({
              name: item[xAxisKey],
              y: item[yAxisKey],
              z: item[yAxisKey] // Assuming yAxisKey value defines radius
            }))
          }]
        };

      case 'bubble':
        return {
          chart: { type: 'bubble', plotBorderWidth: 1, zoomType: 'xy' },
          title: { text: titleText },
          credits: { enabled: false },
          xAxis: { title: { text: xAxisKey } },
          yAxis: { title: { text: yAxisKey } },
          series: [{
            data: limitedData.map(item => [
              item[xAxisKey],
              item[yAxisKey],
              Math.sqrt(item[yAxisKey]) // Assuming yAxisKey value defines bubble size
            ])
          }]
        };

      case 'line':
      // case 'area':
      //case 'bar':
        return {
          chart: { type: 'line' },
          title: { text: titleText },
          credits: { enabled: false },
          xAxis: { categories: limitedData.map(item => item[xAxisKey])},
          // yAxis: {labels: obj},
          series: yAxisKey.map(key => ({
            name: key,
            data: limitedData.map(item => item[key]),
          }))
        };
      case 'rect':
        return {
          chart: { type: 'area' },
          title: { text: titleText },
          credits: { enabled: false },
          xAxis: { categories: limitedData.map(item => item[xAxisKey]) },
          series: yAxisKey.map(key => ({
            name: key,
            data: limitedData.map(item => item[key]),
          }))
        };  
      case 'bar':
        // if(chosenBarCondition==='Year'){
        //   return {
        //     chart: { type: 'bar' },
        //     title: { text: titleText },
        //     plotOptions: {
        //       bar: {
        //           borderRadius: '50%',
        //           dataLabels: {
        //               enabled: true
        //           },
        //           groupPadding: 0.1
        //       }
        //    },
        //     credits: { enabled: false },
        //     xAxis: {categories: uniqueX} ,
        //     series: uniqueSeries.map((val) => ({
        //       name: val,
        //       data: uniqueX.map(x => {
        //           const item = limitedDataBar.find(ele => ele[xAxisKey] === x && ele[seriesKey] === val);
        //           return item ? parseFloat(String(item[yAxisKey[0]] ?? '').replace(/[^0-9.]/g, '')) : null;
        //       })
        //     }))
        //   };
        // }
         
        return {
          chart: { type: chartType },
          title: { text: title },
          credits: { enabled: false },
          xAxis: { categories: chartData.map(item => item[xAxisKey]) },
          series: yAxisKey.map(key => ({
            name: key,
            data: chartData.map(item => item[key]),
          }))
        };
      
      case 'column':
        return {
          chart: { type: chartType },
          title: { text: titleText },
          credits: { enabled: false },
          xAxis: { categories: limitedData.map(item => item[xAxisKey]) },
          series: yAxisKey.map(key => ({
            name: key,
            data: limitedData.map(item => item[key]),
          }))
        };
      case 'stackedBar':
        return {
          chart: { type: 'bar' },
          title: { text: titleText },
          xAxis: { categories: limitedData.map(item => item[xAxisKey]) },
          yAxis: {
            min: 0,
            title: { text: '' },
          },
          legend: { reversed: true },
          plotOptions: {
            series: { stacking: 'normal', dataLabels: { enabled: true } }
          },
          series: yAxisKey.map(key => ({
            name: key,
            data: limitedData.map(item => item[key]),
          }))
        };

      default:
        return {
          chart: { type: 'line' },
          title: { text: titleText },
          credits: { enabled: false },
          xAxis: { categories: limitedData.map(item => item[xAxisKey]) },
          series: [{
            name: yAxisKey,
            data: limitedData.map(item => item[yAxisKey])
          }]
        };
    }
  };

  

  useEffect(() => {
    if (scrollToBottom) {
      document.querySelector('.scrollable').scrollIntoView();
      setScrollToBottom(false);
    }
  }, [scrollToBottom]);
 
    

  const options = getChartOptions();

  

  return (
    // <Modal
    //   open={visible}
    //   onClose={onClose}
    //   aria-labelledby="chart-modal-title"
    //   aria-describedby="chart-modal-description"
    // >
      <Box
        sx={{
          width:"100%"
          // position: 'absolute',
          // top: '50%',
          // left: '50%',
          // transform: 'translate(-50%, -50%)',
          // width: '50%',
          // bgcolor: 'background.paper',
          // boxShadow: 24,
          // p: 4,
          // borderRadius: '8px',
          // fontFamily:'"OpenSans",sans-serif',
          // fontSize: '1.1 rem', 
          // fontWeight: 400,
        }}
      > 
       <HighchartsReact highcharts={Highcharts} options={options}  key={key}/>
        

        {/* <Button
          onClick={()=>{
            setXAxisKey('');
            setYAxisKey([]);
            onClose()}}
          variant="contained"
          color="primary"
          sx={{ marginTop: 4 }}
          fullWidth
        >
          Close
        </Button> */}
      </Box>
    // </Modal>
  );
};

export default React.memo(AgentChartModal);