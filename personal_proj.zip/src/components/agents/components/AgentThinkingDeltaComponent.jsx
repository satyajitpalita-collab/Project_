import { useEffect } from "react"
import AgentAccordianComponent from "./AgentAccordianComponent"
import { Typography } from "@mui/material"

export default function AgentThinkingDeltaComponent(agentThinkingDeltaProps){
  const {data}=agentThinkingDeltaProps 
      return(
           <AgentAccordianComponent title={"Thinking..."} isDefaultopen={true}>
               <Typography variant="subtitle1" >{data?.text}</Typography>
           </AgentAccordianComponent>
       )
}