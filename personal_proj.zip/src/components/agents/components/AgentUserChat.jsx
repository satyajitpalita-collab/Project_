import React, { useState, useRef, useLayoutEffect, useEffect } from "react";
import { useAtom, useAtomValue } from "jotai";
//import { Alert } from 'flowbite-react';
import { FaTelegramPlane } from "react-icons/fa";
import ChatMessage from "../../ChatMessage";
import {
  Box,
  TextField,
  Paper,
  Button,
  IconButton,
  Typography,
  InputAdornment,
  useTheme,
  Modal,
  Backdrop,
  Fade,
  Snackbar,
  Alert,
} from "@mui/material";

import BarChartIcon from "@mui/icons-material/BarChart";
import { format as sqlFormatter } from "sql-formatter";
import hljs from "highlight.js/lib/core";
import sql from "highlight.js/lib/languages/sql";
import { v4 as uuidv4 } from "uuid"; // Import uuidv4
import SummaryResponseRenderer from "../../SummaryResponseRenderer";
import example from "../../../../src/assets/ChatPageIcon/Example.png";
import conversation from "../../../../src/assets/ChatPageIcon/LastConversation.png";
import favorite from "../../../../src/assets/ChatPageIcon/Favorite.png";
import LoadingSpinner from "../../LoadingSpinner";
import { fetchToken } from "../../Auth";
import { useNavigate } from "react-router";
import {
  abortcontrollerRefAtom,
  agentMessageQueryAtom,
  chatHistoryAtom,
  displayPromptsAtom,
  durationAtom,
  durationRef,
  getThreadFromThreadIdQueryAtom,
  graphAtom,
  loadingAtom,
  messageIdAtom,
  myPromptDrawer,
  myPrompts,
  prevDurationRef,
  prevTrackIndexRef,
  progRef,
  sqlResponseAtom,
  threadIdAtom,
  trackIndexRef,
} from "../../../helpers/index.js";
import axios from "axios";
import { DataGrid } from "@mui/x-data-grid";
import ContentCopyIcon from "@mui/icons-material/ContentCopy";
import VisibilityIcon from "@mui/icons-material/Visibility";
import summary from "../../../../src/assets/ChatPageIcon/summary.png";
import graph from "../../../../src/assets/ChatPageIcon/graph.png";
import carbon from "../../../../src/assets/ChatPageIcon/carbon_chat.png";
import favlight from "../../../../src/assets/ChatPageIcon/carbon_favorite.png";
import examplelight from "../../../../src/assets/ChatPageIcon/ant-design_robot-outlined.png";
//import { getBaseURLIntelliQ, getBaseURLMedRFE } from "../configLoader";
import MicIcon from "@mui/icons-material/Mic";
import { useLogout } from "../../../helpers/hooks/useLogout.jsx";
import { API_STATUS, INACTIVITY_TIME } from "../../../const/constant.js";
import { useLogin } from "../../../helpers/hooks/useLogin.jsx";
import { useAppUrl } from "../../../helpers/hooks/hooks.jsx";
import {
  IQPIfetch,
  IQPIput,
  IQPIsqlrun,
  IQPIsummary,
} from "../../../service/ApiDataService.js"; 
import { useSelector, useDispatch } from 'react-redux'

import useSSE from "../../../helpers/hooks/useSSE.jsx";
import AgentChatMessage from "./AgentChatMessage.jsx";
import { AGENT_RESPONSE_TYPE_OBJ } from "../helper/contants.js";
import { getTextFromEvent, parseJson, parseJsonfromThread } from "../helper/helpers.js";
import { createThread } from "../../../redux/slices/createThreadSlice.js";
import { useChatHistory } from "../../../helpers/hooks/useChatHistory.jsx";

hljs.registerLanguage("sql", sql);
function AgentUserChat(props) {
  // Register all Community features
  // ModuleRegistry.registerModules([AllCommunityModule]);
  // ModuleRegistry.registerModules([
  //   ClientSideRowModelModule
  // ]);
  //const theme = useTheme();
  // const isSmallScreen = useMediaQuery(theme.breakpoints.down('sm'));
  // const isMediumScreen = useMediaQuery(theme.breakpoints.between('sm', 'md'));

  const {
    chatLog,
    setChatLog,
    cortexMessages,
    setCortexMessages,
    // themeColor,
    // responseReceived, setResponseReceived,
    error,
    setError,
    // chatInitialMessage,
    isLoading,
    setIsLoading,
    successMessage,
    //setSuccessMessage,
    showInitialView,
    setShowInitialView,
    isCollapsed,
    requestId,
    // setRequestId,
    apiPath,
    sqlUrl,
    appCd,
    customStyles = {},
    chatbotImage,
    userImage,
    // handleNewChat, suggestedPrompts, showButton,
    setShowButton,
    // showExecuteButton,
    setShowExecuteButton,
    // showProivdeSummary,
    setShowProivdeSummary,
    inputField,
    setInputChatField,
    //inputChatField
  } = props;

  const endOfMessagesRef = useRef(null);
  const { logout } = useLogout() || {};
    const dispatch=useDispatch() 
  const { handleLogin } = useLogin() || {};
  const { startStreaming, message } = useSSE();
  const [duration,setDuration]=useAtom(durationAtom);
  const { isLoading: isThreadDataFromThreadIdLoading } = useAtomValue(getThreadFromThreadIdQueryAtom)
  const [loading,setLoading]=useAtom(loadingAtom)
//const {status :createThreadStatus ,threadData} = useSelector((state)=>state.createThread)
const {data:threadData,isSuccess,refetch ,status  }=useAtomValue(agentMessageQueryAtom);
const [threadId,setThreadId]=useAtom(threadIdAtom); 
  const [getMessageId,setmessageId]=useAtom(messageIdAtom);
  const [apiResponse, setApiResponse] = useState(null); // New state for storing API response
  const [input, setInput] = useState("");
  //  const layoutWidth = isSmallScreen ? '100%' : isMediumScreen ? '80%' : '70%';
  const inactivityTimeoutRef = useRef(null); // Ref for the inactivity timeout
  const [sessionActive, setSessionActive] = useState(true); // State to track session activity
  const [openPopup, setOpenPopup] = useState(false);
  const [openSummModal, setOpenSummModal] = useState(false);

  //const INACTIVITY_TIME = 10 * 1000;
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [storedResponse, setStoredResponse] = useState(""); // New state to store the response
  const [showResponse, setShowResponse] = useState(false);
  const [dataRecords, setDataRecords] = useState([]);
  const [sqlExecutionResults, setSqlExecutionResults] = useState("");
  // const [rawResponse, setRawResponse] = useState('');
  const [rawResponse, setRawResponse] = useAtom(sqlResponseAtom);
  const [sqlPrompt, setSqlPrompt] = useState("");
  const [chatHistory, setChatHistory] = useAtom(chatHistoryAtom);
  // const[myPrompt,setMyPrompt]=useAtom(myPromptDrawer);
  const [, setMyPromptDrawer] = useAtom(myPromptDrawer);
  // const [promptCategories,setPromptCategories]=useAtom(PromptCategoriesAtom);
  const [rows, setRows] = useState([]);
  const [columns, setColumns] = useState([]);
  const [promptDisplay, setPromptDisplay] = useAtom(displayPromptsAtom);
  const [isTriggerFromUserChat,setIsTriggerFromUserChat]=useState(false);

  const { API_BASE_URL, APP_NAME } = useAppUrl();
  const token = localStorage.getItem("token");
  const profileName = localStorage.getItem("profileName");

  const theme = useTheme();
  let gridKey = 0;
  const contentTableRef = useRef();
  const contentSumm = useRef();
  const [scrollToBottom, setScrollToBottom] = useState(false);
  const [question, setQuestion] = useAtom(graphAtom);
    const [abortcontrollerRef,setAbortcontrollerRef]=useAtom(abortcontrollerRefAtom);
  const {data:fetchedDataFromThreadId}=useAtomValue(getThreadFromThreadIdQueryAtom)
  const bgColor =
    theme.palette.mode === "dark" ? "rgba(26, 54, 115, 0.60)" : "#E3F4FD";
  const textColor = theme.palette.mode === "dark" ? "#FFF" : "#231E33";
  const textboxColor = theme.palette.mode === "dark" ? "#07093C" : "#FFF";
  const iconColor =
    theme.palette.mode === "dark" ? "#44B8F3" : "rgb(26, 54, 115)";
  const examplesrc = theme.palette.mode === "dark" ? examplelight : example;
  const convsrc = theme.palette.mode === "dark" ? carbon : conversation;
  const favsrc = theme.palette.mode === "dark" ? favlight : favorite;
  const chatMessageRef = useRef();
  const summaryBtnRef = useRef(null);
 
 
  const hasNumericColumn = (row) => {
    return Object.values(row).some((val) => typeof val === "number");
  };

  const headerData = [
    {
      icon: examplesrc,
      title: "Example",
    },
    {
      icon: convsrc,
      title: "Last Conversation",
    },
    {
      icon: favsrc,
      title: "New Added favorite",
    },
  ];
  //const app = window.ENV.REACT_APP_NAME;

  const navigate = useNavigate();

  const fetchPrompts = async () => {
    const response = await IQPIfetch(token, "/extractAllPrompts/");
    const promptsShuffle = response.data.prompts.sort(
      () => 0.5 - Math.random()
    );
    const displayPrompts = promptsShuffle.slice(0, 3);

    setPromptDisplay(displayPrompts);
  };

  const SpeechRecognition =
    window.SpeechRecognition || window.webkitSpeechRecognition;

  const handleMicClick = () => {
    if (!SpeechRecognition) {
      alert("Speech recognition is not supported in this browser");
      return;
    }
    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = "en-US";
    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      setInputChatField((prev) => prev + "" + transcript);
    };
    recognition.onerror = (event) => {
      console.error("Speech recognition error:", event.error);
    };
    recognition.start();
  };

  const getChatHistory = async () => {
    const response = await IQPIfetch(token, "/getUserRecentPrompts/");
    // console.log(response,'from line 103');
    const transformed = response.data.map((text, index) => ({
      id: Date.now() + index,
      text: [text.prompt],
    }));
    setChatHistory(transformed);
  };

  const handleGraphClick = (data) => {
    // setIsModalVisible(true);
    setDataRecords(data);

    const botMessage = {
      role: "assistant",
      content: data,
      sqlprompt: sqlPrompt,
      sqlquery: rawResponse,
      graph: "graph",
      disableCopy: true,
      disableDownload: true,
    };

    setChatLog((prevChatLog) => [...prevChatLog, botMessage]);
  };

  const getMyPrompts = async () => {
    const response = await IQPIfetch(token, "/getDraftPrompts/");
    // console.log(response,'from line 103');

    setMyPromptDrawer(response.data.prompts);
  };

  // Handle session end due to inactivity
  const handleSessionEnd = () => {
    setSessionActive(false);
    setChatLog([
      ...chatLog,
      { role: "assistant", content: "Session has ended due to inactivity." },
    ]);
    setOpenPopup(true); // Show the popup
  };

  // Start or reset the inactivity timer
  const resetInactivityTimeout = () => {
    if (inactivityTimeoutRef.current) {
      clearTimeout(inactivityTimeoutRef.current);
    }

    inactivityTimeoutRef.current = setTimeout(() => {
      handleSessionEnd(); // End session after 60 minutes of inactivity
    }, INACTIVITY_TIME);
  };

  const sessionEndHandleBtnClick = async () => {
    logout();
    localStorage.clear();
    handleLogin();
    navigate("/");
    setOpenPopup(false); // Close modal
  };



  async function handleSubmit(e) {
    e.preventDefault();
    const question = input; 
    setQuestion(question); 
    durationRef.current = []
    trackIndexRef.current = 0
    prevDurationRef.current = null;
    progRef.current = [];
    setDuration((prev) => [...prev, []])
    prevTrackIndexRef.current+=1

   if(threadData?.data?.thread_id || threadId){
      const bodyObj={
        "thread_id": threadData?.data?.thread_id ||threadId,
        "parent_message_id":getMessageId,
        "prompt": question.toString()
      }
      
       startStreaming( `${API_BASE_URL}/query-agent/`,bodyObj );
    }else{
      // dispatch(createThread())
     // dispatch(createThread())
     refetch();
     setIsTriggerFromUserChat(true);
    }
    //alert('input : '+question)

    // Prevent empty messages

    // apiCall.get(`/query-agent?prompt=${question}`)

    if (!question.trim()) return;
    if (!appCd.trim() || !requestId.trim()) {
      setError("Please provide valid app_cd and request_id.");
      return;
    }
    const token = fetchToken();

    const newMessage = {
      role: "user",
      content: question,
      isSQLResponse: false,
    };

    const cortexMessage = {
      role: "user",
      content: [{ type: "text", text: question }],
    };

    cortexMessages.push(cortexMessage);
    const text = cortexMessage.content.map((x) => x.text);

    if (text) {
      const newMessage = {
        id: Date.now(),
        text,
      };
      setChatHistory((prev) => [newMessage, ...prev]);
    }
    // setCortexMessages(newCortexMessages);

    const newChatLog = [...chatLog, newMessage]; // Add user's message to chat log
    setChatLog(newChatLog);
    setInput(""); // Clear the input field
    setInputChatField("");
    setIsLoading(true); // Set loading state
    setError(""); // Clear any previous error
    setShowInitialView(false);
    setShowResponse(false);
    setShowButton(false);
    setShowExecuteButton(false);
    setShowProivdeSummary(false);
 
  }

  const handleInputFocusOrChange = () => {
    setShowInitialView(false);
    resetInactivityTimeout();
  };

  const formatAllDataForClipboard = (mainTitle, grids) => {
    const formattedGrids = grids
      .map((grid) => {
        const { columnData, referralList } = grid;

        // Calculate the maximum width for each column
        const colWidths = columnData.map((col) => {
          return Math.max(
            col.headerName.length,
            ...referralList.map((row) => (row[col.field] || "").length)
          );
        });

        // Function to pad strings manually
        const padString = (str, length) => {
          return str + " ".repeat(length - str.length);
        };

        // Format the headings with proper alignment
        const headings = columnData
          .map((col, index) => padString(col.headerName, colWidths[index]))
          .join("\t");

        // Format each row with proper alignment
        const rows = referralList
          .map((row) => {
            return columnData
              .map((col, index) =>
                padString(row[col.field] || "", colWidths[index])
              )
              .join("\t");
          })
          .join("\n");

        return `${headings}\n${rows}`;
      })
      .join("\n\n");

    return `${mainTitle}\n\n${formattedGrids}`;
  };

  const copyToClipboard = (column, row) => {
    const mainTitle = "Table Data";
    const grids = [
      {
        columnData: column,
        referralList: row,
      },
    ];
    const formattedData = formatAllDataForClipboard(mainTitle, grids);
    navigator.clipboard.writeText(formattedData);
  };

  function toggle(key) {
    const el = document.getElementById(`myGrid-${key}`);
    if (el) {
      el.style.display = el.style.display === "none" ? "block" : "none";
    }
  }

  const executeSQLHandleButtonClick = async (rawVariable) => {
    try {
      setIsLoading(true); // Set loading state
      setShowExecuteButton(false);
      setShowButton(false);
      const sanitizeQuery = (query) => {
        // Example: Remove line breaks, extra spaces, and other unnecessary parts
        let cleanedQuery = query
          .replace(/\\n/g, " ")
          .replace(/\s+/g, " ")
          .replace(/--.*?;/g, "")
          .trim();
        return cleanedQuery;
      };

      const executeQuery = rawVariable;
      //const graphResponse = await fetch('/mockGraph.json');
      const queryParams = {
        app_cd: appCd,
        request_id: requestId,
        exec_query: executeQuery,
      };
      // const sqlQueryUrl = `${sqlUrl}?app_cd=${appCd}&request_id=${requestId}&exec_query=${encodedResponse}`;
      const token = fetchToken();
      const response = await IQPIsqlrun(token, sqlUrl, queryParams);

      // Check if response is okay
      if (response.status !== 200) {
        let errorMessage = "";

        // Handle different status codes
        if (response.status === 404) {
          errorMessage = "404 - Not Found";
        } else if (response.status === 500) {
          //errorMessage = '500 - Internal Server Error';
          const response_data = response.data;
          errorMessage = response_data.detail;
        } else {
          errorMessage = `${response.status} - ${response.statusText}`;
        }

        // Create an error message object
        const errorMessageContent = {
          role: "assistant",
          type: "error",
          content: (
            <div
              style={{
                display: "flex",
                alignItems: "center",
                flexDirection: "column",
              }}
            >
              <p
                style={{
                  fontFamily: '"OpenSans",sans-serif',
                  fontSize: "1.1 rem",
                  fontWeight: 400,
                  textAlign: "justify",
                }}
              >
                {errorMessage}
              </p>
            </div>
          ),
        };

        setChatLog((prevChatLog) => [...prevChatLog, errorMessageContent]); // Update chat log with assistant's error message
        //throw new Error(errorMessage); // Re-throw the error for logging purposes
      } else {
        //const response_data = await graphResponse.json();
        const response_data = response.data;
        const data = response_data.results;
        //console.log(data);
        setSqlExecutionResults(data);
        //setDataRecords(data);

        // Function to convert object to string
        const convertToString = (input) => {
          if (typeof input === "string") {
            return input;
          } else if (Array.isArray(input)) {
            return input.map(convertToString).join(", ");
          } else if (typeof input === "object" && input !== null) {
            return Object.entries(input)
              .map(([key, value]) => `${key}: ${convertToString(value)}`)
              .join(", ");
          }
          return String(input);
        };

        // Handle the response data similarly to handleSubmit
        let modelReply = "Not able to Extract Results at this time ."; // Default message

        const rowData = data;

        // Define the formatNumber function
     const formatNumber = (number) => {
          return new Intl.NumberFormat("en-US", {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
          }).format(number);
        };
        const formatRow = (row) => {
          const formattedRow = {};
          // debugger;
          for (const key in row) {
            if (
              typeof row[key] === "number" &&
              (key.toLowerCase().includes("amt") ||
                key.toLowerCase().includes("amount"))
            ) {
              formattedRow[key] = `$${formatNumber(row[key])}`;
            } else if (
              typeof row[key] === "number" &&
              (key.toLowerCase().includes("pct") ||
                key.toLowerCase().includes("percentage"))
            ) {
              formattedRow[key] = `${formatNumber(row[key])}%`;
            }
            //else if ((typeof row[key] === 'number') && !(key.toLowerCase().includes('mnth')) ) {
            else if (
              typeof row[key] === "number" &&
              !key.toLowerCase().includes("mnth") &&
              !key.toLowerCase().includes("year")
            ) {
              formattedRow[key] = formatNumber(row[key]);
            } else {
              formattedRow[key] = row[key];
            }
          }
          return formattedRow;
        };

        //const colDefs = convertToDictList(response_data.columns, rowData);

        const gridRows = rowData.map((row, index) => {
          //const id = uuidv4(); // or use index if you prefer
          //console.log(`Row ID: ${id}`);
          const formattedRow = formatRow(row);
          return formattedRow;
        });

        let globalRows = [];
        let globalColumns = [];

        // Column Definitions: Defines the columns to be displayed.

        if (data && data.length > 0) {
          // Check if the response is a JSON array of objects
          if (
            Array.isArray(data) &&
            data.every((item) => typeof item === "object") &&
            data.length > 0
          ) {
            const dynamicColumns = Object.keys(data[0]).map((key) => ({
              field: key,
              headerName: key,
              width: 180,
              flex: 1,
            }));
            setColumns(dynamicColumns);
            globalColumns = dynamicColumns;
            const processedRows = data.map((row, index) => ({
              id: index + 1,
              ...row,
            }));

            setRows(processedRows);
            globalRows = processedRows;

            const columnCount = Object.keys(data[0]).length;
            const rowCount = data.length;

            gridKey = uuidv4();

            // ++myKey;
            // Convert to a table-like format with borders for display
            modelReply = (
              // setShowGrid(true)

              <>
                <Box
                  sx={{ width: "1065px" }}
                  ref={contentTableRef}
                  key={gridKey}
                >
                  <Typography
                    style={{
                      color: `${textColor} !important`,
                      fontSize: "16px",
                      fontStyle: "normal",
                      fontWeight: 500,
                      lineHeight: "20px",
                      paddingBottom: "18px",
                    }}
                  >
                    Here is the Data Table.
                  </Typography>
                  <Box
                    sx={{
                      display: "flex",
                      height: "55px",
                      borderRadius: "10px 10px 0px 0px",
                      boxShadow: 1,
                      flexDirection: "row",
                      justifyContent: "space-between",
                      alignItems: "center",
                      bgcolor: "#666",
                      px: 2,
                      py: 1,
                    }}
                  >
                    <Typography color="white" fontSize={14} fontWeight={500}>
                      Table
                    </Typography>
                    <Box>
                      <IconButton
                        size="small"
                        sx={{ color: "white", mr: 2 }}
                        onClick={() => toggle(gridKey)}
                      >
                        <VisibilityIcon fontSize="small" />
                      </IconButton>
                      <IconButton
                        size="small"
                        sx={{ color: "white" }}
                        onClick={() =>
                          copyToClipboard(dynamicColumns, processedRows)
                        }
                      >
                        <ContentCopyIcon fontSize="small" />
                      </IconButton>
                    </Box>
                  </Box>
                  <Box sx={{ display: "flex", flexDirection: "column" }}>
                    {/* {isOpen && */}
                    <Box sx={{ height: "auto", overflow: "hidden" }}>
                      {processedRows.length > 0 && dynamicColumns.length > 0 ? (
                        <div id={`myGrid-${gridKey}`}>
                          <DataGrid
                            key={processedRows.id}
                            rows={processedRows}
                            columns={dynamicColumns}
                            disableRowSelectionOnClick
                            // pageSize={10}
                            pagination
                            initialState={{
                              pagination: {
                                paginationModel: {
                                  pageSize: 10,
                                },
                              },
                            }}
                            pageSizeOptions={[10, 15, 20]}
                            // paginationModel={paginationModel}
                            // onPaginationModelChange={setPaginationModel}
                            // pageSizeOptions={[5, 10, 25, 50]}

                            sx={{
                              "& .MuiDataGrid-columnHeader": {
                                backgroundColor: "#EEE",
                                color: "#231E33",
                                fontWeight: "bold",
                              },
                              "& .MuiDataGrid-columnHeaders": {
                                borderBottom: "1px solid #ccc",
                              },
                              "& .MuiDataGrid-cell": {
                                borderRight: "1px solid #ccc",
                              },
                            }}
                          />
                        </div>
                      ) : (
                        <Typography>Loading Data</Typography>
                      )}
                    </Box>
                    {/* }   */}
                  </Box>
                  {(APP_NAME !== "intelliq" ||
                    (rowCount > 1 && columnCount > 1)) && (
                    <Box>
                      <Typography
                        style={{
                          color: `${textColor} !important`,
                          fontSize: "16px",
                          fontStyle: "normal",
                          fontWeight: 500,
                          lineHeight: "20px",
                          paddingTop: "18px",
                        }}
                      >
                        Other View Options:
                      </Typography>
                      <Box
                        sx={{
                          display: "flex",
                          justifyContent: "left",
                          gap: "20px",
                          marginTop: "30px",
                        }}
                      >
                        {/* <Button sx={{textTransform:'none'}} variant="contained" startIcon={<img src={data} alt="data" style={{width:24,height:24 }} />} onClick={executeSQLHandleButtonClick}>
                      View Data
                      </Button> */}
                        {hasNumericColumn(data[0]) &&
                          rowCount > 1 &&
                          columnCount > 1 && (
                            <Button
                              className="summary-btn"
                              sx={{
                                textTransform: "none",
                                backgroundColor: "#2861BB",
                                color: "#FFF",
                              }}
                              variant="contained"
                              startIcon={
                                <img
                                  src={graph}
                                  alt="data"
                                  style={{ width: 24, height: 24 }}
                                />
                              }
                              onClick={() => handleGraphClick(data)}
                            >
                              View Graph
                            </Button>
                          )}
                        <Button
                          ref={summaryBtnRef}
                          className="summary-btn"
                          sx={{
                            textTransform: "none",
                            backgroundColor: "#2861BB",
                            color: "#FFF",
                          }}
                          variant="contained"
                          startIcon={
                            <img
                              src={summary}
                              alt="data"
                              style={{ width: 24, height: 24 }}
                            />
                          }
                          onClick={() => generateSummaryHandleButtonClick(data)}
                        >
                          View Summary
                        </Button>
                      </Box>
                    </Box>
                  )}
                </Box>
              </>
            );
            setScrollToBottom(true);
            // setShowProivdeSummary(true);
          } else if (typeof data === "string") {
            // If it's a string, display it as text and store it in the state
            modelReply = data;
            //setStoredResponse(data);
            setIsLoading(true);
          } else {
            // Otherwise, convert to string
            modelReply = convertToString(data);
          }
        } else {
          modelReply = "Query produced no results";
          setShowProivdeSummary(false);
        }

        const botMessage = {
          role: "assistant",
          content: modelReply,
          sqlprompt: sqlPrompt,
          sqlquery: rawResponse,
          data: "data",
          rows: globalRows,
          columns: globalColumns,
        };

        setChatLog((prevChatLog) => [...prevChatLog, botMessage]); // Update chat log with assistant's message
      }
    } catch (err) {
      // Handle network errors or other unexpected issues
      const fallbackErrorMessage =
        "We could not fetch the results right now. Please try again after sometime";
      const errorMessageContent = {
        role: "assistant",
        type: "error",
        content: (
          <div
            style={{
              display: "flex",
              alignItems: "center",
              flexDirection: "column",
            }}
          >
            <p
              style={{
                fontFamily: '"OpenSans",sans-serif',
                fontSize: "1.1 rem",
                fontWeight: 400,
                textAlign: "center",
              }}
            >
              {fallbackErrorMessage}
            </p>
          </div>
        ),
      };

      setChatLog((prevChatLog) => [...prevChatLog, errorMessageContent]); // Update chat log with assistant's error message
      //console.error('Error:', err); // Log the error for debugging

      // setShowProivdeSummary(false);
    } finally {
      setIsLoading(false); // Set loading state to false
      setShowExecuteButton(false);
      setShowButton(false);
      //setShowProivdeSummary(false);
    }
  };

  const generateSummaryHandleButtonClick = async (data) => {
    try {
      if (data.length > 100 && APP_NAME !== "intelliq") {
        setOpenSummModal(true);
      } else {
        setIsLoading(true); // Set loading state 
        //setShowProivdeSummary(false);
        // Function to convert object to string
        const convertToString1 = (input) => {
          if (typeof input === "string") {
            return input;
          } else if (Array.isArray(input)) {
            return input.map(convertToString1).join(", ");
          } else if (typeof input === "object" && input !== null) {
            return Object.entries(input)
              .map(([key, value]) => `${key}: ${convertToString1(value)}`)
              .join(", ");
          }
          return String(input);
        };
        const dataRecords_str = convertToString1(data);
        const payload = {
          prompt_message: dataRecords_str,
          request_id: "1234",
        };
        const response = await IQPIsummary("/generateSummary/", payload);

        // Check if response is okay
        if (!response.status === 200) {
          let errorMessage = "";

          // Handle different status codes
          if (response.status === 404) {
            errorMessage = "404 - Not Found";
          } else if (response.status === 500) {
            errorMessage = "500 - Internal Server Error";
          } else {
            errorMessage = `${response.status} - ${response.statusText}`;
          }

          // Create an error message object
          const errorMessageContent = {
            role: "assistant",
            type: "error",
            content: (
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  flexDirection: "column",
                }}
              >
                <p
                  style={{
                    fontFamily: '"OpenSans",sans-serif',
                    fontSize: "1.1 rem",
                    fontWeight: 400,
                    textAlign: "center",
                  }}
                >
                  {errorMessage}
                </p>
              </div>
            ),
          };

          setChatLog((prevChatLog) => [...prevChatLog, errorMessageContent]); // Update chat log with assistant's error message
          throw new Error(errorMessage); // Re-throw the error for logging purposes
        }

        const resSummary = response.data;
        const summary_data = resSummary.summary;
        //setSummType(resSummary.type);
        let modelReply = "No valid reply found."; // Default message

        if (summary_data) {
          // Check if the response is a JSON array of objects
          if (typeof summary_data === "string") {
            // Convert to a table-like format with borders for display
            modelReply = (
              <div style={{ display: "flex", alignItems: "start" }}>
                {summary_data && (
                  <div
                    style={{
                      textWrap: "wrap",
                      wordBreak: "break-word",
                      fontFamily: '"OpenSans",sans-serif',
                      fontSize: "1.1 rem",
                      fontWeight: 400,
                    }}
                    key={uuidv4}
                    ref={contentSumm}
                  >
                    {/* <h3>Summary :</h3> */}
                    {/* <pre > */}
                    {/* {summary_data} */}
                    <SummaryResponseRenderer response={summary_data} />
                    {/* </pre> */}
                  </div>
                )}
              </div>
            );
          } else {
            // Otherwise, convert to string
            modelReply = convertToString1(summary_data);
          }
        }

        const botMessage = {
          role: "assistant",
          content: modelReply,
          sqlprompt: sqlPrompt,
          sqlquery: rawResponse,
          summary: "summary",
          summaryData: summary_data,
        };

        setChatLog((prevChatLog) => [...prevChatLog, botMessage]);
      } // Update chat log with assistant's message
    } catch (err) {
      // Handle network errors or other unexpected issues
      const fallbackErrorMessage =
        "We could not fetch the summary right now. Please try again after sometime";
      const errorMessageContent = {
        role: "assistant",
        type: "error",
        content: (
          <div
            style={{
              display: "flex",
              alignItems: "center",
              flexDirection: "column",
            }}
          >
            <p
              style={{
                fontFamily: '"OpenSans",sans-serif',
                fontSize: "1.1 rem",
                fontWeight: 400,
                textAlign: "center",
              }}
            >
              {fallbackErrorMessage}
            </p>
          </div>
        ),
      };

      setChatLog((prevChatLog) => [...prevChatLog, errorMessageContent]); // Update chat log with assistant's error message
      console.error("Error:", err); // Log the error for debugging
      console.error("Stack trace:", error.stack);
    } finally {
        setIsLoading(false); // Set loading state to false
    }
  };

  useEffect(() => {
    if (scrollToBottom) {
      setTimeout(() => {
        document.querySelector(".scrollable").scrollIntoView();
        setScrollToBottom(false);
      });
    }
  }, [scrollToBottom]);


 useEffect(()=>{
    setInput(inputField)
  },[inputField]);

  useEffect(()=>{
    // setmessageId()
    const formattedFetchedData=fetchedDataFromThreadId?.data?.map((data)=>{ 
       
        const userObj={
        "role": "user",
        "content": data?.message,
        "isSQLResponse": false
        }
        const assistantObj={
      "data":parseJsonfromThread(data?.response)  ,
      "event": "metadata",
      "isSQLResponse": true,
      "role": "assistant",
      "type": "sql", 
  }
  const resultArr=[
          {
            ...userObj
          },{
            ...assistantObj
          }
        ]
        return  resultArr
      }).flat()  
        if(formattedFetchedData?.length>0){
          if(abortcontrollerRef){
            abortcontrollerRef.abort()
          } 
         setmessageId(formattedFetchedData[formattedFetchedData?.length-1]?.data[0]?.data?.metadata?.message_id)
         setChatLog(formattedFetchedData)
       }
    // setInput(inputField)
  },[fetchedDataFromThreadId])

  useLayoutEffect(() => {
    if (endOfMessagesRef.current) {
      endOfMessagesRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [chatLog]);

  useEffect(() => {
    if (isLoading) {
      document.querySelectorAll(".summary-btn").forEach((ele) => {
        ele.disabled = true;
        ele.style.backgroundColor = "rgba(0, 0, 0, 0.26)";
        ele.style.cursor = "default";
      });
    } else {
      document.querySelectorAll(".summary-btn").forEach((ele) => {
        ele.disabled = false;
        ele.style.backgroundColor = "#2861BB";
        ele.style.cursor = "pointer";
      });
    }
  }, [isLoading]);

  useEffect(() => { 
    fetchPrompts(); 
     getChatHistory();
    getMyPrompts();
  }, []);

 

   useEffect(() => { 
    // console.log('line no 1440',isSuccess,threadData?.data?.thread_id);
 
       if(isSuccess && isTriggerFromUserChat){ 
         setThreadId(threadData.data?.thread_id)
        
            const bodyObj={
                "thread_id": threadData.data?threadData.data?.thread_id:"54454932",
                "parent_message_id":0,
                "prompt": question.toString()
              }
         startStreaming( `${API_BASE_URL}/query-agent/`,bodyObj );
         setIsTriggerFromUserChat(false);
       } 
   }, [isSuccess ,isTriggerFromUserChat]);
 
useEffect(() => { 
  if (!message || message.length === 0) {
    setIsLoading(false);
  const  updatedMsg=chatLog.map((chatItem)=>{ 
    if(chatItem?.role==="assistant"){
      const filteredChatItem =chatItem.data.filter((item,index)=> !["response.status" ,"response.tool_result.status"].includes(item.event))
     const fullNewMessageObject = { 
        isSQLResponse: true,
        role: "assistant",
        type: "sql",
        data: filteredChatItem,
        text: "",
      };
      return fullNewMessageObject
    }else{
      return chatItem
    }
  }) 
  // filtering out the events with loaders at the end of the events
  setChatLog(updatedMsg)
    return;
  }  
   
  // Set isLoading to false when the "done" event is received.
  // Make sure this logic is correct for your application.
  if (message[message?.length-1]?.event === AGENT_RESPONSE_TYPE_OBJ.response ) {
    setIsLoading(false);
   
    // const updatedMsg=chatsToRender.filter((item,index)=> !["response.status" ,"response.tool_result.status"].includes(item.event))
  }

  // Use the functional updater for setChatLog to ensure you're working with the latest state.
  setChatLog((prevChatLog) => {
    const newMessageObject = message[0];
    const messageToUpdateId = newMessageObject?.data?.metadata?.message_id;
     if(messageToUpdateId){
       setmessageId(messageToUpdateId);
     }
    if (!messageToUpdateId) {
      // If there's no valid message ID, or if it's a new message,
      // append it to the chat log.
      const fullNewMessageObject = {
        ...newMessageObject,
        isSQLResponse: true,
        role: "assistant",
        type: "sql",
        data: message,
        text: getTextFromEvent(newMessageObject, prevChatLog),
      };
      return [...prevChatLog, fullNewMessageObject];
    }

    // Use findIndex to locate the message to be updated.
    const existingMessageIndex = prevChatLog.findIndex(
      (chat) => chat?.data?.[0]?.data?.metadata?.message_id === messageToUpdateId
    );

    // If an existing message is found, update its content.
    if (existingMessageIndex !== -1) {
      // Create a copy of the chat log to maintain immutability.
      const updatedChatLog = [...prevChatLog];
      
      // Update the existing message at the found index.
      // Assuming 'data' is what needs to be updated.
      updatedChatLog[existingMessageIndex] = {
        ...updatedChatLog[existingMessageIndex],
        data: message, // Update the data property
        text: getTextFromEvent(newMessageObject, prevChatLog), // Update text
      };
      
      return updatedChatLog;
    }

    // If no existing message is found with that ID, treat it as a new message.
    const fullNewMessageObject = {
      ...newMessageObject,
      isSQLResponse: true,
      role: "assistant",
      type: "sql",
      data: message,
      text: getTextFromEvent(newMessageObject, prevChatLog),
    };
    return [...prevChatLog, fullNewMessageObject];
  });
}, [message, setChatLog, setIsLoading]); // Depend on message and state updaters

  useEffect(()=>{ 
    setLoading(isThreadDataFromThreadIdLoading)
  },[isThreadDataFromThreadIdLoading])

  useEffect(() => {
    resetInactivityTimeout();
    return () => {
      if (inactivityTimeoutRef.current)
        clearTimeout(inactivityTimeoutRef.current);
    };
  });

  return (
    <Box
      sx={{
        marginTop: "49px",
        height: "115vh",
        display: "flex",
        flexDirection: "column",
      }}
    >
      {showInitialView && (
        <>
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              maxHeight: "100vh",
              alignItems: "center",
              padding: 4,
              gap: 4,
            }}
          >
            <Box sx={{ marginRight: "60px" }}>
              <Typography
                variant="h4"
                sx={{
                  color: "#2861BB",
                  marginTop: "23px",
                  fontSize: "46px",
                  fontStyle: "normal",
                  fontWeight: 600,
                  lineHeight: "48px",
                }}
                gutterBottom
              >
                Welcome, {profileName}
              </Typography>
              <Typography
                variant="h6"
                sx={{
                  color: textColor,
                  marginTop: "23px",
                  fontSize: "46px",
                  fontStyle: "normal",
                  fontWeight: 600,
                  lineHeight: "48px",
                }}
              >
                I am your Chat Assistant
              </Typography>
              <Typography
                variant="subtitle1"
                sx={{
                  color: textColor,
                  marginTop: "23px",
                  fontSize: "46px",
                  fontStyle: "normal",
                  fontWeight: 600,
                  lineHeight: "48px",
                }}
              >
                How can I help you today?
              </Typography>
            </Box>
            <Box
              sx={{
                display: "flex",
                justifyContent: "center",
                marginTop: "40px",
                gap: 4,
                flexWrap: "wrap",
              }}
            >
              {headerData.map((data, index) => (
                <Box
                  key={index}
                  sx={{
                    alignItems: "center",
                    display: "flex",
                    flexDirection: "column",
                    gap: 2,
                  }}
                >
                  {/* <img src={example} alt="gcp" style={{width:40 }}/> */}
                  <Box component="img" src={data.icon} alt="logo" />
                  <Typography
                    sx={{
                      fontSize: "18px",
                      textAlign: "center",
                      color: "#44B8F3",
                      fontStyle: "normal",
                      fontWeight: 500,
                      lineHeight: "28px",
                    }}
                  >
                    {data.title}
                  </Typography>
                  <Paper
                    sx={{
                      display: "flex",
                      height: "220px",
                      width: "200px",
                      padding: "24px",
                      justifyContent: "center",
                      alignItems: "center",
                      gap: "10px",
                      borderRadius: "20px",
                      backgroundColor: bgColor,
                      // alignSelf: "stretch",
                      overflowY: "auto",
                      "&:: -webkit-scrollbar": {
                        width: "8px",
                      },
                      "&::-webkit-scrollbar-track": {
                        background: "transparent",
                        borderRadius: "4px",
                      },
                      "&::-webkit-scrollbar-thumb": {
                        background: "#888",
                        borderRadius: "4px",
                        minHeight: "10px",
                      },
                    }}
                  >
                    {/* {promptDisplay[index]?.prompt} */}
                    <Typography sx={{ paddingTop: "27px" }}>
                      {/* Lorem ipsum dolor sit amet consectetur adipisicing elit. Ut nemo aperiam sapiente dolor, nam optio unde quia, praesentium enim consectetur quis iure. Officiis asperiores, facere a voluptates aut fugit, laudantium consectetur dolorem suscipit voluptatibus inventore iure ab, quas quis voluptatum! */}
                      {promptDisplay[index]?.prompt}
                    </Typography>
                  </Paper>
                </Box>
              ))}
            </Box>
          </Box>
        </>
      )}
      {/* // :( */} 
      <>
        <Box
          sx={{
            // flex: 1,
            marginLeft: "20px",
            width: "100%",
            overflowY: "auto",
            maxHeight: "100vh",
            "&:: -webkit-scrollbar": {
              width: "8px",
            },
            "&::-webkit-scrollbar-track": {
              background: "transparent",
              borderRadius: "4px",
            },
            "&::-webkit-scrollbar-thumb": {
              background: "#888",
              borderRadius: "4px",
              minHeight: "10px",
            },
            padding: "10px",
            //marginLeft: '360px',
            ...customStyles.chatContainer,
          }}
        >
          <AgentChatMessage
            ref={chatMessageRef}
            executeSQLHandleButtonClick={executeSQLHandleButtonClick}
            chatLog={chatLog}
            chatbotImage={chatbotImage}
            userImage={userImage}
            storedResponse={storedResponse}
            showResponse={apiResponse}
            contentTableRef={contentTableRef}
            contentSumm={contentSumm}
            isLoading={isLoading} 
          />

          <div ref={endOfMessagesRef} />

          {/* {isLoading && <HashLoader color={themeColor} size={30} aria-label="Loading Spinner" data-testid="loader" />} */}
          {/* {isLoading && <LoadingSpinner isLoading={isLoading}></LoadingSpinner>} */}
          {/* {responseReceived && <Feedback />} */}
          {successMessage && (
            <Alert color="success">
              <span>{successMessage}</span>
            </Alert>
          )}
          <br></br>
          <br></br>
          <br className="scrollable"></br>
        </Box>

        <Box
          sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            width: isCollapsed ? "90%" : "80%",
            flexDirection: "column",
            position: "fixed",
            bottom: "50px",
            // transform: 'translateX(50%)'
          }}
        >
          <form
            onSubmit={handleSubmit}
            style={{ width: isCollapsed ? "90%" : "70%" }}
          >
            <TextField
              //disabled
              fullWidth
              id="inputChatTxtFld"
              placeholder="What can I help you with..."
              sx={{
                input: {
                  // color: textboxColor,
                  backgroundColor: textboxColor,
                  "&:-webkit-autofill": {
                    boxShadow: `0 0 0 100px ${textboxColor} inset !important`,
                    WebkitTextFillColor: textColor,
                  },
                },

                "& .MuiOutlinedInput-root": {
                  "& fieldset": {
                    borderColor: textColor,
                  },
                  "&:hover fieldset": {
                    borderColor: textColor,
                  },
                  "&.Mui-focused fieldset": {
                    borderColor: textColor,
                  },
                },
              }}
              //value={inputField}
              value={
                input
              }
              onChange={(e) => {
                //alert('onchange')
                //setInputChatField(e.target.value);
                setInput(e.target.value);
                // setInputChatField(e.target.value);
                 handleInputFocusOrChange(); // Ensure elements disappear when typing
              }}
              onFocus={handleInputFocusOrChange}
              inputProps={{ maxLength: 400 }}
              InputProps={{
                sx: {
                  "& .MuiInputBase-input": {
                    padding: "17px",
                    fontSize: "1.2rem",
                    color: textColor,
                  },
                  "& .MuiInputAdornment-root button": {
                    color: textboxColor,
                  },
                },
                startAdornment: (
                  <InputAdornment position="start">
                    <IconButton onClick={handleMicClick} disabled={isLoading && !abortcontrollerRef?.signal.aborted}>
                      <MicIcon
                        style={{
                          color: (isLoading && !abortcontrollerRef?.signal.aborted) ? "grey" : iconColor,
                        }}
                      />
                    </IconButton>
                  </InputAdornment>
                ),
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton type="submit" disabled={isLoading && !abortcontrollerRef?.signal.aborted}>
                      <FaTelegramPlane
                        className="h-6 w-6"
                        style={{
                          color: (isLoading && !abortcontrollerRef?.signal.aborted) ? "grey" : iconColor,
                        }}
                      />
                    </IconButton>
                  </InputAdornment>
                ),
              }}
            />
          </form>
        </Box>

        <Snackbar
          open={openSummModal}
          autoHideDuration={6000}
          onClose={() => setOpenSummModal(false)}
          anchorOrigin={{ vertical: "top", horizontal: "center" }}
        >
          <Alert
            onClose={() => setOpenSummModal(false)}
            severity="warning"
            variant="filled"
            sx={{
              fontSize: "1.2rem",
              padding: "16px 24px",
              minWidth: "300px",
            }}
          >
            Unable to generate a summary because the record count exceeds 100
          </Alert>
        </Snackbar>
        <Modal
          open={openPopup}
          onClose={(event, reason) => {
            if (reason !== "backdropClick") {
              setOpenPopup(false);
            }
          }}
          closeAfterTransition
          BackdropComponent={Backdrop}
          BackdropProps={{
            timeout: 500,
          }}
        >
          <Fade in={openPopup}>
            <Box
              sx={{
                position: "absolute",
                top: "50%",
                left: "50%",
                transform: "translate(-50%, -50%)",
                width: 300,
                bgcolor: "background.paper",
                borderRadius: "8px",
                boxShadow: 24,
                p: 4,
                textAlign: "center",
              }}
            >
              <Typography
                variant="h6"
                sx={{
                  fontFamily: '"OpenSans",sans-serif',
                  fontSize: "1.1 rem",
                  fontWeight: 400,
                }}
              >
                Session Ended
              </Typography>
              <Typography
                sx={{
                  mt: 2,
                  fontFamily: '"OpenSans",sans-serif',
                  fontSize: "1.1 rem",
                  fontWeight: 400,
                }}
              >
                Your session has ended due to 180 minutes of inactivity.
              </Typography>
              {/* New Chat Button */}
              <Button
                variant="contained"
                color="primary"
                onClick={sessionEndHandleBtnClick}
                sx={{ mt: 2 }}
              >
                Login
              </Button>
            </Box>
          </Fade>
        </Modal>
      </>
    </Box>
  );
}

export default React.memo(AgentUserChat);