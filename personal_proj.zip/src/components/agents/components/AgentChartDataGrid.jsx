import { Box } from "@mui/system";
import { DataGrid, GridColDef } from "@mui/x-data-grid";

export default function AgentChartDataGrid({columns,rows}){

  

    return(
     <Box sx={{ height: 400, width: '100%' }}>
      <DataGrid
        rows={rows}
        columns={columns}
        initialState={{
          pagination: {
            paginationModel: {
              pageSize: 5,
            },
          },
        }}
        pageSizeOptions={[5]}
        disableRowSelectionOnClick
      />
    </Box>
    )
}