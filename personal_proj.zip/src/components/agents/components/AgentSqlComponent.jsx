import hljs from "highlight.js/lib/core"; 
import sql from "highlight.js/lib/languages/sql";
import React, { useEffect, useRef } from "react";
import 'highlight.js/styles/github.css'; 
import { Typography } from "@mui/material";

 function AgentSqlComponent(agentSqlComponentProps){ 
    const codeRef = useRef(null);
    const {data :code}=agentSqlComponentProps
    hljs.registerLanguage('sql', sql);

    useEffect(() => {
        if (codeRef.current) {
          hljs.highlightElement(codeRef.current);
        }
      }, [code]); 
    return(
        <>
        <Typography component={"h4"}>SQL</Typography>  
        <pre>
            <code ref={codeRef} className="language-sql">
                {code}
            </code>
        </pre>
        </>
    )   
}

export default React.memo(AgentSqlComponent)