import React, { useState,useEffect } from 'react';
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import Typography from '@mui/material/Typography';
import Divider from '@mui/material/Divider';
import Box from '@mui/material/Box';
import { MdExpandMore } from 'react-icons/md';
import lightbulb from '../../../assets/CustomButtons/lightbulb.png';
import toolkit from '../../../assets/CustomButtons/toolkit.png';
import document from '../../../assets/CustomButtons/document.png';
import { trackIndexRef } from '../../../helpers';
import { PulseLoader } from 'react-spinners';


// Assume this is a component that you are using
export default function AgentAccordianComponent({ title, children ,isDefaultopen=false,isLoading=false}) {
  // const [rounds,setRounds]=useState([]);

  // useEffect(()=>{
  //   const grouped=[];
  //   let currentRound=[];

  //   title.forEach((item)=>{
  //     if(item.type==='Thinking'){
  //       if(currentRound.length>0){
  //         grouped.push(currentRound);
  //         currentRound=[item];
  //       }
  //     }else{
  //       currentRound.push(item);
  //     }
  //   });
  //   if(currentRound.length >0){
  //     grouped.push(currentRound);
      
  //   }
  //   setRounds(grouped);
  // },[title])

  const getIcon=(title)=>{
    switch(title){
      case "Thinking":
        return <img src={lightbulb} style={{height:'1.5rem'}}/>;
      case "Tool Use":
        return <img src={toolkit}/>; 
      case "Tool Result":
        return <img src={document}/>; 
    }
  };
  // 1. Manage the expanded state
  const [expanded, setExpanded] = useState(isDefaultopen);

  // 2. Handle the change event
  const handleChange = (event, isExpanded) => {
    setExpanded(isExpanded);
  };

  useEffect(() => {
    if(title=='Tool Result'){
      trackIndexRef.current+=1;
    }
  },[title])

  return (
    <>
   
    <Accordion 
      key={title}
      sx={{
        margin: "6px 0px",
        marginBottom: "10px",
        // border:"1px solid oklch(70.7% 0.022 261.325)",
        // borderRadius: "20px !important",
        boxShadow: 'none', 
        // backgroundColor:"oklch(98.5% 0 0)",
        '&::before': { 
          display: 'none' // This is the most reliable way to remove it
        } 
      }}
      // 3. Pass the controlled 'expanded' prop and 'onChange' handler
      expanded={expanded}
      onChange={handleChange}
    >
      <AccordionSummary
        expandIcon={<MdExpandMore />}
        aria-controls="panel2-content"
        id="panel2-header"
        sx={{
          padding:"6px 16px",
          fontSize:"30px"
        }}
      >
        <Box sx={{display:"flex",alignItems:"center",gap:1}}>
          {getIcon(title)}
          <Typography variant="subtitle2" display={"flex"} alignItems={"center"} gap={"6"} color='oklch(27.8% 0.033 256.848)' fontFamily={"sans-serif"} className={`${isLoading&&'status-message'}`}>{title}{isLoading&&<PulseLoader color="#1a3673" size={4} />} </Typography>
        </Box>
      </AccordionSummary>
      
      {/* 4. Conditionally render the Divider */}
      {/* {expanded && <Divider variant="middle" />} */}
      
      <AccordionDetails >
        <Box sx={{
          color: "#231E33",
          fontSize:'14px',
          fontWeight:400
        }}>
          {children}
        </Box>
      </AccordionDetails>
    </Accordion>
    </>
  );
}

 