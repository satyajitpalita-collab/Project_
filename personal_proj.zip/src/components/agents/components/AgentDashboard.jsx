import React, { useEffect, useState, forwardRef, useImperativeHandle, useCallback } from "react";
import { Box } from "@mui/material"; 
import { v4 as uuidv4 } from 'uuid'; 
import { useAtom, useAtomValue } from 'jotai';
import ChatDrawer from "../../Drawer";
import { abortcontrollerRefAtom, chatLoadingAtom, chatLogAtom, getThreadFromThreadIdQueryAtom, messageIdAtom, runPromptAtom, threadIdAtom } from "../../../helpers"; 
import UserChat from "../../UserChat";
import AgentUserChat from "./AgentUserChat";
import { useSelector } from "react-redux";
import { API_STATUS } from "../../../const/constant";
import { useAppUrl } from "../../../helpers/hooks/hooks";

const drawerWidth = 400;
const collapsedWidth = 60;

// const Transition = React.forwardRef(function Transition(props, ref) {
//   return <Slide direction="up" ref={ref} {...props} />;
// });

const AgentDashboard = forwardRef(({

    logo,
    themeColor = "#1a3673",
    title = "Chat Assistant",
    newChatButtonLabel = "New Chat",
    onNewChat,
    apiPath,
    sqlUrl,
    appCd,
    theme,
    chatInitialMessage = "Hello there, I am your Chat Assistant. How can I help you today?",
    // customStyles = {},
    chatbotImage,
    //suggestedPrompts,
    userImage
}, ref) => {
    useImperativeHandle(ref, () => ({
        resetThings: () => {
            //console.log('coming from line 47');
            setChatLog([]);
            setCortexMessages([]);
            setResponseReceived(false);
            setError('');
            setIsLoading(false);
            setSuccessMessage('');
            setShowInitialView(true);
            setRequestId(uuidv4());
            onNewChat?.(uuidv4());
            setShowExecuteButton(false);
            setShowButton(false);
            setShowProivdeSummary(false);
        }
    })); 

   
     const { API_BASE_URL, APP_NAME } = useAppUrl();
    const [chatLog, setChatLog] = useAtom(chatLogAtom);
    const [messageId, setMessageId] = useAtom(messageIdAtom);
    
      const [abortcontrollerRef,setAbortcontrollerRef]=useAtom(abortcontrollerRefAtom);
    const [threadId,setThreadId]=useAtom(threadIdAtom); 
    const [cortexMessages, setCortexMessages] = useState([]);
    const [responseReceived, setResponseReceived] = useState(false);
    const {data:fetchedDataFromThreadId,refetch}=useAtomValue(getThreadFromThreadIdQueryAtom)
    const [error, setError] = useState('');
    //const [isLoading, setIsLoading] = useState(false);
    const [isLoading, setIsLoading] = useAtom(chatLoadingAtom);
    const [successMessage, setSuccessMessage] = useState('');
    const [showInitialView, setShowInitialView] = useState(chatLog?.length !== 0 ? false : true);
    const [requestId, setRequestId] = useState(uuidv4());
    const [showExecuteButton, setShowExecuteButton] = useState(false);
    const [showProivdeSummary, setShowProivdeSummary] = useState(false);
    const [showButton, setShowButton] = useState(false); // New state to show/hide the button
    const [inputChatField, setInputChatField] = useState(''); 
    const [favorites, setFavorites] = useState([]);
    const token = localStorage.getItem('token'); 
    const [isCollapsed, setIsCollapsed] = useState(false);
    const [getrunPrompt] = useAtom(runPromptAtom); 
    const handleNewChat = () => {
        setChatLog([]);
        setMessageId(0)
        setThreadId(null)
        setCortexMessages([]);
        setResponseReceived(false);
        setError('');
        setIsLoading(false);
        setSuccessMessage('');
        setShowInitialView(true);
        setRequestId(uuidv4());
        onNewChat?.(uuidv4());
        setShowExecuteButton(false);
        setShowButton(false);
        setShowProivdeSummary(false);
        abortcontrollerRef.abort()
    };
 

    useEffect(() => {
        setInputChatField(getrunPrompt);
        console.log('from dashboard', getrunPrompt);
    }, [getrunPrompt])

  
    const handlePromptClick = useCallback((prompt) => {
        //alert(`Clicked: ${prompt}`);
        //$('inputChatTxtFld').val(`${prompt}`);  
        setInputChatField(prompt?.prompt || prompt?.text || prompt);
    },[]);
 

    const handleTryFromChild = (prompt) => {
        // console.log('line 147',prompt);
        setInputChatField(prompt);
    } 

     useEffect(()=>{ 
        if(threadId){
            refetch()
            setShowInitialView(false)
        }
     },[threadId])
    


    return (
        <Box sx={{
            display: "flex", backgroundColor: 'background.default',
            color: 'text.primary'
        }}>
            <ChatDrawer isCollapsed={isCollapsed} handleNewChat={handleNewChat} setIsCollapsed={setIsCollapsed} onPromptClick={handlePromptClick} onTryFromChild={handleTryFromChild} />
 
            <Box
                component="main"
                sx={{
                    flexGrow: 1,
                    p: 3,
                    transition: 'margin-left 0.3s',
                    marginLeft: isCollapsed ? `${collapsedWidth}px` : `${drawerWidth}px`
                }}
            >
                <AgentUserChat
                    isCollapsed={isCollapsed}
                    chatLog={chatLog}
                    setChatLog={setChatLog}
                    cortexMessages={cortexMessages}
                    setCortexMessages={setCortexMessages}
                    responseReceived={responseReceived}
                    setResponseReceived={setResponseReceived}
                    error={error}
                    setError={setError}
                    isLoading={isLoading}
                    setIsLoading={setIsLoading}
                    successMessage={successMessage}
                    setSuccessMessage={setSuccessMessage}
                    showInitialView={showInitialView}
                    setShowInitialView={setShowInitialView}
                    themeColor={themeColor}
                    requestId={requestId}
                    setRequestId={setRequestId}
                    apiPath={apiPath}
                    appCd={appCd}
                    // customStyles={customStyles.chat}
                    chatInitialMessage={chatInitialMessage}
                    chatbotImage={chatbotImage}
                    userImage={userImage}
                    handleNewChat={handleNewChat}
                    sqlUrl={sqlUrl}
                    // suggestedPrompts={suggestedPrompts}
                    showExecuteButton={showExecuteButton}
                    setShowExecuteButton={setShowExecuteButton}
                    showProivdeSummary={showProivdeSummary}
                    setShowProivdeSummary={setShowProivdeSummary}
                    showButton={showButton}
                    setShowButton={setShowButton}
                    inputField={inputChatField}
                    setInputChatField={setInputChatField}

                />
            </Box>
        </Box>
    );
});

export default AgentDashboard;
