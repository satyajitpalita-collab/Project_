import React from "react";
import AgentAccordianComponent from "./AgentAccordianComponent";
import AgentTableComponent from "./AgentTableComponent";

function AgentTableAccordianComponent(agentTableAccordianComponentProps){ 
    console.log({data:agentTableAccordianComponentProps?.data})
    const data= agentTableAccordianComponentProps?.data?.result_set
    return (
          <AgentAccordianComponent title={"Table"} isDefaultopen={true}>
           <AgentTableComponent data={data} />
            {/* <AgentChartModal chartType={spec?.mark} spec={spec} chartData={spec?.data?.values} title={spec?.title}/> */}
        </AgentAccordianComponent>
    ) 

}

// Corrected export statement:
export default React.memo(AgentTableAccordianComponent);
