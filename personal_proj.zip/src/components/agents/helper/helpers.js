import { AGENT_RESPONSE_TYPE_OBJ } from "./contants";

export const getTextFromEvent = (data, chatLogs) => {
   let parsedData=parseJson(data);

    if (data) {
        try {
            // Attempt to parse only if it's not the DONE signal
            parsedData = JSON.parse( data);  
            if(parsedData?.message )
               return parsedData?.message 
            else if(parsedData?.text)
               return parsedData?.text;
            else
                return parsedData?.content
        } catch (error) { 
            // You might choose to return the raw data if it's meant to be text
            return data;
        }
    }
 
    // Use the parsed data to return the text
    return parsedData?.text;
};

export const parseJson=(Json)=>{
   if (Json === "[DONE]"||!Json) { 
        return null; // Return an empty string or handle the end of stream logic
    }else if(typeof JSON==='string'){
        return JSON.parse(Json)
    }else{
        return Json
    }
}

export const parseJsonfromThread=(Json)=>{  
  const tempArr=[]
  const eventArr = Json?.split("\n\n");
  for (const eventString of eventArr) {
          const eventArr = eventString.split("\n");
          const dataMatch = eventString.split(/data:\s*(.*)/);
          const eventMatch = eventString.split(/event:\s*(.*)/); 
          if (dataMatch) {
            const data = dataMatch[1];
            const event= eventMatch[1];
            if(data==="[DONE]"||!data){
              continue;
            } 
            tempArr.push({
              data:(data&&JSON.parse(data) )?JSON.parse(data):data,
              event
            }) 
          }
        } 
        return tempArr
    
}

export function combineConsecutiveEvents(messages) { 
  // return messages.reduce((accumulator, currentItem) => {
  //   const lastItem = accumulator[accumulator.length - 1];

  //   // Check for consecutive events with a `data` object containing a `text` key
  //   const lastItemHasText = lastItem?.data?.text !== undefined;
  //   const currentItemHasText = currentItem?.data?.text !== undefined; 
  //   console.log({messages,lastItem,currentItem})
  //   if (
  //     lastItem &&
  //     lastItem.event === currentItem.event &&
  //     lastItemHasText &&
  //     currentItemHasText
  //   ) { 
  //     // If it's a consecutive event and both have text, concatenate
  //     lastItem.data = currentItem.data.text;
  //   } else {
  //     // Otherwise, push a new item (could be the first item,
  //     // a different event, or an event without a text property)
  //     accumulator.push({ ...currentItem });
  //   }
    
  //   return accumulator;
  // }, []);
  const result=[]

  for(const message of messages){
    const last=result[result.length-1]

    const lastHasTest=last && typeof last?.data?.text=="string";
    const currentHasTest= typeof message?.data?.text=="string";
    if(last && last.event===message.event && lastHasTest && currentHasTest){
      last.data={
        ...last.data,
        text:last.data.text+message.data.text
      };
      continue
    }
    result.push(JSON.parse(JSON.stringify(message)))
  }
  return result
}

export const getXYAxisFromSpec=(spec,chartType)=>{ 
    switch (chartType) {
      case 'bar': 
        return  {xAxisKey :spec.encoding.y.field,
                yAxisKey :[spec.encoding.x.field]
              }
      case 'line': 
        return  {xAxisKey :spec?.encoding?.x?.field,
                yAxisKey :[spec?.encoding?.y.field]
              }
      case 'rect':
        return  {xAxisKey :spec?.encoding?.y?.field,
                yAxisKey :[spec?.encoding?.x?.field,]
              }
      case 'arc':
        return  {xAxisKey :spec?.encoding?.color?.field,
                yAxisKey :[spec?.encoding?.theta?.field,]
              }

    }  
}