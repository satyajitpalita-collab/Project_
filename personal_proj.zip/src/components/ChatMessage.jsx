import React, { useEffect,useState, useRef, forwardRef, useImperativeHandle } from 'react';
import { Avatar, Box, Typography, Paper,Button,useTheme } from '@mui/material';
import hljs from 'highlight.js/lib/core';
import sql from 'highlight.js/lib/languages/sql';
import 'highlight.js/styles/github.css';
import { IconButton } from '@mui/material';
import ChatBotFeedback from './ChatBotFeedback';
import { Prism as SyntaxHighlighter } from "react-syntax-highlighter";
import { dracula } from "react-syntax-highlighter/dist/cjs/styles/prism";
import ContentCopyIcon from "@mui/icons-material/ContentCopy";
import VisibilityIcon from "@mui/icons-material/Visibility";
import bot from '../../src/assets/ChatPageIcon/bot.png'; 
import data from '../../src/assets/ChatPageIcon/data.png';
import { useAppUrl } from '../helpers/hooks/hooks';
import ChartModal from './ChartModal';


hljs.registerLanguage('sql', sql);

const ChatMessage = forwardRef (({ chatLog, chatbotImage, userImage, 
  showResponse, storedResponse,executeSQLHandleButtonClick,
 contentTableRef,contentSumm,summType,dataType,childMethod,isLoading
  
}, ref) => {
   const {APP_NAME} =useAppUrl();
   const [isOpen, setIsOpen] = useState(APP_NAME==='intelliq' ? true : false);

    useImperativeHandle(ref, ()=> ({
      closeSQLBox: () => setIsOpen(false)
    }));
    const contentRef=useRef();
  

  useEffect(() => {
    hljs.highlightAll();
  //  console.log(chatLog);
  }, [chatLog, showResponse]);

  // const codeRef = useRef([]);
  const theme=useTheme();
  const titleSql="The question can be answered using the semantic model since we have membership data in fact_rsttd_fncl_mbrshp table which can be joined with.";

  const bgColor=theme.palette.mode==='dark' ? '#1A3673':'#E3F4FD';
  const bgColorAssist=theme.palette.mode==='dark' ? '#231E33' : '#FFF';
  const textColor=theme.palette.mode==='dark'? '#FFF':'#231E33';
  const boxShadow=theme.palette.mode==='dark'?'':'0px 0px 7px #898080';
  
 

  
  // const copyToClipboard = async () => {
  //   debugger;
    
  //   const codeElement = codeRef.current;
  //   if (codeElement) {
  //     try {
  //       await navigator.clipboard.writeText(codeElement.textContent);
  //       console.log(codeElement.textContent)
  //       //alert('SQL code copied to clipboard!');
  //     } catch (err) {
  //       console.error('Failed to copy: ', err);
  //     }
  //   }
  // };
  
  
  
    function toggle() {
      setIsOpen((isOpen) => !isOpen);
    }
  
    

  const copyToClipboard=(text)=>{
    
    //const text=codeRef.current.textContent;
    navigator.clipboard.writeText(text);
      //console.log('from chat bubble',text);
  
  }
//console.log(typeof chatLog[0].type);
  
  return (  
    <Box sx={{ width: '100%'}}>
      {chatLog.map((chat, index) => 
       {  
        console.log({chat})
        return(
        <Box key={index} sx={{ display: 'flex', justifyContent: chat.role === 'assistant' ? 'flex-start' : 'flex-end', marginBottom: '25px', marginTop: '25px'}}>
           <Box sx={{ 
             //width:chat.role === 'assistant' ?'100%':null,
             display: 'flex',
             flexDirection: chat.role==='assistant' ? "row" : "row-reverse !important",
             alignItems:"flex-start",
             justifyContent: chat.role==='assistant'?"flex-start":"flex-end",
            }}>
          {chat.role === 'assistant' ? (
                <Avatar src={bot} alt="Chatbot" sx={{ mr: 2, width: 40, height: 32,}} />
              ) : (
                <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" style={{marginLeft:"10px"}} viewBox="0 0 40 40" fill="none">
                <path fillRule="evenodd" clipRule="evenodd" d="M20.0007 3.33301C10.7957 3.33301 3.33398 10.7947 3.33398 19.9997C3.33398 29.2047 10.7957 36.6663 20.0007 36.6663C29.2057 36.6663 36.6673 29.2047 36.6673 19.9997C36.6673 10.7947 29.2057 3.33301 20.0007 3.33301ZM14.1673 15.833C14.1673 15.067 14.3182 14.3084 14.6114 13.6007C14.9045 12.893 15.3342 12.2499 15.8759 11.7082C16.4175 11.1665 17.0606 10.7369 17.7683 10.4437C18.4761 10.1506 19.2346 9.99967 20.0007 9.99967C20.7667 9.99967 21.5252 10.1506 22.233 10.4437C22.9407 10.7369 23.5838 11.1665 24.1254 11.7082C24.6671 12.2499 25.0968 12.893 25.3899 13.6007C25.6831 14.3084 25.834 15.067 25.834 15.833C25.834 17.3801 25.2194 18.8638 24.1254 19.9578C23.0315 21.0518 21.5477 21.6663 20.0007 21.6663C18.4536 21.6663 16.9698 21.0518 15.8759 19.9578C14.7819 18.8638 14.1673 17.3801 14.1673 15.833ZM30.4306 28.3063C29.1826 29.8753 27.5965 31.1421 25.7905 32.0125C23.9846 32.8829 22.0054 33.3343 20.0007 33.333C17.9959 33.3343 16.0167 32.8829 14.2108 32.0125C12.4048 31.1421 10.8187 29.8753 9.57065 28.3063C12.2723 26.368 15.959 24.9997 20.0007 24.9997C24.0423 24.9997 27.729 26.368 30.4306 28.3063Z" fill="#2861BB"/>
              </svg>
              )}
              <Paper elevation={2} sx={{ backgroundColor: chat.role === 'assistant' ? bgColorAssist : bgColor, padding: '12px', borderRadius: '15px', maxWidth: chat.role === 'assistant' ?'1150px':'800px',textWrap:'wrap', boxShadow: boxShadow, color: textColor, paddingRight: chat.role === 'assistant' ? '60px' : '30px', paddingTop: chat.role === 'assistant' ? '30px' : '10px' }}>
            <Box sx={{ display: 'flex', alignItems: 'center' }}>
              
              
              
              <Typography  variant="body2" sx={{ fontFamily:'"OpenSans",sans-serif',fontSize: '1.1 rem', fontWeight: 400, ml: 1, width: "100%" }}>
                {
                  
                 (chat?.type !== "error" ) ? (
                  <>
                  {(chat.isSQLResponse) ? (
                    <Box ref={contentRef} key={index}>
                    <Typography 
                    
                    sx={{color:textColor,
                      // display:"flex",
                      // flexWrap:"wrap",
                      // maxWidth:"1000px",
                      // width:"100%",
                    //wordSpacing:"10px",
                    paddingRight:"360px",  
                    fontSize: "16px",
                    fontStyle: "normal",
                    fontWeight: 500,
                    lineHeight: "20px",
                    paddingBottom:"18px"
                  }}>
                    {chat.type}
                    </Typography>
                     {/* <>
                        {chat.data}
                        </> */}
                    <Box sx={{ borderRadius: "10px 10px 0px 0px", overflow: 'hidden', boxShadow: 1 }}>
                    <Box sx={{ display: 'flex',height:"55px", justifyContent: 'space-between', alignItems: 'center', bgcolor: '#666', px: 2, py: 1 }}>
                       
                    <Typography color="white" fontSize={14} fontWeight={500}>SQL</Typography>
                      <Box >
                      <IconButton size="small" sx={{ color: 'white',mr:2 }}>
                      <VisibilityIcon fontSize="small" onClick={()=>toggle()}/>
                      </IconButton>
                      <IconButton size="small" sx={{ color: 'white' }} onClick={()=>copyToClipboard(chat.query)}>
                      <ContentCopyIcon fontSize="small" />
                      </IconButton>
                      </Box>
                    </Box>
                    {isOpen &&
                  
                    <SyntaxHighlighter
                    style={dracula}
                    wrapLongLines={true}
                    wrapLines={true}
                    customStyle={{
                      margin:0,
                      paddingTop:"20px",
                      borderRadius: "0px 0px 10px 10px",
                      fontFamily:'"OpenSans",sans-serif',
                    }}
                    lineProps={{
                      style: {
                        whiteSpace: 'pre-wrap',
                        wordBreak: 'break-word',
                        display: 'block',
                        fontFamily:'"OpenSans",sans-serif',
                        
                      }
          }}
                    PreTag="div"
                    language="sql"
                    // {...props}
                    // wrapLongLines={true}
                  >
                    {String(chat.query).replace(/\n$/, "")}
                  </SyntaxHighlighter>
}
                    </Box>
                    {(APP_NAME === 'intelliq' || !chat.isSQLResponse) && (
                    <Typography sx={{
                      color:textColor,
                    fontSize: "16px",
                    fontStyle: "normal",
                    fontWeight: 500,
                    lineHeight: "20px",
                    paddingTop:"18px"
                  }}>
                    Other View Options:
                    </Typography>
                    )}
                    {APP_NAME === 'intelliq' && (
                    <Box sx={{display:"flex",justifyContent:"left",gap:"20px",marginTop:"30px"}}>
                    <Button disabled={isLoading} sx={{textTransform:'none',backgroundColor:"#2861BB",color:"#FFF"}} variant="contained" startIcon={<img src={data} alt="data" style={{width:24,height:24 }} />}
                     onClick={()=>executeSQLHandleButtonClick(chat?.rawResponse)}>
                      View Data
                      </Button>
                    {/* <Button sx={{textTransform:'none'}} variant="contained" startIcon={<img src={graph} alt="data" style={{width:24,height:24 }} />}>
                      View Graph
                      </Button>
                    <Button sx={{textTransform:'none'}} variant="contained" startIcon={<img src={summary} alt="data" style={{width:24,height:24 }}/>} onClick={generateSummaryHandleButtonClick}
                    >
                      View Summary
                      </Button> */}
                    </Box> )}
                    </Box>
                  ):(
                    <pre key={index} style={{ display: 'flex',justifyContent:'flex-start', whiteSpace: 'pre-wrap', fontFamily:'"OpenSans",sans-serif',fontSize: '1.1rem', fontWeight: 400}}>
                  {chat?.graph==='graph' ?(
                    <ChartModal chartData={chat.content || []} id={index}/>
                  ):(<>{chat.content}</>)}
                  
                 
                 </pre>
                  )}
                  </>
                
                ) 
                : (
                <p key={index} style={{ fontFamily:'"OpenSans",sans-serif',fontSize: '1.1rem', fontWeight: 400,textAlign: 'justify', color:'black'}}>
                {chat.content}
                </p>)
                }
                {chat.role === 'assistant'  && (
                  // <Box>
                  //   <Box  sx={{display:"flex",justifyContent:"flex-start",marginTop:"20px"}} >
                  //   <img src={copy} alt="gcp" style={{width:20, }} />
                  //   <img src={download} alt="gcp" style={{width:20, }} />
                  //   <img src={read} alt="gcp" style={{width:20, }} />
                  //   </Box>
                    <  >

                    <ChatBotFeedback 
                      response="response"
                      userId="user123"
                      queryId="chat.queryId"
                      prompt={chat.prompt}
                      sqlprompt={chat?.sqlprompt}
                      sqlquery={chat?.sqlquery}
                      query={chat.query}
                      titleSql={titleSql}
                      childMethod={childMethod}
                      chatError={chat?.type==="error"?true:false}
                      content={chat.content}
                      contentRef={contentRef}
                      contentTableRef={contentTableRef}
                      contentSumm={contentSumm}
                      disableCopy={chat?.disableCopy|| false}
                      disableDownload={chat?.disableDownload || false}
                      summary={chat.summary}
                      dataGrid={chat.data}
                      graph={chat?.graph}
                      summType={summType}
                      dataType={dataType}
                      isSql={chat.isSQLResponse}
                      summaryData={chat?.summaryData || ''}
                      rows={chat?.rows || []}
                      columns={chat?.columns || []}
                      />
                      </>
                  // </Box>
                  // <div style={{ maxWidth: '600px', marginLeft: 'auto', padding: '20px' }}>
                  
                  // </div>
                ) 
              }
              </Typography>
              
            </Box>
          </Paper>
              </Box>
          
        </Box>
      )})}
    </Box>

  );
});

export default ChatMessage;
