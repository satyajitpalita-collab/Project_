import { styled, useTheme } from '@mui/material/styles';
import { DataGrid } from '@mui/x-data-grid';
 
export const StyledDataGrid = styled(DataGrid)(({ theme }) => ({
  '& .MuiDataGrid-columnHeader': {
    backgroundColor: theme.palette.mode === "dark" ? "#949494" : "#eee",
    color: '#231E33',
    fontWeight: 'bold',
  },
  // Add other stable class overrides here
  '& .MuiDataGrid-columnHeaders': {
    borderBottom: '1px solid #ccc'
  },
  '& .MuiDataGrid-cell': {
    borderRight: '1px solid #ccc'
  },
}));
 
// function MyDynamicDataGridComponent({ processedRows, dynamicColumns }) {
//   // Use the styled component instead of the base DataGrid
//   return (
//     <StyledDataGrid
//         key={processedRows?.id}
//         rows={processedRows}
//         columns={dynamicColumns}
//         disableRowSelectionOnClick
//         pagination
//         initialState={{
//           pagination: { paginationModel: { pageSize: 10 } },
//         }}
//         pageSizeOptions={[10, 15, 20]}
//     />
//   );
// }
// export default MyDynamicDataGridComponent
 