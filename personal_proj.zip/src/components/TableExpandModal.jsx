import { Button, Dialog, DialogContent, DialogTitle, Box } from "@mui/material"
const TableExpandModal = ({
    open,
    onClose,
    title,
    children,
}) => {

    const handleClose = () => {
        if (onClose) onClose()
    }
    return (
        <Dialog
            open={open}
            onClose={handleClose}
            fullWidth
            maxWidth={false}
        >
            {title && (<DialogTitle>
                <Box sx={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                    <Box component="span" sx={{ fontWeight: 600 }}>
                        {title}
                    </Box>
                </Box>
            </DialogTitle>)}

            <DialogContent>
                {children}
            </DialogContent>

            <Box sx={{ display: "flex", justifyContent: "flex-end", p: 2 }}>
                <Button variant="contained" onClick={handleClose}>Close</Button>
            </Box>
        </Dialog>
    )
}
export default TableExpandModal;