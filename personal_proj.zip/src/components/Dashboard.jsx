import React, { useEffect, useState,forwardRef,useImperativeHandle } from "react";
import { Box } from "@mui/material";
import UserChat from './UserChat';
import { v4 as uuidv4 } from 'uuid';
import ChatDrawer from '../components/Drawer';
// import useAuth from './useAuth';
import axios from "axios";
// import { Brightness4, Brightness7, ContactlessOutlined } from "@mui/icons-material";
// import { useThemeMode } from "../themes/ThemeContext";
//import { getBaseURLIntelliQ, getBaseURLMedRFE } from "../configLoader";
import { useAtom } from 'jotai';
import { chatLoadingAtom, chatLogAtom, runPromptAtom } from '../helpers';
import { useAppUrl } from "../helpers/hooks/hooks";
import { IQPIClearCache } from "../service/ApiDataService";
//import { IQPIfetch } from "../service/ApiDataService";

const drawerWidth = 400;
const collapsedWidth=60;

// const Transition = React.forwardRef(function Transition(props, ref) {
//   return <Slide direction="up" ref={ref} {...props} />;
// });

const Dashboard = forwardRef(({
  
  logo,
  themeColor = "#1a3673",
  title = "Chat Assistant",
  newChatButtonLabel = "New Chat",
  onNewChat,
  apiPath,
  sqlUrl,
  appCd,
  theme,
  chatInitialMessage = "Hello there, I am your Chat Assistant. How can I help you today?",
  // customStyles = {},
  chatbotImage,
  //suggestedPrompts,
  userImage
},ref) => {
  useImperativeHandle(ref,()=>({
    resetThings:()=>{
      //console.log('coming from line 47');
      setChatLog([]);
      setCortexMessages([]);
      setResponseReceived(false);
      setError('');
      setIsLoading(false);
      setSuccessMessage('');
      setShowInitialView(true);
      setRequestId(uuidv4());
      onNewChat?.(uuidv4());
      setShowExecuteButton(false);
      setShowButton(false);
      setShowProivdeSummary(false);
    }
  }));
  // const isMobile = useMediaQuery("(max-width:950px)");
  //const [chatLog, setChatLog] = useState([]);
 // const isMobile = useMediaQuery("(max-width:950px)");
  //const [chatLog, setChatLog] = useState([]);
  const [chatLog, setChatLog] = useAtom(chatLogAtom);
  const [cortexMessages, setCortexMessages] = useState([]);
  const [responseReceived, setResponseReceived] = useState(false);
  const [error, setError] = useState('');
  //const [isLoading, setIsLoading] = useState(false);
  const [isLoading, setIsLoading] = useAtom(chatLoadingAtom); 
  const [successMessage, setSuccessMessage] = useState('');
  const [showInitialView, setShowInitialView] = useState(chatLog.length!==0? false: true);
  const [requestId, setRequestId] = useState(uuidv4());
  const [showExecuteButton, setShowExecuteButton] = useState(false);
  const [showProivdeSummary, setShowProivdeSummary] = useState(false);
  const [showButton, setShowButton] = useState(false); // New state to show/hide the button
  const [inputChatField, setInputChatField] = useState('');
  // const[isDrawerOpen,setIsDrawerOpen]=useState(true);
  // const [open, setOpen] = useState(false);
  //const {logout} = useAuth();
  // const navigate = useNavigate();
  const [favorites,setFavorites]=useState([]);
  const token=localStorage.getItem('token');
  //const API_PROMPT_URL=process.env.REACT_APP_BASE_URL;
  // const API_DEV_URL=process.env.REACT_APP_BASE_URL;
  // const API_PROD_URL=process.env.REACT_APP_PROD_URL;
  // const API_UAT_URL=process.env.REACT_APP_UAT_URL;
  //const baseUrlIntelliQ = useAppUrl();
  const {API_BASE_URL} =useAppUrl();
  // const {mode,toggleTheme}=useThemeMode();
  const [isCollapsed,setIsCollapsed]=useState(false);
  const[getrunPrompt]=useAtom(runPromptAtom);
  // const theme=useTheme();
  // const backgroundColor=theme.palette.mode==='dark'?"#111":"#fff"
  //console.log("Dashboard collapse----> ", isCollapsed)
  const handleNewChat = async() => {
    setChatLog([]);
    setCortexMessages([]);
    setResponseReceived(false);
    setError('');
    setIsLoading(false);
    setSuccessMessage('');
    setShowInitialView(true);
    setRequestId(uuidv4());
    onNewChat?.(uuidv4());
    setShowExecuteButton(false);
    setShowButton(false);
    setShowProivdeSummary(false);
    await IQPIClearCache(token,'/clear_user_session/');
  };

  // useEffect(()=>{
    
  // fetchFavorites();
  // },[]);

  useEffect(()=>{
    setInputChatField(getrunPrompt);
    console.log('from dashboard',getrunPrompt);
  },[getrunPrompt])

//   const fetchFavorites=async()=>{
//     const response= await IQPIfetch(token,'/extractFavouritePrompts/');
//   const favData=response.data.favouritePrompts;
//   const data = [];
//        favData.forEach(element => {
//         const x = data.find((item) => item.id===element.id);
//         if(!x){
//             data.push(element)
//         }
//     });
//     setFavorites(data);
//    // console.log(favorites);
// }

  const handlePromptClick = (prompt) => {
    //alert(`Clicked: ${prompt}`);
    //$('inputChatTxtFld').val(`${prompt}`);
    console.log(prompt);
    setInputChatField(prompt?.prompt|| prompt?.text || prompt);
  };

  

  // const handleClickOpen = () => {
  //   setOpen(true);
  // };

  // const managePrompts=()=>{
  //   setOpen(true);
  // }
  

  // const handleClose = () => {
  //   setOpen(false);
  //   fetchFavorites();
  // };

  const handleTryFromChild=(prompt)=>{
   // console.log('line 147',prompt);
    setInputChatField(prompt);
  }

  
 

  return (
    <Box sx={{display:"flex",backgroundColor:'background.default',
    color:'text.primary'}}>
<ChatDrawer isCollapsed={isCollapsed} handleNewChat={handleNewChat} setIsCollapsed={setIsCollapsed} onPromptClick={handlePromptClick} onTryFromChild={handleTryFromChild}/>
{/* <PromptSection
                // sections={suggestedPrompts}
                favoritesData={favorites}
                onPromptClick={handlePromptClick}
               isCollapsed={isCollapsed}
                
              /> */}

<Box
component="main"
sx={{
  flexGrow:1,
  p:3,
  transition:'margin-left 0.3s',
  marginLeft: isCollapsed ? `${collapsedWidth}px` : `${drawerWidth}px`
}}
>
<UserChat
              isCollapsed={isCollapsed}
              chatLog={chatLog}
              setChatLog={setChatLog}
              cortexMessages={cortexMessages}
              setCortexMessages={setCortexMessages}
              responseReceived={responseReceived}
              setResponseReceived={setResponseReceived}
              error={error}
              setError={setError}
              isLoading={isLoading}
              setIsLoading={setIsLoading}
              successMessage={successMessage}
              setSuccessMessage={setSuccessMessage}
              showInitialView={showInitialView}
              setShowInitialView={setShowInitialView}
              themeColor={themeColor}
              requestId={requestId}
              setRequestId={setRequestId}
              apiPath={apiPath}
              appCd={appCd}
              // customStyles={customStyles.chat}
              chatInitialMessage={chatInitialMessage}
              chatbotImage={chatbotImage}
              userImage={userImage}
              handleNewChat={handleNewChat}
              sqlUrl={sqlUrl}
             // suggestedPrompts={suggestedPrompts}
              showExecuteButton={showExecuteButton}
              setShowExecuteButton={setShowExecuteButton}
              showProivdeSummary={showProivdeSummary} 
              setShowProivdeSummary={setShowProivdeSummary}
              showButton={showButton}
              setShowButton={setShowButton}
              inputField={inputChatField}
              setInputChatField={setInputChatField}
              
            />
</Box>
    </Box>
  );
});

export default Dashboard;
