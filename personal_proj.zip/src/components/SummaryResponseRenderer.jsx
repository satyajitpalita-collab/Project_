import React from 'react';

const LLMResponseRenderer = ({ response }) => {
  // Function to convert the response to HTML
  const convertToHTML = (text) => {
    // Split the text by lines
    const lines = text.split('\n');

    // Map through each line and convert to HTML
    return lines.map((line, index) => {
      if (line.startsWith('**')) {

        // Replace ** with <h2> for main headers
        return <h3 key={index}>{line.replace(/\*\*/g, '').trim().replace(/\*\*/g, '')}</h3>;
        
      } 
      else if(line.startsWith('- **')){
        return <li key={index}>{line.replace(/^- \*\*/g, '').trim().replace(/\*\*/g, '')}</li>;
      }
      else if (line.startsWith('*')) {
        // Replace * with <li> for subpoints
        return <li key={index}>{line.replace(/\*/g, '').trim()}</li>;
      } 
      else if (/^\d+\.\s*\*\*/.test(line.trim())) {
        //const number=line.trim().match(/^\d+\./)?.[0];
        const content=line.trim().replace(/^\d+\.\s*/, '').replace(/\*\*/g, '').trim()
        // Replace * with <li> for subpoints
        return <li key={index} >{`${content}`}</li>;
      } 
      else if (line.startsWith('\t+') || line.startsWith('\t*')) {
        
        // Replace \t+ with <ul> for subpoints
        return <ul key={index} style={{marginLeft:"20px"}}>{line.replace(/^\t\+/, '').trim().replace(/\*/g, '').trim()}</ul>;
      }
      else {
        // Return plain text for other lines
        return <p key={index}>{line.trim()}</p>;
      }
    });
  };

  // Group subpoints under <ul> tags
  const renderContent = () => {
    const elements = convertToHTML(response);
    const groupedElements = [];
    let currentList = [];

    elements.forEach((element, index) => {
      if (element.type === 'li') {
        // Add list items to the current list
        currentList.push(element);
      } else {
        // If a non-list item is found, close the current list and add it to groupedElements
        if (currentList.length > 0) {
          groupedElements.push(<ul key={`ul-${index}`}>{currentList}</ul>);
          currentList = [];
        }
        // Add the non-list element
        groupedElements.push(element);
      }
    });

    // Add any remaining list items
    if (currentList.length > 0) {
      groupedElements.push(<ul key={`ul-end`}>{currentList}</ul>);
    }

    return groupedElements;
  };

  return <div>{renderContent()}</div>;
};

export default LLMResponseRenderer;
