import React from 'react';
import {Dialog,DialogTitle,DialogContent,DialogActions,Typography,Button,Paper, IconButton,Box, InputLabel, FormControl, Select, Chip, OutlinedInput} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import ContentCopyIcon from '@mui/icons-material/ContentCopy';
import { useAtom } from 'jotai';
import { runPromptAtom } from '../helpers';
import { useNavigate } from "react-router";
import FavoriteIcon from '@mui/icons-material/Favorite';
import { FavoriteBorder } from "@mui/icons-material";
import share from '../../src/assets/CustomButtons/share.png'; 

const PromptDetails=({open,item,onClose,favorites
   // onhandleTry
})=>{

    const [,setRunPrompt]=useAtom(runPromptAtom);
    const navigate = useNavigate();
  
   // console.log(item);
    const handleCopy=()=>{
       if(item?.prompt){
           setRunPrompt('');
           navigator.clipboard.writeText(item.prompt);
       }
       onClose();
    }

    const handleDelete = () => {
        console.info('You clicked the delete icon.');
      };

    return(
<Dialog open={open} onClose={onClose} maxWidth={false}
    PaperProps={{
    sx:{
        p:2,
        position:"relative",
        width:"800px !important",
       // maxWidth:"90vw",
        minHeight:"300px",
        display:"flex",
        flexDirection:"column"
    }
}}
>
    <Box display="flex" justifyContent="space-between" alignItems="center">
        <DialogTitle sx={{fontSize: "24px",fontStyle: "normal",fontWeight: 600}}>Prompt Detail</DialogTitle>
        <IconButton sx={{marginRight:'18px'}}><CloseIcon onClick={onClose}/></IconButton>
        </Box>
        
        <DialogContent>
        <Box sx={{display:"flex",justifyContent:"flex-end",gap:3}}>
        <img src={share} alt="collapse" style={{width:20 }} />
                {favorites?.includes(item?.id)?(
<FavoriteIcon sx={{color:"red"}}/>):(
    <FavoriteBorder/>
)}
                </Box>
            <Paper 
            sx={{
                mt:2,
                p:2,
                boxShadow:"none",
                backgroundColor:"#EEE",
                position:"relative",
                display:"flex",
                justifyContent:"space-between",
                alignItems:"center",
                gap:2
            }}
            >
                
            {/* <Typography variant="body1">{item?.category}</Typography> */}
            <Typography variant="body1" sx={{wordBreak:'break-word',fontSize:'1.1rem'}}>{item?.prompt}</Typography>
            <IconButton onClick={handleCopy}>
                <ContentCopyIcon/>
            </IconButton>
            </Paper>
            <FormControl sx={{ mt: 2, width: 300 }}>
        <InputLabel id="demo-multiple-chip-label">Category</InputLabel>
        <Select
          labelId="demo-multiple-chip-label"
          id="demo-multiple-chip"
          multiple
          value={[item?.category]}
          disabled
          //onChange={handleChange}
          input={<OutlinedInput id="select-multiple-chip" label="Chip" />}
          renderValue={(selected) => (
            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
              {selected.map((value) => (
                <Chip onDelete={handleDelete} key={value} label={value} />
              ))}
            </Box>
          )}
        //   MenuProps={MenuProps}
        >
          {/* {names.map((name) => (
            <MenuItem
              key={name}
              value={name}
              style={getStyles(name, personName, theme)}
            >
              {name}
            </MenuItem>
          ))} */}
        </Select>
      </FormControl>
      {/* <FormControl sx={{ mt: 2,ml:2, width: 300 }}>
        <InputLabel id="demo-multiple-chip-label">Result Type</InputLabel>
        <Select
          labelId="demo-multiple-chip-label"
          id="demo-multiple-chip"
          multiple
          value={["Sql","Table"]}
          disabled
          //onChange={handleChange}
          input={<OutlinedInput id="select-multiple-chip" label="Chip" />}
          renderValue={(selected) => (
            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
              {selected.map((value) => (
                <Chip label="Deletable" onDelete={handleDelete} key={value} label={value} />
              ))}
            </Box>
          )}
        //   MenuProps={MenuProps}
        >
          
        </Select>
      </FormControl> */}
        </DialogContent>

        <DialogActions>
        <Box sx={{width:"100%",mt:2, p:2,display:"flex",justifyContent:"space-between",alignItems:"center",}}>
        <Button 
            variant="outlined" 
            size="medium" 
            color="primary"
            onClick={()=>{
               // onhandleTry(item.prompt);
                onClose();
            }} 
            >Cancel</Button>
            <Button 
            variant="contained" 
            size="medium" 
            color="primary"
            onClick={()=>{
                //onhandleTry(item.prompt);
                setRunPrompt(item.prompt);
                onClose();
                navigate("/chat");
            }} 
            >Run</Button>
        </Box>
        </DialogActions>
    </Dialog>
    )
}

export default PromptDetails;