import React, { useEffect, useState } from 'react';
import { fetchToken } from "./Auth";
import Thumbsdown from '../../src/assets/CoversationSectionIcon/Thumbsdown.png';
import Thumbsup from '../../src/assets/CoversationSectionIcon/Thumbsup.png';
import { Box,Stack,useTheme,IconButton} from '@mui/material';
import copy from '../../src/assets/CoversationSectionIcon/Copy.png';
import download from '../../src/assets/CoversationSectionIcon/Download.png';
import read from '../../src/assets/CoversationSectionIcon/Read.png';
import sound from '../../src/assets/CoversationSectionIcon/sound.png';
import downloaddark from '../../src/assets/CoversationSectionIcon/downloaddark.png';
import copydark from '../../src/assets/CoversationSectionIcon/copydark.png';
import thumbsdowndark from '../../src/assets/CoversationSectionIcon/thumbsdowndark.png';
import thumbsupdark from '../../src/assets/CoversationSectionIcon/thumbsupdark.png';
//import { getBaseURLIntelliQ, getBaseURLMedRFE } from "../configLoader";
import ExcelJS from 'exceljs';
import saveAs from 'file-saver';
import { useAppUrl } from '../helpers/hooks/hooks';
import { chatLogAtom } from '../helpers';


const ChatBotFeedback = ({ response, userId, queryId, prompt, query,contentRef,contentTableRef,
  contentSumm, disableCopy,disableDownload, summType,dataType,isSql,summary,dataGrid,titleSql,childMethod,summaryData,
  rows,columns,sqlprompt,sqlquery,graph,chatError,content
  // content
}) => {
  const [feedback, setFeedback] = useState(null); // 'like', 'dislike', or null
  const [comment, setComment] = useState(''); // Optional feedback comment
  const [isSubmitted, setIsSubmitted] = useState(false); // Track if feedback is submitted
  const [isLoading, setIsLoading] = useState(false); // Track API call loading state
  const [error, setError] = useState(null); // Track API call errors
  const [sqlPrompt,setSqlPrompt]=useState('');
  const API_DEV_URL=process.env.REACT_APP_BASE_URL;
  //const baseUrlIntelliQ = useAppUrl();
  const theme=useTheme();
  const textColor=theme.palette.mode==='dark'? '#FFF':'#231E33';
  const downloadsrc=theme.palette.mode==='dark' ? downloaddark : download;
  const readsrc=theme.palette.mode==='dark' ? sound : read;
  const copysrc=theme.palette.mode==='dark' ? copydark : copy;
  const thumbsupsrc=theme.palette.mode==='dark' ? thumbsupdark: Thumbsup;
  const thumbsdownsrc=theme.palette.mode==='dark' ? thumbsdowndark: Thumbsdown;
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [availableVoices, setAvailableVoices] = useState([]);
  const {API_BASE_URL} =useAppUrl();

  // Handle Like/Dislike click
  const handleFeedbackClick = (type) => {
    setFeedback(type);
  };

  useEffect(() => {
    const loadVoices = () => {
      const voices = speechSynthesis.getVoices();
      if(voices.length > 0){
        const enUSVoices = voices.filter(v => v.lang === 'en-US' && v.name === 'Google US English');
        setAvailableVoices(enUSVoices);
        console.log("Loaded voices: ", enUSVoices);
      }
    };

    loadVoices();
    window.speechSynthesis.onvoiceschanged = loadVoices;
    return () => {
      window.speechSynthesis.onvoiceschanged = null;
    };
  }, []);

  function sanitizeText(input){
    return input
    .replace(/\*\*(.*?)\*\*/g, '$1')
    .replace(/_(.*?)_/g, '$1')
    .replace(/#\w+/g, '')
    .replace(/\[(.*?)\]\(.*?\)/g, '$1')
    .replace(/[`~*#_\[\]()]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
  }

  // const convertToHTML = (text) => {
  //   // Split the text by lines
  //   const lines = text.split('\n');

  //   // Map through each line and convert to HTML
  //   return lines.map((line, index) => {
  //     if (line.startsWith('**')) {
        
  //       // Replace ** with <h2> for main headers
  //       return line.replace(/\*\*/g, '').trim();
        
  //     } else if (line.startsWith('*')) {
  //       // Replace * with <li> for subpoints
  //       return line.replace(/\*/g, '').trim();
  //     } 
  //     else if (/^\d+\.\s*\*\*/.test(line.trim())) {
  //       const number=line.trim().match(/^\d+\./)?.[0];
  //       const content=line.trim().replace(/^\d+\.\s*/, '').replace(/\*\*/g, '').trim()
  //       // Replace * with <li> for subpoints
  //       return `${content}`;
  //     } 
  //     else if (line.startsWith('\t+')) {
        
  //       // Replace \t+ with <ul> for subpoints
  //       return line.replace(/^\t\+/, '').trim();
  //     }
  //     else {
  //       // Return plain text for other lines
  //       return line.trim();
  //     }
  //   });
  // };

  const formatAllDataForClipboard = (mainTitle, grids) => {
    const formattedGrids = grids
      .map((grid) => {
        const { columnData, referralList } = grid;

        // Calculate the maximum width for each column
        const colWidths = columnData.map((col) => {
          return Math.max(
            col.headerName.length,
            ...referralList.map((row) => (row[col.field] || '').length),
          );
        });

        // Function to pad strings manually
        const padString = (str, length) => {
          return str + ' '.repeat(length - str.length);
        };

        // Format the headings with proper alignment
        const headings = columnData
          .map((col, index) => padString(col.headerName, colWidths[index]))
          .join('\t');

        // Format each row with proper alignment
        const rows = referralList
          .map((row) => {
            return columnData
              .map((col, index) =>
                padString(row[col.field] || '', colWidths[index]),
              )
              .join('\t');
          })
          .join('\n');

        return `${headings}\n${rows}`;
      })
      .join('\n\n');

    return `${mainTitle}\n\n${formattedGrids}`;
  };

  const copyToClipboard=(column,row)=>{
    const mainTitle = 'Here is the Data Table';
    const grids = [
      {
        columnData: column,
        referralList: row,
      },
    ];
    const formattedData = formatAllDataForClipboard(mainTitle, grids);
    navigator.clipboard.writeText(formattedData);
    //const text=codeRef.current.textContent;
   // navigator.clipboard.writeText(text);
      //console.log('from chat bubble',text);
  
  }

  const handleCopy=()=>{
    if(isSql){
      //const text=contentRef.current.innerText;
      const text= titleSql + '\n' + query;
      navigator.clipboard.writeText(text).then(()=>alert('copied query'));
    }
    else if(dataGrid ==="data"){
      copyToClipboard(columns,rows);
      //const text2=contentTableRef.current.innerText;
     // navigator.clipboard.writeText(text2).then(()=>alert('copiedData'));
    }
    else if(summary === "summary" ) {
      const sText=sanitizeText(summaryData);
      //const text3=contentSumm.current.innerText;
       navigator.clipboard.writeText(sText).then(()=>alert('copiedSummary'));
    }
    // else{
      
    //   const text3=contentSumm.current.innerText;
    //   navigator.clipboard.writeText(text3).then(()=>alert('copiedSummary'));
    // }
  }

  const handleDownload = () => {
    const timestamp = new Date().toISOString().replace(/[:.-]/g, '');
    if(isSql || summary === "summary"){
      const sText=sanitizeText(summaryData);
      const blob = new Blob([query || sText], { type: 'text/plain' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = isSql ? `query_${timestamp}.txt` : `summary_${timestamp}.txt`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
    else if(dataGrid === 'data'){
      const workbook = new ExcelJS.Workbook();
      const worksheet = workbook.addWorksheet('Sheet1');

      worksheet.columns = columns.map((col) => ({
        header: col.headerName,
        key: col.field,
        width: 20,
      }));

      rows.forEach((row) => {
        worksheet.addRow(row);
      });
      workbook.xlsx.writeBuffer().then((buffer) => {
        const blob = new Blob([buffer], {
          type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        });
        saveAs(blob, `query_results_${timestamp}.xlsx`);
      });
    }

  }

  const handleRead = () => {
    if(speechSynthesis.speaking){
      speechSynthesis.cancel();
      setIsSpeaking(false);
    } else {
      let textToRead = '';
      if(isSql && contentRef?.current) {
        textToRead = contentRef.current.innerText;
      } else if(dataGrid === "data" && contentTableRef?.current) {
        textToRead = contentTableRef.current.innerText;
      } else if(summary === "summary" && contentSumm?.current) {
        textToRead = contentSumm.current.innerText;
      }
      if(textToRead){
        const utterance = new SpeechSynthesisUtterance(textToRead);
        //Female Voice
        if(availableVoices){
          utterance.voice = availableVoices[0];
        }

        utterance.onend = () => setIsSpeaking(false);
        utterance.onerror = () => setIsSpeaking(false);
        setIsSpeaking(true);
        speechSynthesis.speak(utterance);
      } else {
        alert("No content available to read.");
      }
    }
  };

  // Handle feedback submission
  const handleSubmitFeedback = async () => {
    if (!feedback) return; // Ensure feedback is selected
    setSqlPrompt(prompt);
    setIsLoading(true); // Start loading
    setError(null); // Reset error state

    try {
      let requestBody;
      // Prepare the request body
      if(isSql){
      requestBody = {
        user_id: userId,
        query_id: queryId,
        prompt: prompt,
        query: query,
        user_opinion: feedback, // 'like' or 'dislike'
        comment: comment, // Optional comment
      };
    }
    else if (dataGrid === "data"){
      requestBody={
        user_id: userId,
        query_id: queryId,
        prompt: sqlprompt,
        query: sqlquery,
        user_opinion: feedback, // 'like' or 'dislike'
        comment: comment, // Optional comment
        type:"data"
        // comment:{
        //   type:"data",
        //   comment:comment
        // }
        //type:"data"
      }
    }
    else if(summary === "summary"){
      requestBody={
        user_id: userId,
        query_id: queryId,
        prompt: sqlprompt,
        query: sqlquery,
        user_opinion: feedback, // 'like' or 'dislike'
        comment: comment, // Optional comment
        type:"summary"
      }
    }
    else if(graph === "graph"){
      requestBody={
        user_id: userId,
        query_id: queryId,
        prompt: sqlprompt,
        query: sqlquery,
        user_opinion: feedback, // 'like' or 'dislike'
        comment: comment, // Optional comment
        type:"graph"
        
      }
    }
    
      const token = fetchToken();

      // Make the API call
      const response = await fetch(`${API_BASE_URL}/submitFeedback/`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify(requestBody),
      });

      // Check if the request was successful
      if (!response.ok) {
        throw new Error('Failed to submit feedback');
      }

      // Parse the response (if needed)
      const data = await response.json(); 

      // Mark feedback as submitted
      setIsSubmitted(true);
    } catch (error) {
      console.error('Error submitting feedback:', error);
      setError('Failed to submit feedback. Please try again.');
    } finally {
      setIsLoading(false); // Stop loading
    }
  };

 

  return (
    <div style={{  }}>

      {/* Feedback Section */}
      {!isSubmitted ? (
        <div style={{ display: 'grid', flexDirection: 'column', }}>
          {/* <p style={{fontFamily:'"OpenSans",sans-serif',fontSize: '1.1 rem', fontWeight: 400}}>Was this response helpful?</p> */}
          {/* <div style={{ display: 'flex', gap: '10px', marginBottom: '10px' }}> */}
          <Box sx={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:2}}>
          <Stack
            direction="row"
            spacing={2}

            >
                    {/* <img src={copy} alt="gcp" style={{width:25, }} /> */}
                    {/* <Button > */}
                    {graph !== "graph" && (
              <IconButton
                sx={{
                  fontSize: "16px", 
                  color: textColor,
                  fontStyle: "normal",
                  fontWeight: 500,
                  lineHeight: "20px",
                  gap: 2
                }} 
                onClick={handleCopy}
                disabled={disableCopy}
                >
                    <Box component="img" src={copysrc} alt="logo"
                      
                     />
                   
                    Copy
                    {/* </Typography> */}
                    </IconButton> )}
                    {/* </Button> */}
                    {/* <img src={download} alt="gcp" style={{width:22, }} /> */}
                    {(graph !== "graph" && !chatError && content!== 'Query produced no results') && (<IconButton sx={{fontSize: "16px",
                    color:textColor,
fontStyle: "normal",
fontWeight: 500,
lineHeight: "20px",
gap:2
 }} onClick={handleDownload} disabled={disableDownload} >
                    <Box component="img" src={downloadsrc} alt="logo"/>
                   
                    Download
                    </IconButton>)}
                    {/* <img src={read} alt="gcp" style={{width:22, }} /> */}
                    {graph !== "graph" && (<IconButton sx={{fontSize: "16px",
                    color:textColor,
fontStyle: "normal",
fontWeight: 500,
lineHeight: "20px",
gap:2
 }} onClick={handleRead} disabled={graph === "graph"} >
                    <Box component="img" src={readsrc} alt="logo"/>
                    
                    {isSpeaking ? "Stop" : "Read"}
                    </IconButton>)}
                    </Stack>
                    <Stack
direction="row"
spacing={2}

>
            <IconButton
              onClick={() => handleFeedbackClick('like')}
              style={{
                //padding: '8px 16px',
                //backgroundColor: feedback === 'like' ? '#4CAF50' : '#f1f1f1',
                //color: feedback === 'like' ? '#fff' : '#000',
                // border: 'none',
                // borderRadius: '4px',
                cursor: 'pointer',
                fontFamily:'"OpenSans",sans-serif',
                // fontSize: '1.1 rem', 
                // fontWeight: 400,
              }}
            >
              {/* <img src={Thumbsup} alt="gcp" style={{width:20, }} /> */}
              <Box component="img" src={thumbsupsrc} alt="logo"/>

            </IconButton>
            <IconButton
              onClick={() => handleFeedbackClick('dislike')}
              style={{
                // padding: '8px 16px',
                // backgroundColor: feedback === 'dislike' ? '#f44336' : '#f1f1f1',
                // color: feedback === 'dislike' ? '#fff' : '#000',
                // border: 'none',
                // borderRadius: '4px',
                cursor: 'pointer',
                fontFamily:'"OpenSans",sans-serif',
                // fontSize: '1.1 rem', 
                // fontWeight: 400,
              }}
            >
              {/* <img src={Thumbsdown} alt="gcp" style={{width:20, }} /> */}
              <Box component="img" src={thumbsdownsrc} alt="logo"/>
            </IconButton>
            </Stack>
            </Box>
          {/* </div> */}

          {/* Optional Comment */}
          {feedback && (
            <div style={{ width: '100%', marginBottom: '10px' }}>
              <textarea
                placeholder="Please provide additional feedback (optional)"
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                style={{
                  width: '100%',
                  padding: '8px',
                  borderRadius: '4px',
                  border: '1px solid #ccc',
                  resize: 'vertical',
                }}
              />
            </div>
          )}

          {/* Submit Button */}
          {feedback && (
            <button
              onClick={handleSubmitFeedback}
              disabled={isLoading} // Disable button while loading
              style={{
                padding: '8px 16px',
                backgroundColor: '#007bff',
                fontFamily: "Elevance Sans",
                color: '#fff',
                border: 'none',
                borderRadius: '4px',
                cursor: 'pointer',
                opacity: isLoading ? 0.7 : 1,
              }}
            >
              {isLoading ? 'Submitting...' : 'Submit Feedback'}
            </button>
          )}

          {/* Error Message */}
          {error && <p style={{ color: '#f44336', textAlign: 'right',fontFamily:'"OpenSans",sans-serif',fontSize: '1.1 rem', fontWeight: 400 }}>{error}</p>}
        </div>
      ) : (
        <p style={{ color: '#4CAF50', textAlign: 'right',fontFamily:'"OpenSans",sans-serif',fontSize: '1.1 rem', fontWeight: 400 }}>Thank you for your feedback!</p>
      )}
    </div>
  );
};

export default ChatBotFeedback;
