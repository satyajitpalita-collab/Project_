import React, { useEffect, useState,useRef} from "react";
import IconButton from '@mui/material/IconButton';
import { AppBar,Grid2,Alert, Toolbar,ListItem, 
Typography, Drawer, Box, Divider,ListItemText,Button,List,
TextField,Snackbar,Collapse,InputAdornment, Paper, } from "@mui/material";
import KeyboardBackspaceIcon from '@mui/icons-material/KeyboardBackspace';
import FavoriteIcon from '@mui/icons-material/Favorite';
import { ExpandLess, ExpandMore, FavoriteBorder } from "@mui/icons-material";
import { GridSearchIcon } from "@mui/x-data-grid";
import { Label } from "@mui/icons-material";
import axios from "axios";
import { useAtom } from 'jotai';
import AddCommentIcon from '@mui/icons-material/AddComment';
import MyPrompts from "./MyPrompts";
import {myPromptDrawer, myPrompts, selectedFilterAtom} from '../helpers/index.js';
import DeleteIcon from '@mui/icons-material/Delete';
import PromptDetails from "./PromptDetailsDialog";
import { useNavigate } from "react-router";
import Add from '@mui/icons-material/Add';
import allprompt from '../../src/assets/CustomButtons/allprompt.png';
import group from '../../src/assets/CustomButtons/Group.png'; 
import edit from '../../src/assets/CustomButtons/edit.png';
//import { getBaseURLIntelliQ, getBaseURLMedRFE } from "../configLoader";
import { useAppUrl } from "../helpers/hooks/hooks.jsx";
import { IQPIfetch, IQPIpost, IQPIdelete } from "../service/ApiDataService";

// const Transition = React.forwardRef(function Transition(props, ref) {
//     return <Slide direction="up" ref={ref} {...props} />;
//   });

  

const drawerWidth = 420;
const PromptSearch = ({ open, onClose,
    //onTryFromChild 
}) => {
    //const [selectedFilter,setSelectedFilter]=useState("All Prompts");
    const [selectedFilter,setSelectedFilter]=useAtom(selectedFilterAtom);
    const[copyFilter,setCopyFilter]=useState("");
    const [search,setSearch]=useState("");
    const [favorites,setFavorites]=useState([]);
    const [msg,setMsg]=useState("Prompt Added successfully in My Prompts");
    // const [allData,setAllData]=useState([]);
    // const [allData,setAllData]=useAtom(allDataPromptAtom);
   const [allData,setAllData]=useState({
       "All Prompts":[],
       "Favorites":[],
       "My Prompts":[]
   })
   const toggFav=["All Prompts","Membership","KPI","Dimensions","Claims","Trend"]
    const token=localStorage.getItem('token');
    // const[favoriteItems,setFavoriteItems]=useState([]);
    const[addedFavorites,setAddedFavorites]=useState([]);
    const[removedFavorites,setRemovedFavorites]=useState([]);
    const[allPromptsCopy,setAllPromptsCopy]=useState([]);
    const [favCopy,setFavCopy]=useState([]);
    const [openAlert,setOpenAlert]=useState(false);
    const [openMyPromptAlert,setOpenMyPromptAlert]=useState(false);
    const [deleteAlert,setDeleteAlert]=useState(false);
    const[selectedItem,setSelectedItem]=useState(null);
    const[openDialog,setOpenDialog]=useState(false);
    const [myPrompt,setMyPrompt]=useAtom(myPrompts);
    const[,setMyPromptDrawer]=useAtom(myPromptDrawer);
    const [copyMyPrompt,setCopyMyPrompt]=useState([]);
    const[openMyPromptDialog,setOpenMyPromptDialog]=useState(false);
    const [openCategories,setOpenCategories]=useState(false);
    const [uniqueCategories, setUniqueCategories] = useState([]);

    const categories=[
    {label:"All Prompts",icon:<img src={allprompt} alt="collapse" style={{width:20 }} />},
    {label:"Favorites",icon:<FavoriteBorder/>},
    {label:"My Prompts",icon:<AddCommentIcon/>},
    {type:"heading",label:"Categories",icon:<img src={group} alt="collapse" style={{width:20 }} />},
    //{label:"General",icon:<Label/>},
    // {label:"Membership",icon:<Label/>},
    // {label:"Claims",icon:<Label/>},
    // {label:"KPI",icon:<Label/>},
    // {label:"Trend",icon:<Label/>},
    // {label:"Dimensions",icon:<Label/>},
    ...uniqueCategories.map((cat) => ({
        label: cat, icon: <Label />
    }))
]
    const headingIndex=categories.findIndex((item)=>item.type==="heading");
    const [itemDraft,setItemDraft]=useState(null);
    const [favoriteFilter, setFavoriteFilter] = useState("");
    // const [sortBy, setSortBy] = useState("Default");
    const navigate = useNavigate();
    //const API_PROMPT_URL=process.env.REACT_APP_BASE_URL;
    // const API_DEV_URL=process.env.REACT_APP_BASE_URL;
    // const API_UAT_URL=process.env.REACT_APP_UAT_URL;
    //const baseUrlIntelliQ = useAppUrl();
    const {API_BASE_URL,APP_NAME} =useAppUrl();
    const modalRef=useRef();
    const [editModal,setEditModal]=useState(false);
 
     
    useEffect(()=>{
        if(!token && APP_NAME === 'pmintel'){
            navigate('/');
        }
    })

    useEffect(()=>{
        if(selectedFilter==="All Prompts"){
            getAllPrompts();
            if(favorites.length===0){
            getFavoritePrompts();
            }
        }
        else if(selectedFilter === "Favorites"){
            getFavoritePrompts();
        }
        else if(selectedFilter === "My Prompts"){
            getMyPrompt();
        }
        // else if(["Membership","Claims","KPI","Trend","Dimension"].includes(selectedFilter)){
        //     setAllData(otherCategory[selectedFilter] || []);
        // }
        else {
            // const otherCategories=allData["All Prompts"].filter(
            //     item=>item.category=== selectedFilter
            // )
            // setAllData(prev=>({
            //     ...prev,
            //     "All Prompts":
            // }))
    //setAllData(allPromptsCopy.filter((item)=>item.category=== selectedFilter));
        }
        setFavoriteFilter("");
    },[selectedFilter,myPrompt])

    const getMyPrompt=async()=>{
        //const test=myPrompt;
        const response= await IQPIfetch(token,'/getDraftPrompts/');
        if(response.status===200){
        //setAllData(response.data.prompts);
        setAllData((prev) => ({
            ...prev,
        "My Prompts":response.data.prompts
        }))
        setCopyMyPrompt(response.data.prompts);
        setMyPromptDrawer(response.data.prompts);
        }
        // console.log(test);
        
    }

    const getAllPrompts= async ()=>{
        console.log(token);
        
       const response= await IQPIfetch(token,'/extractAllPrompts/');
           
       if(response.status===200){
       //setAllData(response.data.prompts);
         setAllData((prev) => ({
             ...prev,
             "All Prompts":response.data.prompts,
      }))
       setAllPromptsCopy(response.data.prompts);
       const categories = [...new Set(response.data.prompts.map(p => p.category).filter(Boolean))];
       setUniqueCategories(categories);
}
    
    }

    const getFavoritePrompts=async()=>{

        const response= await IQPIfetch(token,'/extractFavouritePrompts/');
       if(response.status===200){
       const favData=response.data.favouritePrompts;
       setAllData((prev)=>({
        ...prev,
        "Favorites":favData,
        }))
       setFavCopy(favData);
       //setAllData(favData);
       
    //    if(selectedFilter==="Favorites"){
       //setAllData(favData);
      // }
    
    setFavorites(favData.map((item)=>item.id));
       }
       
      // setFavoriteItems(favData);
    }

    useEffect(() => {
        if (dataToRenderCopy && favoriteFilter) {
            const filteredData = dataToRenderCopy.filter((prompt) => {
                return (
                    // (favoriteFilter === "All" ||
                    (favoriteFilter === "Yes" && favorites.includes(prompt.id)) ||
                    (favoriteFilter === "No" && !favorites.includes(prompt.id))
                    //) 

                    // (categoryFilter === "" || categoryFilter === prompt.category) &&
                    // (membershipFilter === "" || prompt.membership === membershipFilter) &&
                    // (resultTypeFilter === "" || prompt.resultType === resultTypeFilter) &&
                    // (search === "" || prompt.prompt.toLowerCase().includes(search.toLowerCase()))
                );
            })
            setDataToRender(filteredData);
        }
    }, [favoriteFilter, favorites])

    const handleBack = () => {
        navigate("/chat");
    }

    const toggleFavorite=(item)=>{
        const isFav=favorites.includes(item.id);
        if(selectedFilter==="Favorites"){
            //setFavorites((prev)=>prev.filter((fid)=>fid!==item.id));
        
        if(isFav){
            setFavorites((prev)=>prev.filter((fid)=>fid!==item.id));
            // setFavoriteItems((prev)=>prev.filter((i)=>i.id!==item.id));
            if(selectedFilter==="Favorites"){
            //setAllData((prev)=>prev.filter((i)=>i.id!==item.id));
            setAllData((prev)=>({
                ...prev,
                "Favorites":prev.Favorites.filter((i)=>i.id!==item.id),
                }))
            setRemovedFavorites((prev)=>[...prev,item]);
            }
            else{
                setRemovedFavorites((prev)=>[prev.find((i)=>i.id===item.id) ? prev : [...prev,item]]);
            }
        }
    }else{
            // if(isFav){
            //     setFavorites((prev)=>prev.filter((fid)=>fid!==item.id));
            //     setFavoriteItems((prev)=>prev.filter((i)=>i.id!==item.id));
            // }
            // else{
               // console.log(item);
            setFavorites((prev)=>[...prev,item.id]);
            setAddedFavorites((prev)=>prev.find((i)=>i.id===item.id)? prev : [...prev,item])
            //setFavoriteItems((prev)=>[...prev,item.id]);
            //}
            // setRemovedFavorites((prev)=>prev.find((i)=>i.id===item.id)?
            // prev : [...prev,item]
            // )
        }
    
        // setFavorites((prev)=>{
        //     // prev.includes(id)?prev.filter((fid)=>fid !== id) : [...prev,id]
        //     const exists= prev.some((fav)=>fav.id===item.id);
        //     if(exists){
        //         return prev.filter((fav)=>fav.id!==item.id);
        //     }
        //     else{
        //         return [...prev,item];
        //     }
        // });
    };

    useEffect(()=>{
      if(search.length>=2){
          getFilteredData()
      }
      else if(search.length===0){
          if(selectedFilter !== "All Prompts" && selectedFilter !== "Favorites"){
    //    setAllData(allPromptsCopy.filter((item)=>item.category=== selectedFilter)); 
          } 
          else{
            setAllData((prev) => ({
                ...prev,
                [selectedFilter]: selectedFilter === 'All Prompts' ? allPromptsCopy : selectedFilter === 'Favorites' ? favCopy : copyMyPrompt
            }));
        } 
      }
     
    },[search, selectedFilter, allPromptsCopy, copyMyPrompt, favCopy])

    const handleSearchChange=(event)=>{
setSearch(event.target.value);
    }

    const deleteMyPrompt=async(id)=>{
        console.log(id);
        // const updated=myPrompt[0].filter((item)=>item.id !== id);
        // console.log(updated);
        console.log(allData);
        
        const response=await IQPIdelete([id],token,'/deleteDraftPrompts/');
           
        if(response.status===200){
            
             setDeleteAlert(true);
         }
         const updatedData = allData["My Prompts"].map((item)=>{
            if(item && item.id!== id){
                return {...item};
            }
            return null
        }).filter((ele)=>ele!==null);
        setAllData((prev)=>({
            ...prev,
            "My Prompts": updatedData
        }));
        // setMyPrompt((prev)=>prev.map((item)=>{
        //     if(item && item.id!== id){
        //         return {...item};
        //     }
        //     return null
        // }).filter((ele)=>ele!==null));
        
        // const newMessage={
        //     id:updated,
        //    // prompt:input,
        // }
        //setAllData((prev)newMessage);
            }


    const getFilteredData=()=>{
        const textSearch = search.trim().toLowerCase();
        if(!textSearch) return;
        let source = [];
        if(selectedFilter === 'All Prompts') {
            source = allPromptsCopy;
        } else if(selectedFilter === 'Favorites') {
            source = favCopy;
        } else if(selectedFilter === 'My Prompts') {
            source = copyMyPrompt;
        } else {
            source = allPromptsCopy.filter((item) => item.category === selectedFilter);
        }
        const filtered = source.filter((item) => {
            const promptText = item.prompt?.toLowerCase() || "";
            const categoryText = item.category?.toLowerCase() || "";

            return (promptText.includes(textSearch) || categoryText.includes(textSearch));
        });
        setAllData((prev) => ({
            ...prev,
            [selectedFilter]: filtered,
        }));
        setDataToRender(filtered);
        setDataToRenderCopy(filtered);

        // let data=[...allData];

        // if(selectedFilter==="Favorites"){
        //     data=data.filter((item)=>favorites.includes(item.id));
        // } 
        // if(selectedFilter !== "All Prompts" && selectedFilter !== "Favorites"){
        //     data =data.filter((item)=>item.category===selectedFilter);
        // }
        // if(["Membership","Claims","KPI"].includes(selectedFilter)){
        //     data=otherCategory[selectedFilter] || [];
        // }
        // console.log("Search ----> ",search)
        // if(search.trim()!== "" && allData?.[selectedFilter]){
        //     const datUpdated=selectedFilter === 'All Prompts' ? allPromptsCopy 
        //     : selectedFilter === 'Favorites' ? favCopy 
        //     : selectedFilter === 'My Prompts' ? copyMyPrompt
        //     : allPromptsCopy.filter((item) => item.category === selectedFilter);
        //     const data=datUpdated.filter((item)=>
        //     item.prompt.toLowerCase().includes(search.toLowerCase()) ||
        //     item.category.toLowerCase().includes(search.toLowerCase())
        //     );
        //     console.log("FILTERD------->",data)
        // setAllData((prev) => ({
        //     ...prev,
        //     [selectedFilter]: data
        // }));
        // }
        //setSearch(data);
    }

    const saveToFav= async()=>{
    
    console.log(addedFavorites,selectedFilter);
    if(selectedFilter === "My Prompts" && copyMyPrompt.length>0){
        
        const response= await IQPIpost(copyMyPrompt,token,'/addDraftPrompts/');
            
        if(response.status===200){
          console.log("successfull");
          //setMyPrompt([]);
          setCopyMyPrompt([]);
           // setAddedFavorites([]);
           // setOpenAlert(true);
        }
    }
    if(selectedFilter!=="Favorites" && addedFavorites.length>0){
        
       const response= await IQPIpost(addedFavorites,token,'/addFavouritePrompts/');
                  
              if(response.status===200){
                  setAddedFavorites([]);
                  setOpenAlert(true);
              }
    }
    else if(selectedFilter==="Favorites" && removedFavorites.length>0){
        const ids= removedFavorites.map((item)=>item.id);
        //console.log(ids);
        const response=await IQPIdelete(ids,token,'/deleteFavouritePrompts/');
        if(response.status===200){
            
             setDeleteAlert(true);
         }
 
    }
    setAddedFavorites([]);
    setRemovedFavorites([]);

   // alert("Favorites updated");
    }

    // const handleTryPrompt=(prompt)=>{
    //     onTryFromChild(prompt);
    //     console.log('line 402 promptsearch',prompt)
    // }

    //const filteredData=getFilteredData();

    // const managePrompts=()=>{
    //     setOpen(true);
    // };

    // const handleClose = () => {
    //     setOpen(false);
    // };

    // const normalizedFilter=selectedFilter.toLowerCase().replace(/\s/g, '');
    const [dataToRender,setDataToRender]=useState([]);
    const [dataToRenderCopy,setDataToRenderCopy]=useState([]);
    useEffect(()=>{
    const dataToRender2 = allData?.[selectedFilter] ? allData?.[selectedFilter] : allPromptsCopy.filter((item) => item.category === selectedFilter)
     setDataToRender(dataToRender2);
     setDataToRenderCopy(dataToRender2);
},[allData,selectedFilter, allPromptsCopy])

    
    //  dataToRender = allData?.[selectedFilter].filter((prompt) => {
    //     return (
    //         (favoriteFilter === "All" ||
    //             (favoriteFilter === "Yes" && favorites.includes(prompt.id)) ||
    //             (favoriteFilter === "No" && !favorites.includes(prompt.id))) 
    //         //     &&
    //         // (categoryFilter === "" || categoryFilter === prompt.category)
    //         // (membershipFilter === "" || prompt.membership === membershipFilter) &&
    //         // (resultTypeFilter === "" || prompt.resultType === resultTypeFilter) &&
    //         // (search === "" || prompt.prompt.toLowerCase().includes(search.toLowerCase()))
    //     );
    // });
    console.log(selectedFilter);
    console.log(allData);

return(
    <>
    <Box>
        {/* <Dialog
        fullScreen
        open={open}
        onClose={onClose}
        TransitionComponent={Transition}
      > */}
        <Box sx={{display:"flex",flexDirection:"column",height:"130vh"}}>
        <AppBar position="static" color="transparent" elevation={0}
                        sx={{ height: "64px", padding: '0px 40px' }}>
                        <Toolbar sx={{
                            display: "flex", justifyContent: "space-between",
                            alignItems: 'center',
                        }}>
                            <IconButton
                                edge="start"
                                color="inherit"
                                onClick={handleBack}
                                aria-label="close"
                                sx={{ width: '60px', height: '60px' }}
                            >
                                <KeyboardBackspaceIcon sx={{ width: '100%', height: '100%' }} />
                            </IconButton>
                            <Typography variant="h6" component="div" sx={{
                                fontFamily: 'sans-serif',
                                fontSize: '40px', fontWeight: 600, lineHeight: '44px', color: '#2861BB'
                            }} id="customized-dialog-title">
                                Prompt Search
                            </Typography>
                        </Toolbar>
</AppBar>
<Divider sx={{ borderColor: '#E0E0E0' }} />
    <Box sx={{display:"flex", flexGrow: 1,overflow:"hidden"}}>
    <Drawer
        sx={{
          width: drawerWidth,
          flexShrink: 0,
          '& .MuiDrawer-paper': {
            width: drawerWidth,
            boxSizing: 'border-box',
            top:"64px",
            marginBottom:"64px"
          },
        }}
        variant="permanent"
        // anchor="left"
      >
          <Divider sx={{ borderColor: '#E0E0E0' }} />
          <Button variant="contained" 
                                sx={{mb: 3, width: '60%', backgroundColor: '#2861BB', color: '#fff', fontWeight: 600, borderRadius: "100px",
                                    textTransform: 'none', boxShadow: 3, marginTop: '40px', marginLeft:'15px', ':hover': {backgroundColor: '#0f4cd1',},
                                }}
                                onClick={()=>{
                                    setOpenMyPromptDialog(true);
                                    modalRef?.current?.clearInput();
                                }}
                                endIcon={<Add />}
                            >New Prompts</Button>
          <List>
              {categories.map((text,index)=>{
                  if(text.type==="heading"){
                      return(
                        //   <Typography
                        //   key={text.label}
                        //   variant="subtitle2"
                        //   sx={{mt:4,mb:1,paddingLeft:'20px',fontWeight:750,fontSize:"20px",color:"#1392D3"}}
                        //   >
                        //       {text.label}
                        //   </Typography>

                       
                        <Box sx={{display:"flex",alignItems:"center",gap:2}}>
                        <ListItem button key={text.label}
                        sx={{
                            paddingTop: '25px !important',
                            
                            
                        }}   
                        onClick={()=>setOpenCategories(!openCategories)}>
                             
                      {text.icon}
                      <ListItemText
                            primary={text.label}
                            primaryTypographyProps={{fontSize:"18px",fontWeight:500,
                            color:"#231E33",paddingLeft:"15px",
                            fontFamily:'"OpenSans",sans-serif'}}
                          
                            
                            />
                            {openCategories ? <ExpandLess/>:<ExpandMore/>}
                        </ListItem>
                      </Box>
                        //     <ListItemIcon>{text.icon}</ListItemIcon>
                        //     <ListItemText
                        //     primary={text.label}
                        //     primaryTypographyProps={{fontSize:"18px",fontWeight:500,
                        //     fontFamily: "Elevance Sans"}}
                          
                            
                        //     />
                        //     {openCategories ? <ExpandLess/>:<ExpandMore/>}
                        // </ListItem>
                      )
                  }
                   const isAfterHeading=index > headingIndex;
                   if(headingIndex !== -1 && isAfterHeading){
                       return(
                           <Collapse in={openCategories} timeout="auto" key={text.label}>
                               <ListItem
                                onClick={()=>{
                                    setSelectedFilter(text.label);
                                    setCopyFilter(text.label);
                                    }} 
                                  sx={{
                                    paddingBottom:'8px !important',
                                    paddingTop: '0 !important',
                                    color:"#231E33",
                                    fontFamily:'"OpenSans",sans-serif',
                                    marginLeft:"30px",
                                    backgroundColor:selectedFilter=== text.label ? '#E3F4FD':'transparent',
                                    '&Mui-selected':{
                                        backgroundColor:'#E3F4FD',
                                        fontweight: 'bold'
                                    },
                                    '&:hover':{
                                        backgroundColor:'#E3F4FD',
                                    }
                                }}  
                               >
                                   {/* <ListItemIcon>{text.icon}</ListItemIcon> */}
                                   <Box sx={{display:"flex",alignItems:"center",gap:1,mt:4}}>
                      {/* {text.icon} */}
                      <ListItemText primary={text.label}
                      primaryTypographyProps={{fontSize:"18px",fontWeight:500,color:"#231E33",
                      fontFamily:'"OpenSans",sans-serif'}}
                      />
                      </Box>
                               </ListItem>
                           </Collapse>
                       )
                   }
                  return(
                  <ListItem
                  button
                  key={text.label}
                  selected={selectedFilter===text.label}
                  onClick={()=>{
                    setSelectedFilter(text.label);
                    setCopyFilter(text.label);
                   
                  }}
                  sx={{
                      paddingBottom:'8px !important',
                      paddingTop: '0 !important',
                      color:"#666666",
                      backgroundColor:selectedFilter=== text.label ? '#E3F4FD':'transparent',
                      '&Mui-selected':{
                          backgroundColor:'#E3F4FD',
                          fontweight: 'bold'
                      },
                      '&:hover':{
                          backgroundColor:'#E3F4FD',
                      }
                  }}
                  >
                      <Box sx={{display:"flex",alignItems:"center",gap:2,mt:4}}>
                      {text.icon}
                      <ListItemText primary={text.label}
                      primaryTypographyProps={{fontSize:"18px",fontWeight:500,color:"#231E33",fontFamily:'"OpenSans",sans-serif'}}
                      />
                      </Box>
                  </ListItem>
                  );
              })}
          </List>
</Drawer>
<Box
component="main"
sx={{
    flexGrow:1,
    p:3,
    overflowY:"auto",
    mt:"64px",
    mb:"64px"
}}
>
{/* <Typography>{contentMap[selected]}</Typography> */}
<Box sx={{display:"flex",gap:2,mb:3}}>
<TextField
                                    sx={{
                                        width: "100%", height: '45px', '& .MuiOutlinedInput-root': {
                                            borderRadius: '50px',
                                            backgroundColor: '#f9f9f9',
                                        },
                                    }}
                                    placeholder="Type Prompt"
                                    value={search}
                                    onChange={handleSearchChange}
                                    variant="outlined"
                                    size="small"
                                    InputProps={{
                                        endAdornment: (
                                            <InputAdornment position="end">
                                                <GridSearchIcon />
                                            </InputAdornment>
                                        ),
                                    }}
                                />
{/* <Button variant="contained">Search</Button> */}
{/* <Button variant="contained" sx={{textTransform:"none"}} >Add Prompt</Button> */}
</Box>
<Box sx={{ display: "flex", gap: 2, mb: 3, width: '20%', paddingTop: '30px' }}>
                                {/* <TextField select label="Favorite Prompt" value={favoriteFilter}
                                    onChange={(e) => setFavoriteFilter(e.target.value)} sx={{ flex: 1 }}>
                                   
                                    <MenuItem value="Yes">Yes</MenuItem>
                                    <MenuItem value="No">No</MenuItem>
                                </TextField> */}

                                {/* <TextField select label="Category"  sx={{ flex: 1 }} >
                                    {uniqueCategories.map((cat, index) => (
                                        <MenuItem key={index} value={cat}>{cat}</MenuItem>
                                    ))}
                                </TextField> */}
                                {/* <TextField label="Membership" value={membershipFilter} onChange={(e) => setMembershipFilter(e.target.value)} sx={{ flex: 1 }} />
                                <TextField label="Result Type" value={resultTypeFilter} onChange={(e) => setResultTypeFilter(e.target.value)} sx={{ flex: 1 }} /> */}
                                {/* <TextField select label="Sort By" value={sortBy} onChange={(e) => setSortBy(e.target.value)} sx={{ flex: 1 }}>
                                    <MenuItem value="Default">Default</MenuItem>
                                    <MenuItem value="Recent">Most Recent</MenuItem>
                                    <MenuItem value="Popular">Most Used</MenuItem>
                                </TextField> */}
                            </Box>
<Grid2 container spacing={3} mt={8}>
    
{dataToRender.map((item)=>(
    <Grid2 item xs={12} md={6} lg={4} key={item?.Id}>
       <Paper elevation={3}
       sx={{
           height:"80px",
           width:"392px",
           p:2,
           position:"relative",
           display:"flex",
           fontFamily: '"OpenSans",sans-serif',
           flexDirection:"column",
           justifyContent:"space-between",
           backgroundColor:"#E3F4FD",
           borderRadius: "20px",
           paddingBottom:"112px !important"
           }}
           onClick={( )=>{
               setSelectedItem(item);
               setOpenDialog(true);
           }}
           >
{/* <Box sx={{display:"flex",flexDirection:"column",justifyContent:"space-between",color:"#1A3673",gap:4}}> */}

<Typography variant="subtitle1" sx={{fontFamily:'"OpenSans",sans-serif',fontSize: "16px"}}>{item?.prompt}</Typography>

<Box sx={{display:"flex",mt:"auto",gap:1,justifyContent:"flex-end",alignItems:"center",
position:"absolute",right:0,bottom:2}}>
{/* <CardContent sx={{padding: '2px !important',color:"#1A3673"}} > */}
    {/* <Box sx={{display:"inline-block",border:"2px solid",borderColor:"primary.main",p:"4px"}}> */}
        <Box sx={{display:selectedFilter!=="My Prompts"?"block":"none",backgroundColor:"#8FD4F8",border:"2px solid",borderColor:"#8FD4F8",px:3,py:0.5,mb:1,borderRadius:1}}>
    <Typography variant="h6" sx={{fontFamily:'"OpenSans",sans-serif',fontSize: "16px",color:"#1A3673"}}>{item?.category}</Typography>
    </Box>
    <Box sx={{mb:1}}>
    {/* </Box> */}
    {selectedFilter!=="My Prompts" ? (
    <IconButton onClick={(e)=> {
        if(selectedFilter==="Favorites" || (toggFav.includes(selectedFilter) && !favorites.includes(item.id))){
    toggleFavorite(item);
   
        }
        e.stopPropagation();
    }}>
{favorites.includes(item.id)?(
<FavoriteIcon sx={{color:"red"}}/>):(
    <FavoriteBorder/>
)}
</IconButton>
): (
    <Box>
         <IconButton onClick={(e)=>{
        e.stopPropagation();
        setOpenMyPromptDialog(true);
        setEditModal(true);
        //setSelectedItem(item);
        setItemDraft(item);
        }}>
        <img src={edit} alt="edit" style={{width:20 }} />
    </IconButton>
    <IconButton sx={{color:"#1A3673"}} onClick={(e)=>{
        e.stopPropagation();
        deleteMyPrompt(item?.id)
        }}>
        <DeleteIcon/>
    </IconButton>
    </Box>
)}

</Box>   

{/* </CardContent> */}
</Box>
{/* </Box> */}
       </Paper>
    </Grid2>
))}
</Grid2>

{dataToRender.length ===0 && (
    <Typography>No result found</Typography>
)}
</Box>
    </Box>
    <Box
    sx={{
        position:"fixed",
        bottom:0,
        width:"100%",
        height:"64px",
       // backgroundColor:"#f5f5f5",
        display:"flex",
        justifyContent:"flex-end",
        alignItems:"center",
        pr:3,
        borderTop:"1px solid #ccc"
    }}
    >
       
    <Button disabled={selectedFilter==="My Prompts"} variant="contained" size="large" sx={{textTransform:"none",marginRight:"10px"}} onClick={saveToFav}>
           Save
    </Button>

    </Box>

        </Box>

      {/* </Dialog> */}
      <Snackbar
      open={ openAlert}
    //   autoHideDuration={3000}
      onClose={()=> setOpenAlert(false)}
      anchorOrigin={{vertical:'bottom',horizontal:'left'}}
      >
      <Alert 
      onClose={()=> setOpenAlert(false)} 
      severity="success" 
      variant="filled"
      sx={{
          fontSize:'1.2rem',
          padding:'16px 24px',
          minWidth:'300px'
      }}
      >
        Prompts are added successfully in the Favorites
      </Alert>
      </Snackbar>
      <Snackbar
      open={ deleteAlert}
      autoHideDuration={3000}
      onClose={()=> setDeleteAlert(false)}
      anchorOrigin={{vertical:'bottom',horizontal:'left'}}
      >
      <Alert 
      onClose={()=> setDeleteAlert(false)} 
      severity="error" 
      variant="filled"
      sx={{
          fontSize:'1.2rem',
          padding:'16px 24px',
          minWidth:'300px'
      }}
      >
        Prompts deleted successfully!!
      </Alert>
      </Snackbar>
      <Snackbar
      open={openMyPromptAlert}
       autoHideDuration={3000}
      onClose={()=> setOpenMyPromptAlert(false)}
      anchorOrigin={{vertical:'bottom',horizontal:'left'}}
      >
      <Alert 
      onClose={()=> setOpenMyPromptAlert(false)} 
      severity="success" 
      variant="filled"
      sx={{
          fontSize:'1.2rem',
          padding:'16px 24px',
          minWidth:'300px'
      }}
      >
        {msg}
      </Alert>
      </Snackbar>
      <PromptDetails 
      open={openDialog} 
      item={selectedItem} 
      onClose={()=>setOpenDialog(false)}
      favorites={favorites}
     // onhandleTry={handleTryPrompt}
    
      />
    </Box>
    <MyPrompts
    ref={modalRef}
    openMyPrompt={openMyPromptDialog} 
    openMyPromptAlert={openMyPromptAlert}
    setOpenMyPromptAlert={setOpenMyPromptAlert}
    editModal={editModal}
    setEditModal={setEditModal}
    setMsg={setMsg}
    //setAllData={setAllData}
    itemDraft={itemDraft} 
    onCloseMyPrompt={()=>setOpenMyPromptDialog(false)}
    //onhandleTry={handleTryPrompt}
  
    />
    </>

)
}

export default PromptSearch;