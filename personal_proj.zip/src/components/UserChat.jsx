import React, { useState, useRef, useLayoutEffect, useEffect } from 'react';
import { useAtom } from 'jotai';
//import { Alert } from 'flowbite-react';
import { FaTelegramPlane } from 'react-icons/fa';
import ChatMessage from './ChatMessage';
import { Box, TextField,Paper, Button, IconButton, Typography, InputAdornment, useTheme,Modal, Backdrop, Fade, Snackbar,Alert} from '@mui/material';
import ChartModal from './ChartModal';
import BarChartIcon from '@mui/icons-material/BarChart';
import { format as sqlFormatter } from 'sql-formatter';
import hljs from 'highlight.js/lib/core';
import sql from 'highlight.js/lib/languages/sql';
import { v4 as uuidv4 } from 'uuid'; // Import uuidv4
import SummaryResponseRenderer from './SummaryResponseRenderer';
import example from '../../src/assets/ChatPageIcon/Example.png';
import conversation from '../../src/assets/ChatPageIcon/LastConversation.png';
import favorite from '../../src/assets/ChatPageIcon/Favorite.png';
import LoadingSpinner from './LoadingSpinner';
import { fetchToken } from "./Auth";
import { useNavigate } from "react-router";
import {chatHistoryAtom, displayPromptsAtom, graphAtom,loadingAtom, myPromptDrawer, myPrompts, sqlResponseAtom} from '../helpers/index.js';
import axios from "axios";
import {DataGrid} from '@mui/x-data-grid';
import ContentCopyIcon from "@mui/icons-material/ContentCopy";
import VisibilityIcon from "@mui/icons-material/Visibility";
import ExpandIcon from '@mui/icons-material/OpenInFull';
import summary from '../../src/assets/ChatPageIcon/summary.png';
import graph from '../../src/assets/ChatPageIcon/graph.png';
import carbon from '../../src/assets/ChatPageIcon/carbon_chat.png';
import favlight from '../../src/assets/ChatPageIcon/carbon_favorite.png';
import examplelight from '../../src/assets/ChatPageIcon/ant-design_robot-outlined.png';
//import { getBaseURLIntelliQ, getBaseURLMedRFE } from "../configLoader";
import MicIcon from '@mui/icons-material/Mic';
import { useAppUrl } from '../helpers/hooks/hooks.jsx';
import { IQPIsqlrun, IQPIfetch, IQPIput, IQPIsummary } from '../service/ApiDataService';
import { ConstructionOutlined, Label } from '@mui/icons-material';
import { config } from '../oktaConfig';
import OktaAuth from '@okta/okta-auth-js';
import { useLogout } from '../helpers/hooks/useLogout.jsx'; 
import { INACTIVITY_TIME } from '../const/constant';
import { useLogin } from '../helpers/hooks/useLogin.jsx';
import TableExpandModal from './TableExpandModal.jsx';
import { StyledDataGrid } from './MyDynamicDataGridcomponent.jsx';


//import { useThemeMode } from "../themes/ThemeContext";





const oktaAuth = (config.oktaConfig && config.oktaConfig.issuer) ? new OktaAuth(config.oktaConfig):null;
hljs.registerLanguage('sql', sql);
function UserChat(props) {
  // Register all Community features
  // ModuleRegistry.registerModules([AllCommunityModule]);
  // ModuleRegistry.registerModules([
  //   ClientSideRowModelModule
  // ]);
 //const theme = useTheme();
  // const isSmallScreen = useMediaQuery(theme.breakpoints.down('sm'));
  // const isMediumScreen = useMediaQuery(theme.breakpoints.between('sm', 'md'));

  const {
    chatLog, setChatLog,
    cortexMessages,
    setCortexMessages,
   // themeColor,
   // responseReceived, setResponseReceived,
    error, setError,
   // chatInitialMessage,
    isLoading, setIsLoading,
    successMessage, 
    //setSuccessMessage,
    showInitialView, setShowInitialView,
    isCollapsed,
    requestId, 
   // setRequestId, 
    apiPath, sqlUrl, appCd, customStyles = 
    {}, chatbotImage, userImage,
    // handleNewChat, suggestedPrompts, showButton, 
     setShowButton, 
    // showExecuteButton, 
     setShowExecuteButton, 
    // showProivdeSummary, 
     setShowProivdeSummary, inputField, setInputChatField,
  } = props;
  
  const endOfMessagesRef = useRef(null);
  const {logout}=useLogout()|| {};
  const {handleLogin} = useLogin()||{};
  const [apiResponse, setApiResponse] = useState(null); // New state for storing API response
  const [input, setInput] = useState('');
//  const layoutWidth = isSmallScreen ? '100%' : isMediumScreen ? '80%' : '70%';
  const inactivityTimeoutRef = useRef(null); // Ref for the inactivity timeout
  const [sessionActive, setSessionActive] = useState(true); // State to track session activity
  const [openPopup, setOpenPopup] = useState(false);
  const [openSummModal,setOpenSummModal]=useState(false);
 
  //const INACTIVITY_TIME = 10 * 1000;
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [storedResponse, setStoredResponse] = useState(''); // New state to store the response
  const [showResponse, setShowResponse] = useState(false);
  const [dataRecords, setDataRecords] = useState([]);
  const [sqlExecutionResults, setSqlExecutionResults] = useState('');
 // const [rawResponse, setRawResponse] = useState('');
  const [rawResponse, setRawResponse] = useAtom(sqlResponseAtom);
  const[sqlPrompt,setSqlPrompt]=useState('');
  const [chatHistory,setChatHistory]=useAtom(chatHistoryAtom);
 // const[myPrompt,setMyPrompt]=useAtom(myPromptDrawer);
  const[,setMyPromptDrawer]=useAtom(myPromptDrawer);
 // const [promptCategories,setPromptCategories]=useAtom(PromptCategoriesAtom);
  const [rows,setRows]=useState([]);
  const [columns,setColumns]=useState([]);
  const [promptDisplay,setPromptDisplay]=useAtom(displayPromptsAtom);
  // const [showGrid,setShowGrid]=useState(false);
  const isOpenTable = useRef(true);
  const [isOpen,setIsOpen]=useState(false);
  const tableDataMapRef = useRef(new Map()); // Stores all tables by gridKey
  const currentModalDataRef = useRef({ rows: [], columns: [] });
  const [modalKey, setModalKey] = useState(null);
  // const [paginationModel,setPaginationModel]=useState({
  //   pageSize:10,
  //   page:0
  // })
  // const API_DEV_URL=process.env.REACT_APP_BASE_URL;
  // const API_PROD_URL=process.env.REACT_APP_PROD_URL;
  // const API_UAT_URL=process.env.REACT_APP_UAT_URL;
  //const baseUrlIntelliQ = useAppUrl();
  const {API_BASE_URL,APP_NAME} =useAppUrl();
  const token=localStorage.getItem('token');
  const profileName=localStorage.getItem('profileName');

  const theme=useTheme();
  let gridKey=0;
  const contentTableRef=useRef();
  const contentSumm=useRef();
  //const [chartData,setChartData]=useAtom(chartAtom);
  const [scrollToBottom, setScrollToBottom] = useState(false);
  const [graphData,setGraphData]=useAtom(graphAtom);
 // const [graphId,setGraphId]=useAtom(graphIDAtom);
  //const [rawPI,setrawPI]=useAtom(rawAtom);
  
  //const API_DEV_URL=process.env.REACT_APP_BASE_URL;
  const bgColor=theme.palette.mode==='dark' ? 'rgba(26, 54, 115, 0.60)':'#E3F4FD';
  const textColor=theme.palette.mode==='dark' ? '#FFF' : '#231E33';
  const textboxColor=theme.palette.mode==='dark' ? '#07093C':'#FFF' ;
  const iconColor=theme.palette.mode==='dark' ? '#44B8F3' : 'rgb(26, 54, 115)';
  const examplesrc= theme.palette.mode==='dark' ? examplelight : example;
  const convsrc=theme.palette.mode==='dark' ? carbon : conversation;
  const favsrc=theme.palette.mode==='dark' ? favlight : favorite;
  const chatMessageRef = useRef();
  const summaryBtnRef=useRef(null);

  const [loading]=useAtom(loadingAtom);
 

  const hasNumericColumn = (row) => {
    return Object.values(row).some(val => typeof val === 'number' || (typeof val=== 'string' && val.includes('$')));
  }

  const headerData=[{
    
    icon: examplesrc,
    title: "Example"
  },{
    
    icon: convsrc,
    title: "Last Conversation"
  },{
    
    icon: favsrc,
    title: "New Added favorite"
  }]
//const app = window.ENV.REACT_APP_NAME;
  
  
  
  const navigate = useNavigate();
  // const handlePromptClick = (prompt) => {
  //   //alert(`Clicked: ${prompt}`);
  //   //$('inputChatTxtFld').val(`${prompt}`);
  //   setInput(`${prompt}`);
  // };

  useEffect(()=>{
   if(isLoading){
    document.querySelectorAll('.summary-btn').forEach((ele)=>{
      ele.disabled=true;
      ele.style.backgroundColor='rgba(0, 0, 0, 0.26)';
      ele.style.cursor="default";
    })
   }
   else{
    document.querySelectorAll('.summary-btn').forEach((ele)=>{
      ele.disabled=false;
      ele.style.backgroundColor="#2861BB";
      ele.style.cursor="pointer";
    })
   }
  },[isLoading])

  useEffect(()=>{
    fetchPrompts();
  },[])

  const fetchPrompts=async()=>{
    const response= await IQPIfetch(token,'/extractAllPrompts/');
    const promptsShuffle=response.data.prompts.sort(()=>0.5-Math.random());
    const displayPrompts=promptsShuffle.slice(0,3);
    // const categories = [...new Set(response.data.prompts.map(p => p.category).filter(Boolean))];
    // const cat=categories.map((ele)=>{
    //   const f=promptCategories.find((e)=>e.label===ele)
    //   if(!f){
    //   return {
    //     label:ele,
    //     icon:<Label/>
    //   }
    // }
    // return null
    // }).filter((x)=>x);
  
    // setPromptCategories((prev)=>[...prev,...cat]);
    // console.log(cat);
    setPromptDisplay(displayPrompts);
 }

  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

  const handleMicClick = () => {
    if(!SpeechRecognition) {
      alert('Speech recognition is not supported in this browser');
      return;
    }
    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';
    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      setInputChatField(prev => prev + '' +transcript);
    };
    recognition.onerror = (event) => {
      console.error('Speech recognition error:', event.error);
    };
    recognition.start();
  }

 
  const getChatHistory=async()=>{
  
  const response= await IQPIfetch(token,'/getUserRecentPrompts/');
// console.log(response,'from line 103');
const transformed=response.data.map((text,index)=>({
      id:Date.now()+index,
      text:[text.prompt]
    }));
    setChatHistory(transformed);
  }

  const getMyPrompts=async()=>{
    const response= await IQPIfetch(token,'/getDraftPrompts/');
// console.log(response,'from line 103');

setMyPromptDrawer(response.data.prompts);
  }

  useEffect(() => {
    if (scrollToBottom) {
      setTimeout(()=>{
      document.querySelector('.scrollable').scrollIntoView();
      setScrollToBottom(false);
    })
    }
  }, [scrollToBottom]);

  useEffect(()=>{
    getChatHistory();
    getMyPrompts();
  },[]);

  useLayoutEffect(() => {
    if (endOfMessagesRef.current) {
      endOfMessagesRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [chatLog]);

  function toggle(key) {
    // setIsOpenTable(!isOpenTable);
    // isOpenTable.current = !isOpenTable.current;
    // setIsOpen(isOpenTable.current);

    const el=document.getElementById(`myGrid-${key}`);
    if(el){
      el.style.display=el.style.display=== 'none' ? 'block' : 'none';
    }
    
    
  }

  const handleGraphClick = (data) => {
   
    // setIsModalVisible(true);
    setDataRecords(data);
    
    // let modelReply;
    // modelReply=(
    //   <Box >
         
    //                 {/* <Box sx={{display:"flex"}}> */}
    //                   {/* <div style={{width:"1100px !important"}}> */}
    //                     <ChartModal chartData={data || []}/>
    //     {/* <HighchartsReact highcharts={Highcharts} options={value} /> */}
    //     {/* </div> */}
    //     {/* </Box> */}
    //   </Box>
    // )
    const botMessage = {
        role: 'assistant',
        content: data,
        sqlprompt:sqlPrompt,
        sqlquery: rawResponse,
        graph: 'graph',
        disableCopy: true,
        disableDownload: true
      };
  
      setChatLog((prevChatLog) => [...prevChatLog, botMessage]); 
     
    
  };

  // const handleModalClose = () => {
  //   setIsModalVisible(false);
   
  // };

  // const handleDataFromModal=(value)=>{
  //   console.log('userchat3',value);
  //   setIsModalVisible(false);
  //   let modelReply;
  //   modelReply=(
  //     <Box sx={{width:'1065px'}}>
  //         <Typography style={{color: `${textColor} !important`,
  //                 fontSize: "16px",
  //                 fontStyle: "normal",
  //                 fontWeight: 500,
  //                 lineHeight: "20px",
  //                 paddingBottom: "18px"
  //               }}>
  //                 Here is the Visualization.
  //                 </Typography>
  //      <Box sx={{ display: 'flex',height:"55px",borderRadius: "10px 10px 0px 0px", boxShadow: 1,flexDirection:'row', justifyContent: 'space-between', alignItems: 'center', bgcolor: '#666', px: 2, py: 1 }}>
  //                   <Typography color="white" fontSize={14} fontWeight={500}>Top 10 Data Point</Typography>
  //                   <Box >
  //                   <IconButton size="small" sx={{ color: 'white',mr:2 }} >
  //                   <VisibilityIcon fontSize="small" />
  //                   </IconButton>
  //                   <IconButton size="small" sx={{ color: 'white' }} onClick={()=>setIsModalVisible(true)}>
  //                   <ContentCopyIcon fontSize="small" />
  //                   </IconButton>
  //                   </Box>
  //                   </Box>
  //                   <Box sx={{display:"flex"}}>
  //                     <div style={{width:"1100px !important"}}>
  //                       <ChartModal chartData={dataRecords || []}/>
  //       {/* <HighchartsReact highcharts={Highcharts} options={value} /> */}
  //       </div>
  //       </Box>
  //     </Box>
  //   )
  //   const botMessage = {
  //       role: 'assistant',
  //       content: modelReply,
  //       // disableCopy:true
  //     };
  
  //     setChatLog((prevChatLog) => [...prevChatLog, botMessage]); 
  // }
  // Handle session end due to inactivity
  const handleSessionEnd = () => {
    setSessionActive(false);
    setChatLog([...chatLog, { role: 'assistant', content: 'Session has ended due to inactivity.' }]);
    setOpenPopup(true); // Show the popup
  };

  // Start or reset the inactivity timer
  const resetInactivityTimeout = () => {
    if (inactivityTimeoutRef.current) {
      clearTimeout(inactivityTimeoutRef.current);
    }

    inactivityTimeoutRef.current = setTimeout(() => {
      handleSessionEnd(); // End session after 60 minutes of inactivity
    }, INACTIVITY_TIME);
  };

  const sessionEndHandleBtnClick = async() => {
      localStorage.clear();
      localStorage.removeItem("okta-token-storage");
      localStorage.removeItem("okta-cache-storage");
      logout();
      handleLogin()
       navigate("/")
      setOpenPopup(false);  // Close modal
  };




  async function handleSubmit(e) {
    e.preventDefault();
    const question = inputField === null || inputField === undefined || inputField === '' ? input : inputField

    //alert('input : '+question)

    // Prevent empty messages
    
    if (!question.trim()) return;
    if (!appCd.trim() || !requestId.trim()) {
      setError('Please provide valid app_cd and request_id.');
      return;
    }
    const token = fetchToken();

    const newMessage = {
      role: 'user',
      content: question,
      isSQLResponse : false
    };

    
    const cortexMessage = {"role": "user", "content": [{"type": "text", "text": question}]}
    
    cortexMessages.push(cortexMessage);
    // chatHistory=cortexMessage.content.map((x=>x.text));
    // setChatHistory(chatHistory);
    const text=cortexMessage.content.map((x=>x.text));
    
    if(text){
      const newMessage={
        id:Date.now(),
        text,
      }
      setChatHistory((prev)=>[newMessage,...prev]);
    }
    //setCortexMessages(newCortexMessages);   

    const newChatLog = [...chatLog, newMessage]; // Add user's message to chat log
    setChatLog(newChatLog);
    setInput(''); // Clear the input field
    setInputChatField('');
    setIsLoading(true); // Set loading state
    setError(''); // Clear any previous error
    setShowInitialView(false);
    setShowResponse(false);
    setShowButton(false);
    setShowExecuteButton(false);
    setShowProivdeSummary(false);

    try {
      // Dynamic API URL based on user inputs
      const queryParams={
        app_cd:appCd,
        request_id:requestId
      }
      const body=JSON.stringify([cortexMessage])
      // const url = `${apiPath}?app_cd=${appCd}&request_id=${requestId}`;
      const response= await IQPIput(token,apiPath,queryParams,body);
      // const response = await fetch(
      //   url,
      //   {
      //     method: 'PUT',
      //     headers: {
      //       'Content-Type': 'application/json',
      //       "Authorization": `Bearer ${token}`
      //     },
      //     body: JSON.stringify([cortexMessage]),
      //   }
      // );

      // Check if response is okay
      if (response.status !== 200) {
        let errorMessage = '';

        // Handle different status codes
        if (response.status === 404) {
          errorMessage = '404 - Not Found';
        } else if (response.status === 500) {
          errorMessage = '500 - Internal Server Error';
        } else {
          errorMessage = `${response.status} - ${response.statusText}`;
        }

        // // Display the image and error message
        const botMessage = {
          role: 'assistant',
          type: 'error',
          content: (
            <div style={{ display: 'flex', alignItems: 'center', flexDirection: 'column' }}>
              <p style={{ fontFamily:'"OpenSans",sans-serif',fontSize: '1.1 rem', fontWeight: 400, textAlign: 'center' }}>{errorMessage}</p>
            </div>
          ),
        };

        setChatLog([...newChatLog, botMessage]); // Update chat log with assistant's error message
        throw new Error(errorMessage); // Re-throw the error for logging purposes
      }
      
       const data = response.data;
    //   const data = {
    //     "sql": true,
    //     "type": "Display all available Lines of Business (LOB)",
    //     "modelreply": "WITH\r\n __ddim_mbu_cf AS (\r\n  SELECT\r\n   lob_long_desc,\r\n   snap_year_mnth_nbr\r\n  FROM\r\n   s01_edm_v3.edm_v3_nophi_nogbd.ddim_mbu_cf\r\n )\r\nSELECT DISTINCT\r\n d.lob_long_desc\r\nFROM\r\n __ddim_mbu_cf AS d\r\n\r\nWHERE d.snap_year_mnth_nbr =202505 and \r\n NOT d.lob_long_desc IN ('Line Of Business Not Mapped')\r\nORDER BY\r\n d.lob_long_desc\r\n -- Generated by Cortex Analyst\r\n;",
    //     "source": "cache",
    //     "prompt": "Display all available Lines of Business (LOB)",
    //     "content": null
    // }
      
      setApiResponse(data);

      // Function to convert object to string (if needed)
      const convertToString = (input) => {
        if (typeof input === 'string') {
          return input;
        } else if (Array.isArray(input)) {
          // Recursively convert array items
          return input.map(convertToString).join(', ');
        } else if (typeof input === 'object' && input !== null) {
          // Convert key-value pairs
          return Object.entries(input)
            .map(([key, value]) => `${key}: ${convertToString(value)}`)
            .join(', ');
        }
        return String(input);
      };

      // Determine how to handle the response
      let isSQLResponse = false;
      let modelReply = 'No valid reply found.'; // Default message
      if (data.modelreply) {
        // Check if the response is a JSON array of objects
        if (Array.isArray(data.modelreply) && data.modelreply.every(item => typeof item === 'object')) {
          const columnCount = Object.keys(data.modelreply[0]).length;
          const rowCount = data.modelreply.length;
          // Convert to table-like format with borders for display
          modelReply = (
            <div style={{ display: 'flex', alignItems: 'start' }}>
              <table style={{ borderCollapse: 'collapse', width: '100%' }}>
                <thead>
                  <tr>
                    {Object.keys(data.modelreply[0]).map((key) => (
                      <th key={key} style={{ border: '1px solid black', padding: '8px', textAlign: 'left' }}>{key}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {data.modelreply.map((row, rowIndex) => (
                    <tr key={rowIndex}>
                      {Object.values(row).map((val, colIndex) => (
                        <td key={colIndex} style={{ border: '1px solid black', padding: '8px' }}>{convertToString(val)}</td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
              {(rowCount > 1 && columnCount > 1) && (
                <Button
                  variant="contained"
                  color="primary"
                  startIcon={<BarChartIcon />}
                  sx={{ display: 'flex', alignItems: 'center', padding: '8px 16px', marginLeft: '15px', width: '190px', fontSize: '10px', fontWeight: 'bold' }}
                  // onClick={()=>handleGraphClick(requestId)}
                >
                  Graph View
                </Button>
              )}
            </div>
          );
        } else if ((typeof data.modelreply === 'string') && (data.sql) ) {
          const sqlRegex = /```sql([\s\S]*?)```/g;
          const parts = [];
          let lastIndex = 0;
          let match;

          // Split the response into SQL and text
          while ((match = sqlRegex.exec(data.modelreply)) !== null) {
            // Add the text before the SQL block
            if (match.index > lastIndex) {
              parts.push(
                <p key={`text-${lastIndex}`} style={{ fontFamily:'"OpenSans",sans-serif',fontSize: '1.1 rem', fontWeight: 400,margin: "8px 0", width: "100%" }}>
                  {data.modelreply.slice(lastIndex, match.index).trim()}
                </p>
              );
            }

            // Format the SQL block
            const sqlContent = match[1].trim();
            try {
              parts.push(
                <pre key={`sql-${match.index}`} style={{ fontFamily:'"OpenSans",sans-serif',fontSize: '1.1 rem', fontWeight: 400,margin: '8px 0' }}>
                  <code style={{ whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>
                    {sqlFormatter(sqlContent)}
                  </code>
                </pre>
              );
            } catch (err) {
              console.error("SQL Formatting Error:", err);
              parts.push(
                <pre key={`sql-${match.index}`} style={{ fontFamily:'"OpenSans",sans-serif',fontSize: '1.1 rem', fontWeight: 400,margin: '8px 0', color: 'red' }}>
                  {sqlContent}
                </pre>
              );
            }

            lastIndex = sqlRegex.lastIndex;
          }
          // if (lastIndex < data.modelreply.length) {
          //   parts.push(
          //     <p key={`text-${lastIndex}`} style={{ margin: "8px 0" }}>
          //       {data.modelreply.slice(lastIndex).trim()}
          //     </p>
          //   );
          // }

          if (lastIndex < data.modelreply.length) {
            const cortexMessage = {
              role: 'analyst',
              content: data.content,
            };

            cortexMessages.push(cortexMessage);
            setCortexMessages(cortexMessages);

            const remainingContent = data.modelreply.slice(lastIndex).trim();
            if (/SELECT|WHERE|FROM/i.test(remainingContent)) {
              // Treat remaining content as SQL
              try {
                parts.push(
                  <pre key={`sql-remaining`} style={{ margin: '25px 40px' }}>
                    {/* <div style={{ backgroundColor: '#2e2920', borderRadius: '10px', wordWrap:'break-word', width: '100%', whiteSpace : 'pre-wrap', wordBreak: 'break-word', padding: "10px" }}> */}
                      <div style={{fontFamily:'"OpenSans",sans-serif',fontSize: '1.1 rem', fontWeight: 400, color: 'gray', whiteSpace : 'pre-wrap', wordBreak: 'break-word' }}>
                      {data.type}
                      </div>
                    {/* </div> */}
                    <br></br>
                    <code style={{ fontFamily:'"OpenSans",sans-serif',fontSize: '1.1 rem', fontWeight: 400,whiteSpace: 'pre-wrap', wordBreak: 'break-word', background: '#E3F4FD' }}>
                      {sqlFormatter(remainingContent)}
                    </code>
                  </pre>
                );
              } catch (err) {
                console.error("SQL Formatting Error:", err);
                parts.push(
                  <pre key={`sql-remaining`} style={{ fontFamily:'"OpenSans",sans-serif',fontSize: '1.1 rem', fontWeight: 400,margin: '8px 0', color: 'red' }}>
                    {remainingContent}
                  </pre>
                );
              }
            } else {
              // Add remaining text as-is
              parts.push(
                <p key={`text-${lastIndex}`} style={{ fontFamily:'"OpenSans",sans-serif',fontSize: '1.1 rem', fontWeight: 400,margin: "8px 0" }}>
                  {remainingContent}
                </p>
              );
            }
            setShowResponse(true);
          }
          modelReply = (
            <div style={{ overflow: "auto", maxWidth: "100%", padding: "10px" }}>
              {parts}
            </div>
          );
          const raw = data.modelreply;
          setRawResponse(raw);
          setSqlPrompt(data.prompt);
          setStoredResponse(modelReply)
          // setStoredResponse(modelReply);
          setShowButton(true); // Show "Show SQL" button
          setShowExecuteButton(true); // Show "Execute SQL" button
          const finalbotMessage = {
            role: 'assistant',
            content: modelReply,
            isSQLResponse: true,
            type: data.type,
            prompt: data.prompt,
            query: data.modelreply,
            source: data.source,
            rawResponse:raw
          };
          setChatLog((prevChatLog) => [...prevChatLog, finalbotMessage]);
          if(APP_NAME === 'intelliq'){
            setShowResponse(true);
          }
           else {
            if(chatMessageRef.current?.closeSQLBox){
              chatMessageRef.current.closeSQLBox();
            }
            //sessionStorage.setItem('Query', raw);
            //setrawPI(raw);
            //setRawResponse(raw);
            //console.log(rawPI);
            await executeSQLHandleButtonClick(raw);
            setShowResponse(false);
            setShowButton(true);
           }
        } 
        else {
          // Otherwise, convert to string
          modelReply = convertToString(data.modelreply);
          const botMessage = { role: 'assistant', content: modelReply, isSQLResponse, };
          setChatLog([...newChatLog, botMessage]);

          const cortexMessage = {
            role: 'assistant',
            content: modelReply,
          };

          const newCortexMessages =  [...cortexMessages, cortexMessage];
          setCortexMessages(newCortexMessages);
        }
      }
    } catch (err) {
      let fallbackErrorMessage = 'We could not proccess your query right now. Please try again after sometime';
      const errorMessage = {
        role: 'assistant',
        type: 'error',
        content: (
          <div style={{ display: 'flex', alignItems: 'center', flexDirection: 'column' }}>
            <p style={{ fontFamily:'"OpenSans",sans-serif',fontSize: '1.1 rem', fontWeight: 400, textAlign: 'center' }}>{fallbackErrorMessage}</p>
          </div>
        ),
      };

      setChatLog([...newChatLog, errorMessage]);
      setError('We could not proccess your query right now. Please try again after sometime');
      
    
    } finally {
      setIsLoading(false); // Set loading state to false
    }
  }
  
  const handleInputFocusOrChange = () => {
    setShowInitialView(false);
    resetInactivityTimeout();
  };

  const formatAllDataForClipboard = (mainTitle, grids) => {
    const formattedGrids = grids
      .map((grid) => {
        const { columnData, referralList } = grid;

        // Calculate the maximum width for each column
        const colWidths = columnData.map((col) => {
          return Math.max(
            col.headerName.length,
            ...referralList.map((row) => (row[col.field] || '').length),
          );
        });

        // Function to pad strings manually
        const padString = (str, length) => {
          return str + ' '.repeat(length - str.length);
        };

        // Format the headings with proper alignment
        const headings = columnData
          .map((col, index) => padString(col.headerName, colWidths[index]))
          .join('\t');

        // Format each row with proper alignment
        const rows = referralList
          .map((row) => {
            return columnData
              .map((col, index) =>
                padString(row[col.field] || '', colWidths[index]),
              )
              .join('\t');
          })
          .join('\n');

        return `${headings}\n${rows}`;
      })
      .join('\n\n');

    return `${mainTitle}\n\n${formattedGrids}`;
  };

  const copyToClipboard=(column,row)=>{
    const mainTitle = 'Table Data';
    const grids = [
      {
        columnData: column,
        referralList: row,
      },
    ];
    const formattedData = formatAllDataForClipboard(mainTitle, grids);
    navigator.clipboard.writeText(formattedData);
    //const text=codeRef.current.textContent;
   // navigator.clipboard.writeText(text);
      //console.log('from chat bubble',text);
  
  }

  useEffect(() => {
    resetInactivityTimeout();
    return () => {
      if (inactivityTimeoutRef.current) clearTimeout(inactivityTimeoutRef.current);
    };
  });

  const executeSQLHandleButtonClick = async (rawVariable) => {
    try {
      setIsLoading(true); // Set loading state
      setShowExecuteButton(false);
      setShowButton(false);
      const sanitizeQuery = (query) => {
        // Example: Remove line breaks, extra spaces, and other unnecessary parts
        let cleanedQuery = query
          .replace(/\\n/g, ' ')
          .replace(/\s+/g, ' ')
          .replace(/--.*?;/g, '')
          .trim();
        return cleanedQuery;
      };
      
      // const decodedStoredResponse = rawResponse ? encodeURIComponent(rawResponse): encodeURIComponent(sessionStorage.getItem('Query'));
      // const encodedResponse = sanitizeQuery(decodedStoredResponse); // Encode the storedResponse
        // const executeQuery= APP_NAME === 'intelliq' ? rawResponse : rawVariable
        const executeQuery=  rawVariable;
      //const graphResponse = await fetch('/mockGraph.json');
      const queryParams={
        app_cd:appCd,
        request_id:requestId,
        exec_query: executeQuery
      }
     // const sqlQueryUrl = `${sqlUrl}?app_cd=${appCd}&request_id=${requestId}&exec_query=${encodedResponse}`;
      const token = fetchToken();
      const response= await IQPIsqlrun(token,sqlUrl,queryParams);
      // const response = await fetch(sqlQueryUrl, {
      //   method: 'POST',
      //   headers: {
      //     'Content-Type': 'application/json',
      //     "Authorization": `Bearer ${token}`
      //   },
      // });

      // Check if response is okay
      if (response.status !== 200) {
        let errorMessage = '';

        // Handle different status codes
        if (response.status === 404) {
          errorMessage = '404 - Not Found';
        } else if (response.status === 500) {
          //errorMessage = '500 - Internal Server Error';
          const response_data = response.data;
          errorMessage = response_data.detail;
        } else {
          errorMessage = `${response.status} - ${response.statusText}`;
        }

        // Create an error message object
        const errorMessageContent = {
          role: 'assistant',
          type: 'error',
          content: (
            <div style={{ display: 'flex', alignItems: 'center', flexDirection: 'column' }}>
              <p style={{ fontFamily:'"OpenSans",sans-serif',fontSize: '1.1 rem', fontWeight: 400, textAlign: 'justify' }}>{errorMessage}</p>
            </div>
          ),
        };

        setChatLog((prevChatLog) => [...prevChatLog, errorMessageContent]); // Update chat log with assistant's error message
        //throw new Error(errorMessage); // Re-throw the error for logging purposes

      }
      else 
      {



        //const response_data = await graphResponse.json();
         const response_data =  response.data;
         const data = response_data.results
        //console.log(data);
        setSqlExecutionResults(data)
        //setDataRecords(data);
        
        // Function to convert object to string
        const convertToString = (input) => {
          if (typeof input === 'string') {
            return input;
          } else if (Array.isArray(input)) {
            return input.map(convertToString).join(', ');
          } else if (typeof input === 'object' && input !== null) {
            return Object.entries(input)
              .map(([key, value]) => `${key}: ${convertToString(value)}`)
              .join(', ');
          }
          return String(input);
        };

        // Handle the response data similarly to handleSubmit
        let modelReply = 'Not able to Extract Results at this time .'; // Default message
        
        const rowData = data;
        
        // Define the formatNumber function
        const formatNumber = (number) => {
          return new Intl.NumberFormat('en-US', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
          }).format(number);
        };
        const formatRow = (row) => {
          const formattedRow = {};
          // debugger;
          for (const key in row) {
            if (typeof row[key] === 'number' && (key.toLowerCase().includes('amt') || key.toLowerCase().includes('amount'))) {
              formattedRow[key] = `$${formatNumber(row[key])}`;
            }
            else if ((typeof row[key] === 'number') && ((key.toLowerCase().includes('pct')) || (key.toLowerCase().includes('percentage')))) {
              formattedRow[key] = `${formatNumber(row[key])}%`;
            }
            //else if ((typeof row[key] === 'number') && !(key.toLowerCase().includes('mnth')) ) {
            else if ((typeof row[key] === 'number') && !(key.toLowerCase().includes('mnth')) && !(key.toLowerCase().includes('year'))) {
              formattedRow[key] = formatNumber(row[key]);
            }
            else {
              formattedRow[key] = row[key];
            }
          }
          return formattedRow;
        };

        // function convertToDictList(values, rows) {
        //   return values.map(value => {
        //     const isNumber = rows.some(row => typeof row[value] === 'number');
        //     const containsAmount = value.toLowerCase().includes('amt') || value.toLowerCase().includes('amount');

        //     if (containsAmount) {
        //       return { field: value, headerName: value, align: 'left' };
        //     } else if (isNumber) {
        //       return { field: value, headerName: value, align: 'right' };
        //     } else {
        //       return { field: value, headerName: value, align: 'left' };
        //     }
        //   });
        // }

        
        //const colDefs = convertToDictList(response_data.columns, rowData);
        
        const gridRows = rowData.map((row, index) => {
          //const id = uuidv4(); // or use index if you prefer
          //console.log(`Row ID: ${id}`);
          const formattedRow = formatRow(row);
          return formattedRow;
          });
        
        
        let globalRows=[];
        let globalColumns=[];
       

// Column Definitions: Defines the columns to be displayed.

        if (data && data.length > 0) {
          
          
          // Check if the response is a JSON array of objects
          if (Array.isArray(data) && data.every(item => typeof item === 'object') && data.length>0) {
            const dynamicColumns=Object.keys(data[0]).map((key)=>({
              field:key,
              headerName:key,
              width:180,
              flex:1
            }));
            setColumns(dynamicColumns);
            globalColumns=dynamicColumns;
            const processedRows=data.map((row,index)=>({
              id:index+1,
              ...row,
            }));
            const currentGridKey = uuidv4();

            tableDataMapRef.current.set(currentGridKey, {
            rows: processedRows,
            columns: dynamicColumns
          });
            
            setRows(processedRows);
            globalRows=processedRows;
            

            
            const columnCount = Object.keys(data[0]).length;
            const rowCount = data.length;
            // const defaultColDef = {
            //   flex: 1,
            // };
        //     const convertToString_table = (val, key) => {
        //       if ((typeof val === 'number') && (!(key.toLowerCase().includes('mnth'))) && (!(key.toLowerCase().includes('year')))) {
        //         return new Intl.NumberFormat('en-US', {
        //             minimumFractionDigits: 2,
        //             maximumFractionDigits: 2
        //         }).format(val);
        //     }
        //     return val;
        // };
//  ++gridKey;
  gridKey = uuidv4();
  
// ++myKey;
          // Convert to a table-like format with borders for display
          modelReply = (
    // setShowGrid(true)
    
    <>
    
       <Box sx={{width:'1150px'}} ref={contentTableRef} key={gridKey}>
         
                <Typography style={{color: `${textColor} !important`,
                  fontSize: "16px",
                  fontStyle: "normal",
                  fontWeight: 500,
                  lineHeight: "20px",
                  paddingBottom: "18px"
                }}>
                  Here is the Data Table.
                  </Typography>
       <Box sx={{ display: 'flex',height:"55px",borderRadius: "10px 10px 0px 0px", boxShadow: 1,flexDirection:'row', justifyContent: 'space-between', alignItems: 'center', bgcolor: '#666', px: 2, py: 1 }}>
                    <Typography color="white" fontSize={14} fontWeight={500}>Table</Typography>
                    <Box >
                      <IconButton
                      size="small"
                      sx={{ color: "white", mr: 2 }}
                      onClick={() => {
                        // ✅ Retrieve THIS table's data from Map
                        const tableData = tableDataMapRef.current.get(currentGridKey);
                        console.log('Opening modal for key:', currentGridKey);
                        console.log('Table data:', tableData);
                        
                        if (tableData) {
                          currentModalDataRef.current = tableData;
                          setModalKey(currentGridKey);
                          setIsOpen(true);
                        }
                      }}
                    >
                      <ExpandIcon fontSize="small" />
                    </IconButton>

                    <IconButton size="small" sx={{ color: 'white',mr:2 }} onClick={()=>toggle(gridKey)}>
                    <VisibilityIcon fontSize="small" />
                    </IconButton>
                    <IconButton size="small" sx={{ color: 'white' }} onClick={()=>copyToClipboard(dynamicColumns,processedRows)}>
                    <ContentCopyIcon fontSize="small" />
                    </IconButton>
                    </Box>
                    </Box>
                    <Box sx={{display:'flex',flexDirection:'column'}}>
                      {/* {isOpen && */}
         <Box sx={{height:"auto",overflow:'hidden'}}>   
      {processedRows.length>0 && dynamicColumns.length>0  ?(
        <div id={`myGrid-${gridKey}`} >
                 <StyledDataGrid
                          key={processedRows?.id}
                          rows={processedRows}
                          columns={dynamicColumns}
                          disableRowSelectionOnClick
                          pagination
                          initialState={{
                            pagination: { paginationModel: { pageSize: 10 } },
                          }}
                          pageSizeOptions={[10, 15, 20]}
                        />
            </div>   
      ) :(
       <Typography>Loading Data</Typography>
      )
      }
      </Box>  
          {/* }   */}
      </Box>
      {(APP_NAME!=='intelliq'|| (rowCount > 1 && columnCount > 1)) && (
      <Box>
      <Typography style={{
                    color: `${textColor} !important`,
                    fontSize: "16px",
                    fontStyle: "normal",
                    fontWeight: 500,
                    lineHeight: "20px",
                    paddingTop:"18px"
                  }}>
                    Other View Options:
                    </Typography>
                    <Box sx={{display:"flex",justifyContent:"left",gap:"20px",marginTop:"30px"}}>
                    {/* <Button sx={{textTransform:'none'}} variant="contained" startIcon={<img src={data} alt="data" style={{width:24,height:24 }} />} onClick={executeSQLHandleButtonClick}>
                      View Data
                      </Button> */}
                      {(hasNumericColumn(data[0]) && rowCount>1 && columnCount>1) && (
                    <Button className='summary-btn' sx={{textTransform:'none',backgroundColor:"#2861BB",color:"#FFF"}} variant="contained" startIcon={<img src={graph} alt="data" style={{width:24,height:24 }}/>}  
                    onClick={()=>handleGraphClick(data)}
                    >
                      View Graph
                        </Button>
                      )}
                    <Button ref={summaryBtnRef} className='summary-btn' sx={{textTransform:'none',backgroundColor:"#2861BB",
                    color:"#FFF"}} variant="contained" startIcon={<img src={summary} alt="data" style={{width:24,height:24 }}/>} 
                    onClick={()=>generateSummaryHandleButtonClick(data)}
                    >
                      View Summary
                      </Button>
                    </Box>
      </Box>
      )}
      </Box>
    </> 
    
    
           
            );
            setScrollToBottom(true);
           // setShowProivdeSummary(true);
          } else if (typeof data === 'string') {
            // If it's a string, display it as text and store it in the state
            modelReply = data;
            //setStoredResponse(data);
            setIsLoading(true);
          } else {
            // Otherwise, convert to string
            modelReply = convertToString(data);
          }
        }
        else {
          modelReply = 'Query produced no results';
          setShowProivdeSummary(false);
        }

        const botMessage = {
          role: 'assistant',
          content: modelReply,
          sqlprompt:sqlPrompt,
          sqlquery: rawResponse,
          data:"data",
          rows:globalRows,
          columns:globalColumns
        };

        setChatLog((prevChatLog) => [...prevChatLog, botMessage]); // Update chat log with assistant's message
        
      }
    } catch (err) {
      // Handle network errors or other unexpected issues
      const fallbackErrorMessage = 'We could not fetch the results right now. Please try again after sometime';
      const errorMessageContent = {
        role: 'assistant',
        type: 'error',
        content: (
          <div style={{ display: 'flex', alignItems: 'center', flexDirection: 'column' }}>
            <p style={{ fontFamily:'"OpenSans",sans-serif',fontSize: '1.1 rem', fontWeight: 400, textAlign: 'center' }}>{fallbackErrorMessage}</p>
          </div>
        ),
      };

      setChatLog((prevChatLog) => [...prevChatLog, errorMessageContent]); // Update chat log with assistant's error message
      //console.error('Error:', err); // Log the error for debugging
      
     // setShowProivdeSummary(false);
    } finally {
      setIsLoading(false);// Set loading state to false
      setShowExecuteButton(false);
      setShowButton(false);
      //setShowProivdeSummary(false);
    }
  }
  const generateSummaryHandleButtonClick = async (data) => {
    try {
      if(data.length > 100 && APP_NAME!=='intelliq'){
        setOpenSummModal(true);
      }
      else{
      setIsLoading(true); // Set loading state
      console.log('from line 793',data);
      //setShowProivdeSummary(false);
      // Function to convert object to string
      const convertToString1 = (input) => {
        if (typeof input === 'string') {
          return input;
        } else if (Array.isArray(input)) {
          return input.map(convertToString1).join(', ');
        } else if (typeof input === 'object' && input !== null) {
          return Object.entries(input)
            .map(([key, value]) => `${key}: ${convertToString1(value)}`)
            .join(', ');
        }
        return String(input);
      };
      const dataRecords_str = convertToString1(data);
      const payload={
        prompt_message:dataRecords_str,
        request_id: '1234'
      }
     //const sqlQueryUrl = `${API_BASE_URL}/generateSummary/?prompt_message=${dataRecords_str}&request_id=1234`;
      const response= await  IQPIsummary("/generateSummary/",payload);
      // await fetch(sqlQueryUrl, {
      //   method: 'POST',
      //   headers: {
      //     'Content-Type': 'application/json',
      //   },
      // });

      // Check if response is okay
      if (!response.status===200) {
        let errorMessage = '';

        // Handle different status codes
        if (response.status === 404) {
          errorMessage = '404 - Not Found';
        } else if (response.status === 500) {
          errorMessage = '500 - Internal Server Error';
        } else {
          errorMessage = `${response.status} - ${response.statusText}`;
        }

        // Create an error message object
        const errorMessageContent = {
          role: 'assistant',
          type: 'error',
          content: (
            <div style={{ display: 'flex', alignItems: 'center', flexDirection: 'column' }}>
              <p style={{ fontFamily:'"OpenSans",sans-serif',fontSize: '1.1 rem', fontWeight: 400, textAlign: 'center' }}>{errorMessage}</p>
            </div>
          ),
        };

        setChatLog((prevChatLog) => [...prevChatLog, errorMessageContent]); // Update chat log with assistant's error message
        throw new Error(errorMessage); // Re-throw the error for logging purposes
      }

      const resSummary=  response.data;
      const summary_data = resSummary.summary;
      //setSummType(resSummary.type);
      let modelReply = 'No valid reply found.'; // Default message

      if (summary_data) {
        // Check if the response is a JSON array of objects
        if (typeof summary_data === 'string') {

          // Convert to a table-like format with borders for display
          modelReply = (
            <div style={{ display: 'flex', alignItems: 'start' }}>
              {summary_data && (
                <div style={{ textWrap:'wrap',wordBreak:'break-word',fontFamily:'"OpenSans",sans-serif',fontSize: '1.1 rem', fontWeight: 400, }} key={uuidv4} ref={contentSumm}>
                  {/* <h3>Summary :</h3> */}
                  {/* <pre > */}
                    {/* {summary_data} */}
                    <SummaryResponseRenderer response={summary_data} />
                  {/* </pre> */}
                </div>)
              }
            </div>
          );
        }
        else {
          // Otherwise, convert to string
          modelReply = convertToString1(summary_data);
        }
      }

      const botMessage = {
        role: 'assistant',
        content: modelReply,
        sqlprompt:sqlPrompt,
        sqlquery: rawResponse,
        summary: 'summary',
        summaryData:summary_data
      };

      setChatLog((prevChatLog) => [...prevChatLog, botMessage]);
    } // Update chat log with assistant's message
} catch (err) {
      // Handle network errors or other unexpected issues
      const fallbackErrorMessage = 'We could not fetch the summary right now. Please try again after sometime';
      const errorMessageContent = {
        role: 'assistant',
        type: 'error',
        content: (
          <div style={{ display: 'flex', alignItems: 'center', flexDirection: 'column' }}>
            <p style={{ fontFamily:'"OpenSans",sans-serif',fontSize: '1.1 rem', fontWeight: 400, textAlign: 'center' }}>{fallbackErrorMessage}</p>
          </div>
        ),
      };

      setChatLog((prevChatLog) => [...prevChatLog, errorMessageContent]); // Update chat log with assistant's error message
      console.error('Error:', err); // Log the error for debugging
      console.error('Stack trace:', error.stack);
} finally {
      setIsLoading(false);// Set loading state to false
      //setShowExecuteButton(false);
      //setShowButton(false);
     // setShowProivdeSummary(false);
    }
  }
  // function handleShowResponse() {
  //   setShowResponse((prev) => {
  //     const newVisibility = !prev; // Toggle SQL response visibilit
  //     if (newVisibility) {
  //       const botMessage = {
  //         role: 'assistant',
  //         content: storedResponse,
  //       };

  //       setChatLog((prevChatLog) => [...prevChatLog, botMessage]);
  //     } else {
  //       setChatLog((prevChatLog) => {
  //         if (prevChatLog.length > 0 && prevChatLog[prevChatLog.length - 1].role === 'assistant') {
  //           return prevChatLog.slice(0, prevChatLog.length - 1);
  //         }
  //         return prevChatLog;
  //       });
  //     }

  //     return newVisibility;
  //   });
  // }


  return (
<Box
sx={{
  marginTop: "49px",
  height: "115vh",
  display:"flex",
  flexDirection:"column"
}}>
{showInitialView && (
        <>
          <Box
          sx={{
            display:"flex",
            flexDirection:"column",
            maxHeight: '100vh',
            alignItems:"center",
            padding:4,
            gap:4
          }}
          >
            <Box sx={{marginRight:"60px",}}>
              <Typography variant="h4" sx={{color:"#2861BB",marginTop: "23px",fontSize: "46px",fontStyle: "normal",fontWeight: 600,lineHeight: "48px"}} gutterBottom>
                Welcome, {profileName}
                </Typography>
              <Typography variant="h6" sx={{color:textColor,marginTop: "23px",fontSize: "46px",fontStyle: "normal",fontWeight: 600,lineHeight: "48px"}}>
                I am your Chat Assistant
                </Typography>
              <Typography variant="subtitle1" sx={{color:textColor,marginTop: "23px",fontSize: "46px",fontStyle: "normal",fontWeight: 600,lineHeight: "48px"}}>
                How can I help you today?
                </Typography>
            </Box>
            <Box sx={{
              display:"flex",
              justifyContent:"center",
              marginTop:"40px",
              gap:4,
              flexWrap:"wrap"
            }}>
              {headerData.map((data,index)=>(
                <Box sx={{alignItems:"center",display:"flex",flexDirection:"column",gap:2}}>
              {/* <img src={example} alt="gcp" style={{width:40 }}/> */}
              <Box component="img" src={data.icon} alt="logo"/>
              <Typography sx={{
                fontSize: "18px",
                textAlign:"center",
                color:"#44B8F3",
                fontStyle: "normal",
                fontWeight: 500,
                lineHeight: "28px"
              }}>
                {data.title}</Typography>
              <Paper
                  sx={{
                    display: "flex",
                    height: "220px",
                    width:"200px",
                    padding: "24px",
                    justifyContent: "center",
                    alignItems: "center",
                    gap: "10px",
                    borderRadius: "20px",
                    backgroundColor: bgColor ,
                  // alignSelf: "stretch",
                    overflowY:"auto",
                    '&:: -webkit-scrollbar':{
                      width:'8px' ,
                      
                    },
                    '&::-webkit-scrollbar-track': {
                      background: "transparent",
                      borderRadius:'4px'
                    },
                    '&::-webkit-scrollbar-thumb': {
                      background: '#888',
                      borderRadius:'4px',
                      minHeight:'10px',
                    },
                  }}
              >
               {/* {promptDisplay[index]?.prompt} */}
              <Typography sx={{paddingTop:"27px"}}>               
                {/* Lorem ipsum dolor sit amet consectetur adipisicing elit. Ut nemo aperiam sapiente dolor, nam optio unde quia, praesentium enim consectetur quis iure. Officiis asperiores, facere a voluptates aut fugit, laudantium consectetur dolorem suscipit voluptatibus inventore iure ab, quas quis voluptatum! */}
                {promptDisplay[index]?.prompt}      
                </Typography>
             </Paper>
              </Box>
              ))}
              
              
            </Box>
          </Box>

        </>
      )}
      {/* // :( */}
          <>
          <Box 
          sx={{
        // flex: 1,
        marginLeft:"20px",
        width: '100%',
        overflowY: 'auto',
        maxHeight: '100vh',
        '&:: -webkit-scrollbar':{
          width:'8px' ,
          
        },
        '&::-webkit-scrollbar-track': {
          background: "transparent",
          borderRadius:'4px'
        },
        '&::-webkit-scrollbar-thumb': {
          background: '#888',
          borderRadius:'4px',
          minHeight:'10px',
        },
        padding: '10px',
        //marginLeft: '360px',
        ...customStyles.chatContainer
      }}>
        <ChatMessage ref={chatMessageRef}
         executeSQLHandleButtonClick={executeSQLHandleButtonClick}
        chatLog={chatLog} 
        chatbotImage={chatbotImage} userImage={userImage} storedResponse={storedResponse} 
        showResponse={apiResponse} contentTableRef={contentTableRef} contentSumm={contentSumm}
        isLoading={isLoading}
        />
         
        <div ref={endOfMessagesRef} />
        
        {/* {showButton && (
          
            <Button variant="contained" color="primary" onClick={handleShowResponse} sx={{ mr: 2 }}>
              {showResponse ? "Hide SQL" : "Show SQL"}
            </Button>
        )}
        {showExecuteButton && (
          <Button variant="contained" color="primary" onClick={executeSQLHandleButtonClick}>
            Execute SQL
          </Button>
        )}
        {showProivdeSummary && (
          <Button variant="contained" color="primary" onClick={generateSummaryHandleButtonClick}>
            Provide Summary
          </Button>
        )} */}
        {/* {isLoading && <HashLoader color={themeColor} size={30} aria-label="Loading Spinner" data-testid="loader" />} */}
        {isLoading && <LoadingSpinner isLoading={isLoading}></LoadingSpinner>}
        {/* {responseReceived && <Feedback />} */}
        {successMessage && <Alert color="success"><span>{successMessage}</span></Alert>}
        <br></br>
        <br></br>
        <br className='scrollable'></br>

      </Box>

      <Box sx={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        width: isCollapsed ? '90%' : '80%',
        // width: '90%',
        // maxWidth: '100%',
        flexDirection: 'column',
        position: 'fixed',
        bottom: '50px',
        // transform: 'translateX(50%)'
      }}>

        {/* <Grid container spacing={2} sx={{ width: '100%', maxWidth: '100%', position: 'fixed', bottom: '50px', left: '57%', transform: 'translateX(-50%)', width: '70%', marginLeft: '8px', flexDirection: 'column' }}>
          


          <Grid item xs={12} sm={6} md={4} > */}
            <form onSubmit={handleSubmit} style={{ width: isCollapsed ? '90%' : '70%', }}>
              <TextField
                //disabled
                fullWidth
                id='inputChatTxtFld'
                placeholder="What can I help you with..."
                sx={{
                  input:{
                    // color: textboxColor,
                    backgroundColor: textboxColor,
                    '&:-webkit-autofill': {
                      boxShadow: `0 0 0 100px ${textboxColor} inset !important`,
                      WebkitTextFillColor: textColor
                    }
                  },
                 
                  '& .MuiOutlinedInput-root': {
                    '& fieldset': {
                      borderColor: textColor,
                    },
                    '&:hover fieldset': {
                      borderColor: textColor,
                    },
                    '&.Mui-focused fieldset': {
                      borderColor: textColor,
                    },
                  },
                //   "& .MuiInputBase-input.Mui-disabled": {
                //     WebkitTextFillColor: themeColor,
                // },
                }}
                //value={inputField}
                value={(inputField === null || inputField === undefined || inputField === '') ? input : inputField}
                onChange={(e) => {
                  //alert('onchange')
                  setInputChatField(e.target.value);
                  setInput(e.target.value);
                  handleInputFocusOrChange(); // Ensure elements disappear when typing
                }}
                onFocus={handleInputFocusOrChange}
                inputProps={{ maxLength: 400 }}
                InputProps={{
                  sx: {
                    '& .MuiInputBase-input': {
                      padding: '17px',
                      fontSize: '1.2rem',
                      color: textColor,
                      // borderColor:textColor
                      // borderColor: 
                    },
                    '& .MuiInputAdornment-root button': {
                      color: textboxColor,
                     
                    },
                    // '& .MuiOutlinedInput-root': {
                    //   '& fieldset': {
                    //     borderColor: textboxColor,
                       
                    //   },
                    // }
                  },
                  startAdornment: (
                    <InputAdornment position="start">
                      <IconButton onClick={handleMicClick} disabled={isLoading}>
                        <MicIcon style={{color:isLoading ? 
                        'grey' :  iconColor}} />
                        </IconButton>
                    </InputAdornment>
                  ),
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton type="submit" disabled={isLoading}
                      
                      >
                        <FaTelegramPlane className="h-6 w-6" style={{color:isLoading ? 
                        'grey' :  iconColor}}  />
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
              />
            </form>

          {/* </Grid>
        </Grid> */}
      </Box>
      {/* <ChartModal
        visible={isModalVisible}
        onClose={handleModalClose}
       // handleDataFromModal={handleDataFromModal}
        chartData={dataRecords || []}  // Ensure you pass valid JSON data
      /> */}
      <Snackbar
      open={ openSummModal}
      autoHideDuration={6000}
      onClose={()=> setOpenSummModal(false)}
      anchorOrigin={{vertical:'top',horizontal:'center'}}
      >
      <Alert 
      onClose={()=> setOpenSummModal(false)} 
      severity="warning" 
      variant="filled"
      sx={{
          fontSize:'1.2rem',
          padding:'16px 24px',
          minWidth:'300px'
      }}
      >
      Unable to generate a summary because the record count exceeds 100
      </Alert>
      </Snackbar>
      <Modal open={openPopup}
        onClose={(event, reason) => {
          if (reason !== "backdropClick") {
            setOpenPopup(false);
          }
        }}
        closeAfterTransition
        BackdropComponent={Backdrop}
        BackdropProps={{
          timeout: 500,
        }}>
        <Fade in={openPopup}>
          <Box sx={{
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            width: 300,
            bgcolor: 'background.paper',
            borderRadius: '8px',
            boxShadow: 24,
            p: 4,
            textAlign: 'center',
          }}>
            <Typography variant="h6" sx={{  fontFamily:'"OpenSans",sans-serif',
              fontSize: '1.1 rem', 
              fontWeight: 400 }}>Session Ended</Typography>
            <Typography sx={{ mt: 2, fontFamily:'"OpenSans",sans-serif',
              fontSize: '1.1 rem', 
              fontWeight: 400 }}>Your session has ended due to 180 minutes of inactivity.</Typography>
            {/* New Chat Button */}
            <Button
              variant="contained"
              color="primary"
              onClick={sessionEndHandleBtnClick}
              sx={{ mt: 2 }}
            >
              Login
            </Button>
          </Box>
        </Fade>
      </Modal>
          </>    
              {/* // )} */}
       <Box>
        {isOpen && (
           <TableExpandModal
            open={isOpen}
            onClose={() => setIsOpen(false)}
            title={"Data Table"}
          >
            <Box sx={{ height: "100vh", overflow: "hidden", p: 1 }}>
              {currentModalDataRef.current.rows.length > 0 && 
               currentModalDataRef.current.columns.length > 0 ? (
               <div style={{height:'100%'}}>
                  <StyledDataGrid
                    key={modalKey} // Forces re-render when modalKey changes
                    rows={currentModalDataRef.current.rows}
                    columns={currentModalDataRef.current.columns}
                    disableRowSelectionOnClick
                      pagination
                      initialState={{
                        pagination: { paginationModel: { pageSize: 15 } },
                      }}
                      pageSizeOptions={[10, 15, 20]}
                    //autoHeight
                  />
                </div>
              ) : (
                <Typography>No Data Available</Typography>
              )}
            </Box>
          </TableExpandModal>
        )}
      </Box>

</Box>
    
  );
};

export default UserChat;
