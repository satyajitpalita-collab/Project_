import React, { useState,useEffect } from 'react';
import Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';
import exporting from 'highcharts/modules/exporting';
import exportData from 'highcharts/modules/export-data'; // Optional for CSV export
import offlineExporting from 'highcharts/modules/offline-exporting'; // Import offline exporting module
import variablePie from 'highcharts/modules/variable-pie'; // Import the variable-pie module
import highchartsMore from 'highcharts/highcharts-more';
import VisibilityIcon from "@mui/icons-material/Visibility";
import {useAtom} from 'jotai'; 
import { chartAtom, graphAtom } from '../helpers';
import {
  IconButton,
  Box,
  MenuItem,
  Select,
  InputLabel,
  FormControl,
  Typography,
  ListItemText,
} from '@mui/material';
import Checkbox from '@mui/material/Checkbox';

// Initialize exporting and additional chart modules
exporting(Highcharts);
exportData(Highcharts); // Optional, for CSV export
offlineExporting(Highcharts); // Initialize offline exporting
variablePie(Highcharts); // Initialize variable-pie module
highchartsMore(Highcharts);

const ChartModal = ({ visible, onClose, chartData = [],id }) => {
  const [chartType, setChartType] = useState('line');
  const [chosenBarCondition,setChosenBarCondition]=useState('Aggregate');
  const [xAxisKey, setXAxisKey] = useState('');
  const [yAxisKey, setYAxisKey] = useState([]);
  const [chardata,setChartData]=useAtom(chartAtom);
  const [scrollToBottom, setScrollToBottom] = useState(false);
  const [graphData,setGraphData]=useAtom(graphAtom);
  const [open,setOpen]=useState(false);
  const [key,setkey]=useState(0);

 
  // Ensure chartData is an array, otherwise fallback to an empty array
  const validData = Array.isArray(chartData) && chartData.length > 0 ? chartData : [];

  const fieldTypes = validData.length > 0 ? Object.fromEntries(
    Object.entries(validData[0]).map(([key, value]) => [key, typeof value])
  ) : {};

  // Extract keys for x-axis and y-axis options, default to empty array if no valid data
  const dataKeys = validData.length > 0 ? Object.keys(validData[0]) : [];

  //Group data by selected xaxis and sum yaxis
  const aggregatedData = validData.reduce((acc, item) => {
    const xValue = item[xAxisKey];
    if(!acc[xValue]) {
      acc[xValue] = { [xAxisKey]: xValue };
      yAxisKey.forEach(key => {
        acc[xValue][key] = 0;
      });
    }
    yAxisKey.forEach(key => {
      const val = parseFloat(String(item[key] ?? '').replace(/[^0-9.]/g, ''));
    // const val=parseFloat(String(item[key].startsWith('$')) ? item[key].replace(/[^0-9.]/g, ''):item[key]);
      if(!isNaN(val)) {
        acc[xValue][key] += val;
      }
    });
    return acc;
  }, {});

  const groupedData = Object.values(aggregatedData);

  // Limit data to top 10 items
  const limitedData = groupedData.length > 0 ? groupedData.slice(0, 10) : [];

  const limitedDataBar = validData;
  
  // let seriesKey = Object.keys(limitedDataBar[0]).find(key => key !== xAxisKey && key !== yAxisKey[0]);
  let seriesKey = Object.keys(limitedDataBar[0]).filter(key => key !== xAxisKey && key !== yAxisKey[0]);
  let seriesKeyYear=seriesKey.find(key => key.toLowerCase().includes('year') && validData[0][key]?.toString().length===4);
  seriesKey=seriesKeyYear ? seriesKeyYear : seriesKey[0]?seriesKey[0]:'';
  
  let uniqueX = [...new Set(limitedDataBar.map(ele => ele[xAxisKey]))].slice(0,10).sort(
      seriesKey === 'year' || seriesKey.includes('year') ? (a, b) => a - b : (a, b) => a?.toString().localeCompare(b?.toString())
  );
  let uniqueSeries = [...new Set(limitedDataBar.map(ele => ele[seriesKey]))].slice(0,10).sort(
      seriesKey === 'year' || seriesKey.includes('year') ? (a, b) => a - b : (a, b) => a?.toString().localeCompare(b?.toString())
  );
  // Handle cases where there's no valid data
  const hasSufficientData = validData.length > 0 && xAxisKey && yAxisKey.length > 0;

  // Define chart options based on the selected chart type
  const getChartOptions = () => {
    const titleText = `Showing only top ${chartType==='bar' ? '10':limitedData.length} data points`;
   
    switch (chartType) {
      case 'pie':
        return {
          chart: { type: 'variablepie' },
          title: { text: titleText },
          credits: { enabled: false },
          series: [{
            minPointSize: 10,
            innerSize: '20%',
            zMin: 0,
            name: 'data',
            data: limitedData.map(item => ({
              name: item[xAxisKey],
              y: item[yAxisKey],
              z: item[yAxisKey] // Assuming yAxisKey value defines radius
            }))
          }]
        };

      case 'bubble':
        return {
          chart: { type: 'bubble', plotBorderWidth: 1, zoomType: 'xy' },
          title: { text: titleText },
          credits: { enabled: false },
          xAxis: { title: { text: xAxisKey } },
          yAxis: { title: { text: yAxisKey } },
          series: [{
            data: limitedData.map(item => [
              item[xAxisKey],
              item[yAxisKey],
              Math.sqrt(item[yAxisKey]) // Assuming yAxisKey value defines bubble size
            ])
          }]
        };

      case 'line':
      // case 'area':
      //case 'bar':
        return {
          chart: { type: 'line' },
          title: { text: titleText },
          credits: { enabled: false },
          xAxis: { categories: limitedData.map(item => item[xAxisKey])},
          // yAxis: {labels: obj},
          series: yAxisKey.map(key => ({
            name: key,
            data: limitedData.map(item => item[key]),
          }))
        };
      case 'area':
        return {
          chart: { type: 'area' },
          title: { text: titleText },
          credits: { enabled: false },
          xAxis: { categories: limitedData.map(item => item[xAxisKey]) },
          series: yAxisKey.map(key => ({
            name: key,
            data: limitedData.map(item => item[key]),
          }))
        };  
      case 'bar':
        if(chosenBarCondition==='Year'){
          return {
            chart: { type: 'bar' },
            title: { text: titleText },
            plotOptions: {
              bar: {
                  borderRadius: '50%',
                  dataLabels: {
                      enabled: true
                  },
                  groupPadding: 0.1
              }
           },
            credits: { enabled: false },
            xAxis: {categories: uniqueX} ,
            series: uniqueSeries.map((val) => ({
              name: val,
              data: uniqueX.map(x => {
                  const item = limitedDataBar.find(ele => ele[xAxisKey] === x && ele[seriesKey] === val);
                  return item ? parseFloat(String(item[yAxisKey[0]] ?? '').replace(/[^0-9.]/g, '')) : null;
              })
            }))
          };
        }
        else{
        return {
          chart: { type: chartType },
          title: { text: titleText },
          credits: { enabled: false },
          xAxis: { categories: limitedData.map(item => item[xAxisKey]) },
          series: yAxisKey.map(key => ({
            name: key,
            data: limitedData.map(item => item[key]),
          }))
        };
      }
      case 'column':
        return {
          chart: { type: chartType },
          title: { text: titleText },
          credits: { enabled: false },
          xAxis: { categories: limitedData.map(item => item[xAxisKey]) },
          series: yAxisKey.map(key => ({
            name: key,
            data: limitedData.map(item => item[key]),
          }))
        };
      case 'stackedBar':
        return {
          chart: { type: 'bar' },
          title: { text: titleText },
          xAxis: { categories: limitedData.map(item => item[xAxisKey]) },
          yAxis: {
            min: 0,
            title: { text: '' },
          },
          legend: { reversed: true },
          plotOptions: {
            series: { stacking: 'normal', dataLabels: { enabled: true } }
          },
          series: yAxisKey.map(key => ({
            name: key,
            data: limitedData.map(item => item[key]),
          }))
        };

      default:
        return {
          chart: { type: 'line' },
          title: { text: titleText },
          credits: { enabled: false },
          xAxis: { categories: limitedData.map(item => item[xAxisKey]) },
          series: [{
            name: yAxisKey,
            data: limitedData.map(item => item[yAxisKey])
          }]
        };
    }
  };

  useEffect(() => {
    console.log('line 155',id,xAxisKey,yAxisKey,graphData)
    if(graphData ){
      //const id = chartData?.id;
      const found = graphData.find((ele) => ele?.id === id);
      console.log('line 159',found);
      if(found){
        setXAxisKey(found.xAxis);
        setYAxisKey(found.yAxis)
        setChartType(found.cType);
        setChosenBarCondition(found.barCondition)
      }
    }
  },[graphData, chartData])

  useEffect(() => {
    if(xAxisKey && yAxisKey && chartType && chartData){
      //const id = chartData?.id;
      const found = graphData.find((ele) => ele?.id === id);
      console.log('line 171',found);
      //this is used if user updates the x or y axis at a later stage in chat
      if(found){
        setGraphData((prev) => prev.map((ele) => {
          if(ele?.id == id){
            return {...ele, xAxis: xAxisKey, yAxis: yAxisKey,cType:chartType,barCondition:chosenBarCondition}
          }
          return ele
        }))
      }
      else{
        const newObj = {
          id: id,
          xAxis: xAxisKey,
          yAxis: yAxisKey,
          cType:chartType,
          barCondition:chosenBarCondition
        }
        setGraphData((prev) => [...prev, newObj])
      }
    }
  },[xAxisKey, yAxisKey,chartType, chartData])

  useEffect(() => {
    if (scrollToBottom) {
      document.querySelector('.scrollable').scrollIntoView();
      setScrollToBottom(false);
    }
  }, [scrollToBottom]);
 

 

  useEffect(()=>{
    if(hasSufficientData){
      setkey((prev)=>prev+1);
      setChartData(getChartOptions());
      
    }
      },[hasSufficientData,xAxisKey,yAxisKey,chartType])
    

  const options = getChartOptions();

  return (
    // <Modal
    //   open={visible}
    //   onClose={onClose}
    //   aria-labelledby="chart-modal-title"
    //   aria-describedby="chart-modal-description"
    // >
      <Box
        sx={{
          width:"1065px"
          // position: 'absolute',
          // top: '50%',
          // left: '50%',
          // transform: 'translate(-50%, -50%)',
          // width: '50%',
          // bgcolor: 'background.paper',
          // boxShadow: 24,
          // p: 4,
          // borderRadius: '8px',
          // fontFamily:'"OpenSans",sans-serif',
          // fontSize: '1.1 rem', 
          // fontWeight: 400,
        }}
      >
        <Typography id="chart-modal-title" variant="h6" component="h2">
          Select Chart Options
        </Typography>

        <FormControl fullWidth sx={{ marginTop: 2 }}>
          <InputLabel>Chart Type</InputLabel>
          <Select
            value={chartType}
            onChange={(e) => {
              setChartType(e.target.value);
              if(e.target.value==='bar'){
                setYAxisKey([]);
              }
            }
            }
            label="Chart Type"
          >
            <MenuItem value="pie">Variable Radius Pie</MenuItem>
            <MenuItem value="bubble">Bubble Chart</MenuItem>
            <MenuItem value="line">Line Chart</MenuItem>
            <MenuItem value="stackedBar">Stacked Bar Chart</MenuItem>
            <MenuItem value="area">Area Chart</MenuItem>
            <MenuItem value="bar">Basic Bar Chart</MenuItem>
            <MenuItem value="column">Basic Column Chart</MenuItem>
          </Select>
        </FormControl>

        {chartType==='bar' && dataKeys.find((key)=>key.toLowerCase().includes('year') && validData[0][key]?.toString().length===4)
         && (
          <FormControl fullWidth sx={{ marginTop: 2 }}>
          <InputLabel>Options</InputLabel>
          <Select
            value={chosenBarCondition}
            onChange={(e) => {
              setChosenBarCondition(e.target.value);
              setYAxisKey([]);
              }
            }
            label="Condition"
          >
            {/* {dataKeys.find((key)=>key.toLowerCase().includes('year')) && ( */}
            <MenuItem value="Year">Year Based</MenuItem>
            {/* )} */}
            <MenuItem value="Aggregate">Without Year</MenuItem>
            
          </Select>
        </FormControl>
        )}

        <FormControl fullWidth sx={{ marginTop: 2 }}>
          <InputLabel>X Axis</InputLabel>
          <Select
            value={xAxisKey}
            onChange={(e) => {
              setXAxisKey(e.target.value)
              
              
            }}
            label="X Axis"
          >
            {dataKeys.filter((key) => key !== yAxisKey)
            .map((key) => (
              <MenuItem key={key} value={key} >
                {key}
              </MenuItem>
            ))}
          </Select>
        </FormControl>

        <FormControl fullWidth sx={{ marginTop: 2 }}>
          <InputLabel>Y Axis</InputLabel>
          <Select
            multiple= {chartType!=='bar' || (chartType==='bar' && chosenBarCondition==='Aggregate') ? true:false }
            value={yAxisKey}
            onChange={(e) => {
             
              if(chartType==='bar' && chosenBarCondition==='Year'){
                setYAxisKey([e.target.value]);
              }
              else{
              setYAxisKey(e.target.value);
              }
            }}
            label="Y Axis"
            renderValue={(selected) => chartType!=='bar' || (chartType==='bar' && chosenBarCondition==='Aggregate') ?  selected.join(', '): selected[0]}
            open = {open}
          onOpen = {() => setOpen(true)}
          onClose = {() => setOpen(false)}
          MenuProps={{PaperProps: {
            onMouseLeave: () => {
              setOpen(false);
              if(xAxisKey){
                setScrollToBottom(true);
                }
            }
          }}}
          >
            {dataKeys.filter((key) => (fieldTypes[key] === 'number'  && 
             ((chartType=== 'bar' && chosenBarCondition==='Year')? (!key.toLowerCase().includes('year')&& !key.toLowerCase().includes('month')) : key)) || (fieldTypes[key]==='string' && 
             validData[0][key].includes('$')))
            .map((key) => {
              const isSelected = yAxisKey.includes(key);
              return (
                <MenuItem key={key} value={key} 
                sx={{ backgroundColor: isSelected ? '#d0d0d0': 'inherit', 
                '&.Mui-selected' : {backgroundColor: '#d0d0d0',}, 
                '&.Mui-selected:hover': {backgroundColor: '#bcbcbc',},
                }}>
                  {/* {key} */}
                {(chartType !== 'bar' || (chartType==='bar' && chosenBarCondition==='Aggregate')) && (
                <Checkbox checked={isSelected} />
                )}  
                <ListItemText primary={key} />
              </MenuItem>
              )
            }
            //   (

            //   <MenuItem key={key} value={key} 
            //     disabled={fieldTypes[key] === 'string' && fieldTypes[xAxisKey] === 'string'}>
            //     {key}
            //   </MenuItem>
            // )
            )}
          </Select>
        </FormControl>

        {hasSufficientData ? (
          <Box sx={{ marginTop: 4 }}>
            <Typography style={{color: '',
                  fontSize: "16px",
                  fontStyle: "normal",
                  fontWeight: 500,
                  lineHeight: "20px",
                  paddingBottom: "18px"
                }}>
                  Here is the Visualization.
                  </Typography>
       <Box sx={{ display: 'flex',height:"55px",borderRadius: "10px 10px 0px 0px", boxShadow: 1,flexDirection:'row', justifyContent: 'space-between', alignItems: 'center', bgcolor: '#666', px: 2, py: 1 }}>
                    <Typography color="white" fontSize={14} fontWeight={500}>Top 10 Data Point</Typography>
                    <Box >
                    <IconButton size="small" sx={{ color: 'white',mr:2 }} >
                    <VisibilityIcon fontSize="small" />
                    </IconButton>
                    {/* <IconButton size="small" sx={{ color: 'white' }} >
                    <ContentCopyIcon fontSize="small" />
                    </IconButton> */}
                    </Box>
                    </Box>

            <HighchartsReact highcharts={Highcharts} options={options}  key={key}/>
          </Box>
        ) : (
          <Typography sx={{ marginTop: 4 }} color="error">
            No sufficient data to display the chart. Please provide valid data and select valid axes.
          </Typography>
        )}

        {/* <Button
          onClick={()=>{
            setXAxisKey('');
            setYAxisKey([]);
            onClose()}}
          variant="contained"
          color="primary"
          sx={{ marginTop: 4 }}
          fullWidth
        >
          Close
        </Button> */}
      </Box>
    // </Modal>
  );
};

export default ChartModal;