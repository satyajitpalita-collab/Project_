import React from 'react';
import { useAtom } from 'jotai';
import { Box, Typography, Paper,Accordion, AccordionSummary, AccordionDetails, useTheme } from '@mui/material';
import { ExpandMore } from '@mui/icons-material';
import {chatHistoryAtom, myPromptDrawer,agentChatAtom, abortcontrollerRefAtom} from '../helpers/index.js';
import favorite from '../../src/assets/CustomButtons/FavoritePrompt.png';
import myprompt from '../../src/assets/CustomButtons/ChatHistory.png';
import './SuggestedPrompts.css';
import AccessTimeFilledIcon from '@mui/icons-material/AccessTimeFilled';
import AgentChatList from './agents/components/AgentChatList.jsx';


const PromptSection = ({ favoritesData, onPromptClick,isCollapsed }) => {
  const chatHistory=useAtom(agentChatAtom);
  const [myPrompt]=useAtom(myPromptDrawer);
  const [abortcontrollerRef,setAbortcontrollerRef]=useAtom(abortcontrollerRefAtom);
  const theme=useTheme();
  const bgColor=theme.palette.mode==='dark' ? '#1A3673':'#E3F4FD';
  const textColor=theme.palette.mode==='dark'? '#FFF':'#231E33';

// const accordionbgColor=theme.palette.mode==='dark' ? 'rgba(227, 244, 253, 0.25) !important':'#FFF';

  console.log('chat history',chatHistory);

  // if(!favoritesData || favoritesData.length === 0){
  //   return(
  //   <Typography sx={{fontSize: '1.3rem',fontWeight:'400'}}>No Favorites Data. Please add your Favorites</Typography>
  //   )
  // }

  // const groupedData=favoritesData.map((item)=>{
  //   return item;
  // })
  

  const groupedData=favoritesData.reduce((acc,item)=>{
    if(!acc[item.category]) acc[item.category]=[];
    acc[item.category].push(item);
    return acc;
  },{});
  return (
    <>
    {!isCollapsed ?(
    <Box>
      
       <Accordion sx={{border:"none",boxShadow:'none',backgroundColor:'background.paper',}}>
         <AccordionSummary expandIcon={!isCollapsed ? <ExpandMore/> : null}>
         
         <img src={favorite} alt="gcp" style={{width:30, }}/>&nbsp;
         <Typography sx={{fontSize: '1.2rem',fontWeight:'400',color:textColor,marginLeft:"12px"}}>Favorite Prompt </Typography>
        
         </AccordionSummary>
         
         <AccordionDetails>
         {(!favoritesData || favoritesData.length === 0)? (
        <Typography sx={{fontSize: '1.3rem',fontWeight:'400'}}>No Favorites Data. Please add your Favorites</Typography>
      ):(
         <div className="slim-scrollbar" 
         style={{
           maxHeight:"260px",
           overflowY:"scroll",
           }}>
           {Object.keys(groupedData).map((category,index)=>(
             <Accordion key={index} sx={{backgroundColor:'background.paper'}}>
               <AccordionSummary expandIcon={!isCollapsed ? <ExpandMore/> : null}>
<Typography sx={{fontSize: '1.1rem',fontWeight:'400',color:textColor}}>{category}</Typography>
               </AccordionSummary>
             <AccordionDetails>
             {groupedData[category].map((item)=>(
             <Box key={item.id} sx={{mb: 1}}>
               {/* <Box> */}
              <Paper
              key={item.id}
              elevation={3}
              sx={{
                p:2,
                cursor:"pointer",
                // '&:hover':{backgroundColor:'#f5f5f5'},
                textAlign:"left",
                fontSize: '1.1rem',
                backgroundColor:bgColor,
                fontWeight:'400',
                borderRadius:2,
                color:textColor
              }}
              
              onClick={()=>onPromptClick(item)}
              
              >
              {item.prompt}
              
              </Paper>
              {/* </Box> */}
             </Box>
             ))}
             </AccordionDetails>
             </Accordion>
           ))}
           </div>
      )}
         </AccordionDetails>
       </Accordion>
       

       <Accordion sx={{border:"none",boxShadow:'none'}} >
<AccordionSummary expandIcon={<ExpandMore/>}>

<img src={myprompt} alt="gcp" style={{width:30, }}/>
 <Typography sx={{fontSize: '1.2rem',fontWeight:'400',color:textColor,marginLeft:"12px"}}>My Prompts</Typography>
  </AccordionSummary>
  
  <AccordionDetails >
  {(myPrompt.length === 0)? (
        <Typography sx={{fontSize: '1.3rem',fontWeight:'400'}}>No My Prompts</Typography>
      ):(
        <div className="slim-scrollbar" style={{maxHeight:"200px",overflowY:"scroll"}}>
          {myPrompt.map((chat)=>(
            <Box key={chat.id} sx={{mb: 1}}>
            <Paper
            key={chat.id}
            elevation={3}
            sx={{
              p:2,
              cursor:"pointer",
              // '&:hover':{backgroundColor:'#f5f5f5'},
              textAlign:"left",
              fontSize: '1.1rem',
              backgroundColor:bgColor,
              fontWeight:'400',
              borderRadius:2,
              color:textColor
            }}
            
            onClick={()=>{
              console.log(chat);
              onPromptClick(chat?.prompt)
            }}
            
            >
               {chat.prompt}
              </Paper>
             </Box>
          ))}

</div>
)}
  </AccordionDetails>

        </Accordion>
   
      <Accordion sx={{border:"none",boxShadow:'none',flex:1, display:"flex", flexDirection:"column"}} >
<AccordionSummary expandIcon={<ExpandMore/>}>

<AccessTimeFilledIcon fontSize='large' sx={{color:'#f5ae64'}}/>
 <Typography sx={{fontSize: '1.2rem',fontWeight:'400',color:textColor,marginLeft:"12px"}}>Previous Conversation</Typography>
  </AccordionSummary>
  
            <AccordionDetails sx={{p:"0px"}}>
              {/* sx={{flex: 1, overflowY: "auto", height: "100%", padding: 0}} */}
              <AgentChatList
                data={chatHistory[0]}
                onPromptClick={()=>{
                   abortcontrollerRef.abort();
                  onPromptClick();
                }}
                bgColor={bgColor}
                textColor={textColor}
              />
            </AccordionDetails>

        </Accordion>
    </Box>
    ):(
      <Box sx={{display:"flex", flexDirection:"column", alignItems:"center",
      justifyContent:"center",marginTop:"20px",gap:4}}>
        <img src={favorite} alt="gcp" style={{width:35, }}/>
        <img src={myprompt} alt="gcp" style={{width:35, }}/>
        <AccessTimeFilledIcon fontSize='large' sx={{color:'#f5ae64'}}/>
      </Box>
    )}
    </>
  )
};

export default PromptSection;
