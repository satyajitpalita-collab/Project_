import { Security, SecureRoute, LoginCallback } from '@okta/okta-react';
import { toRelativeUrl } from '@okta/okta-auth-js';
import { useNavigate } from 'react-router-dom';
export default function CustomLoginCallback ()  {
 const navigate = useNavigate();
 const customErrorHandler = async (error) => {
   console.warn('Okta callback error:', error);
   // Common stale code errors
   const isStaleCode =
     error.name === 'OAuthError' &&
     (error.errorCode === 'invalid_request' ||
      error.message.includes('code has already been used') ||
      error.message.includes('expired'));
   if (isStaleCode) {
     // Clear URL params and restart login flow
     const cleanUrl = window.location.pathname; // e.g., /login/callback
     window.history.replaceState({}, '', cleanUrl);
     // Redirect to home or trigger fresh login
     navigate('/', { replace: true });
    
    } else {
     // Handle other errors
     navigate('/');
   }
 };
 return <LoginCallback errorComponent={(error) => { customErrorHandler(error); return null; }} />;
};