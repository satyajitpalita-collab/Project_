import React from "react";
import { Box, Stack, Typography } from '@mui/material';
import { red } from '@mui/material/colors';
import ErrorOutlineIcon from '@mui/icons-material/ErrorOutline';

function ErrorPage() {
    return (
        // <div style={{ padding: '2rem', textAlign: 'center', color: 'red' }}>
        //     <h2>Invalid Application Context</h2>
        //     <p>The provide app context is not valid. Please use a valid link.</p>
        // </div>
        <Box
      sx={{
        alignItems: 'center',
        display: 'flex',
        height: "100vh",
        overflow:"hidden"
        // ...sx,
      }}
    >
    <Stack
        alignItems={'center'}
        flexGrow={1}
        gap={2}
        justifyContent={'center'}
        padding={2}
      >
        <ErrorOutlineIcon fontSize={'large'} sx={{ color: red[600] }} />
        <Typography sx={{ color: red[600] }}>Unable to fetch user info.Please close the tab and reload</Typography>
      </Stack>
    </Box>
    )
}

export default ErrorPage;