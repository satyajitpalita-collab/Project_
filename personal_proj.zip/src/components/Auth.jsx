import { useLocation,Navigate, useNavigate } from "react-router-dom";
import React,{useEffect} from 'react';
import { useOktaAuth } from "@okta/okta-react";
import { useLogin } from "../helpers/hooks/useLogin";
//import { toRelativeUrl } from '@okta/okta-auth-js';

export const setToken = (token)=>{

    localStorage.setItem('temitope', token)
}

export const fetchToken = ()=>{

    return localStorage.getItem('temitope')
}

export function RequireToken({children}){

    let auth = fetchToken()
    let location = useLocation()

    if(!auth){

        return <Navigate to='/login' replace/>;
    }

    return children;
}

// export function RequireAuth({children}){
//     const {oktaAuth,authState}=useOktaAuth();
//     const [checkingSession,setCheckingSession]=useState('');

//     useEffect(()=>{
//         if(authState?.isAuthenticated) return;
//         const checkSessionAndLogin=async()=>{
//             try{
//                 const session= await oktaAuth.session.get();
//                 if(session.status==='ACTIVE' ){
//                     setCheckingSession('active');
//                    // await oktaAuth.signInWithRedirect();
//                 }
//                 else{
//                     setCheckingSession('inactive'); 
//                     oktaAuth.signInWithRedirect();
//                 }
//             }catch(error){
//                 console.error('error',error);
//                // await oktaAuth.signInWithRedirect();
//             }
//         };
//         checkSessionAndLogin();
//     },[oktaAuth,authState])

//     useEffect(()=>{
//        if(authState?.isAuthenticated){
//            setCheckingSession(false);
//        }
//        else if(authState?.isAuthenticated=== false){
//            oktaAuth.signInWithRedirect({prompt:'none'});
//        }
// },[authState,oktaAuth]);

// if(!authState?.isAuthenticated){
//     return <div>Authenticating....</div>
// }
// return children;
// }

export function RequireAuth({children}){
    const {oktaAuth,authState}=useOktaAuth();
    const {handleLogin}=useLogin()
    let auth = localStorage.getItem("okta-token-storage") && localStorage.getItem("okta-cache-storage");

    useEffect(()=>{ 
        if(authState && !authState.isAuthenticated){
            
            // const originalUri = toRelativeUrl(window.location.href, window.location.origin);
            // oktaAuth.setOriginalUri(originalUri);
            oktaAuth.tokenManager.clear();
            oktaAuth.signInWithRedirect({ originalUri: window.location.origin + '/' });
            
        }
    },[authState,oktaAuth]);
 

    if(!authState || !authState?.isAuthenticated) return <div>Loading...
        If you are not automatically redirected please <a style={{color:'blue',cursor:'pointer'}} onClick={()=>{
           oktaAuth.signInWithRedirect({ originalUri: window.location.origin + '/' });}}>
                Click here</a>
    </div>

    if(!auth){ 
        handleLogin() 
        return <Navigate to='/' replace/>;
    }
  
    return children;
}