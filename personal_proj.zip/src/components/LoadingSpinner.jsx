import React from 'react';
import { PulseLoader } from "react-spinners";

const LoadingSpinner = ({ isLoading, loadingText, children }) => {
  if (isLoading) {
    return (
      <div style={{ display: 'flex', textAlign: 'left', marginTop: '0px', alignItems: 'center'  }}>
        <PulseLoader color="#1a3673" size={8} />
        {/* <img src="/spinner.gif" alt="Processing..." style={{ width: '80px', height: '60px' }} />
        <p style={{ marginLeft : '10px', 
                    fontFamily: 'Roboto', 
                    fontSize: '14.5px', 
                    fontWeight: '700', 
                    color: '#ADD8E6'}} 
        > 
          {loadingText || 'Processing' } 
        </p> */}
        
      </div>
    );
  }

  return children;
};

export default LoadingSpinner;
