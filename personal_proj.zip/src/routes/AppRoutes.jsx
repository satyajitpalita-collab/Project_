
import React, { useEffect } from 'react';
import { Routes,Route, useLocation, useNavigate } from "react-router-dom"
import Login from '../pages/Login';
import { RequireToken,RequireAuth, PublicRoute, PrivateRoute } from '../components/Auth';
import Disclaimer from '../pages/Disclaimer';
import ChatPage from '../pages/ChatPage';
import HomePage from '../pages/HomePage';
import ErrorPage from '../components/ErrorPage';
import PromptSearch from '../components/PromptSearch';
import {Security,LoginCallback} from '@okta/okta-react';
import {OktaAuth,toRelativeUrl} from '@okta/okta-auth-js';
// import config from '../oktaConfig';
import {config} from '../oktaConfig';
import CocDisclaimer from '../pages/CocDisclaimer';
import { useAppUrl } from '../helpers/hooks/hooks';
import Logout from '../pages/Logout';
import IndexAgentChat from '../components/agents/IndexAgentChat';
import ChatMessageMapper from '../components/agents/components/ChatMessageMapper';
import CustomLoginCallback from '../components/CustomLoginCallback';



const oktaAuth = (config.oktaConfig && config.oktaConfig.issuer) ? new OktaAuth(config.oktaConfig):null ;
//const authCode=config.sso.authCode;

const AppRoutes=()=> {
  const location = useLocation();
  const navigate = useNavigate();
  const {AUTH_MODE}=useAppUrl();
  
// console.log('form approutes',authCode);
 console.log('dummy commit', AUTH_MODE);
// console.log('URL',window.REACT_APP_API_BASE_URL);

  const restoreOriginalUri=async(_oktaAuth,originalUri)=>{
    console.log("entered the redtoring func")
    const toOriginalUri = toRelativeUrl(
      originalUri || '/',
      window.location.origin
    );
 
    // Replace with current URL
    navigate(toOriginalUri, { replace: true });
   // originalUri=window.location.origin +'/disclaimer'
   // window.history.replaceState(null,'',toRelativeUrl(originalUri || '/',window.location.origin))
  }
  
  useEffect(() => {
    setZoomLevel();
  const params = new URLSearchParams(location.search);
    const app = params.get('app');
    if(app){
      if(app === 'IntelliQ' || app === 'MedRFP'){
        sessionStorage.setItem('Application', app);
        const cleanPath = location.pathname;
        window.history.replaceState({}, '', cleanPath);
      } else {
        navigate('/error');
      }
      
    }
}, [location, navigate]);
 
 
  return (
    
    //  <Router>
     <div>
       {AUTH_MODE === "sso" ? (
      <Security oktaAuth={oktaAuth} restoreOriginalUri={restoreOriginalUri}>
      <Routes>
        <Route path="/login/callback" element={<CustomLoginCallback/>}/>
        {/* <Route path="/login/callback" element={<LoginCallback/>}/> */}
        {/* <Route path="/login/callback?*" element={<Disclaimer/>}/> */}
      
        <Route path="/" element={<RequireAuth><Disclaimer/></RequireAuth>} />
        {/* <Route path="/home" element={<RequireAuth><HomePage /></RequireAuth>} /> */}
          <Route path="/logout" element={<Logout/>}/>
          {/* <Route path="/chat" element={<RequireAuth><ChatPage /></RequireAuth>} /> */}
        <Route path="/chat" element={<RequireAuth><IndexAgentChat /></RequireAuth>} />
        <Route path="/promptlibrary" element={<RequireAuth><PromptSearch /></RequireAuth>} />
        <Route path="/error" element={<ErrorPage />} />
        <Route path="*" element={<RequireAuth><Disclaimer/></RequireAuth>} />
      </Routes>
      </Security>
      ):(
        <Routes>
         <Route path="/" element={<HomePage />} />
         <Route path="/logout" element={<Logout/>}/>
         <Route path="/login" element={<Login />} />
         <Route path="/disclaimer" element={<RequireToken><CocDisclaimer/></RequireToken>} />
          {/* <Route path="/chat" element={<RequireToken><ChatPage /></RequireToken>} /> */}
          <Route path="/chat" element={<RequireToken><IndexAgentChat /></RequireToken>} />
         <Route path="/promptlibrary" element={<RequireToken><PromptSearch /></RequireToken>} />
         {/* <Route path="/error" element={<ErrorPage />} /> */}
      </Routes>
      )}
      </div>
    

     
      //  </Router>
    

    // <div>
    //   {/* <Navbar /> */}
    //   <Routes>
    //     <Route path="/" element={<Login />} />
    //     <Route path="/disclaimer" element={<Disclaimer></Disclaimer>} />
    //     {/* <Route path="/home" element={<RequireToken><Home /></RequireToken>} /> */}
    //     <Route path="/home" element={<RequireToken><HomePage /></RequireToken>} />
    //     <Route path="/chat" element={<RequireToken><ChatPage /></RequireToken>} />
    //     <Route path="/promptlibrary" element={<RequireToken><PromptSearch /></RequireToken>} />
    //     <Route path="/error" element={<ErrorPage />} />
    //   </Routes>
    //   </div>
    
  );
}

function setZoomLevel() {
  document.body.style.zoom = "75%";
}

export default AppRoutes;