import { Backdrop, CircularProgress } from "@mui/material";
import { useAtom } from "jotai";
import { loadingAtom } from "./helpers";

export default function Spinner(){
    const [loading]=useAtom(loadingAtom);
    console.log('from spinner',loading);

    return (
        <>
      <Backdrop
      sx={{
        color: '#fff',
        zIndex: (theme) => theme.zIndex.modal + 1,
        display: 'flex',
        justifyContent: 'center',
      }}
      open={loading}
    >
      <div style={{ display: 'flex', alignItems: 'center', flexDirection: 'column' }}>
        <CircularProgress />
        <div>Loading....</div>
      </div>
    </Backdrop>
   
    </>
    )
}