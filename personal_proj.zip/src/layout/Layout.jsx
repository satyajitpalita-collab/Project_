import React,{useEffect,useState} from "react";
import { AppBar, Menu,Avatar,MenuItem,Toolbar, CssBaseline, Typography, Box , useMediaQuery,ListItemIcon } from "@mui/material";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import Logout from "@mui/icons-material/Logout";
import Tooltip from '@mui/material/Tooltip';
import IconButton from '@mui/material/IconButton';
import { useNavigate } from "react-router";
import logo from '../../src/images/logo.png';
import { useLocation } from "react-router-dom";
import { useAtom } from "jotai";
import { titleAtom } from "../helpers";
import {OktaAuth} from '@okta/okta-auth-js';
import {config} from "../oktaConfig";
import { useAppUrl } from "../helpers/hooks/hooks";
import { useLogout } from "../helpers/hooks/useLogout";

//const oktaAuth = new OktaAuth(config.oktaConfig);
const oktaAuth = (config.oktaConfig && config.oktaConfig.issuer) ? new OktaAuth(config.oktaConfig):null;
const Layout=({children, handleResetClick,
    // logo,
    themeColor = "#1a3673",
    //title = "IntellIQ",
    customStyles = {},
    
})=>{
    const isMobile = useMediaQuery("(max-width:950px)");
    const navigate = useNavigate();
    const location =useLocation();
    const {logout}= useLogout()
    const showLogout=location.pathname !== "/disclaimer" && location.pathname !== "/";
    const [title,setTitle] = useAtom(titleAtom);
    const name=localStorage.getItem("fullName");
    const [anchorEl,setAnchorEl]=useState(null);
    const open=Boolean(anchorEl);
    const {APP_NAME} = useAppUrl();
    
    //const API_DEV_URL=process.env.REACT_APP_UAT_URL;
    
    //const token=localStorage.getItem('token');
    console.log(location.pathname);

    useEffect(()=>{
    
      //  if(location.pathname === "/chat"){
        if(APP_NAME === 'intelliq'){
          if( location.pathname !== "/"){
          setTitle('Cost of Care IQ');
          }
          else{
            setTitle('IntelliQ');
          }
          //console.log('iq',title);
        } else if(APP_NAME === 'pmintel'){
         setTitle('Program Intelligence Query');
         //console.log('PI',title);
        }
        
      //}
    },[APP_NAME])

    const handleMenuOpen=(event)=>{
      setAnchorEl(event.currentTarget);
    }

    const handleMenuClose=()=>{
      setAnchorEl(null);
    }
    
    
      const handleLogout=async()=>{
        //logout();
        // isAuthenticated=false;
      //   const response= await axios.post(`${API_DEV_URL}/logout`,{},{
      //     headers:{
      //       Authorization:`Bearer ${token}`
      //     }
      // });
        logout()
        navigate("/logout")
        //console.log("logout button is clicked");
      }

      
      const theme = createTheme({
        palette: {
          primary: {
            main: themeColor,
          },
        },
      });
 return (
     <>
     <ThemeProvider theme={theme}>
     <Box sx={{ display: "flex", flexDirection: 'column', overflow: 'hidden', ...customStyles.container }}>
      <CssBaseline />
        <AppBar position="fixed" sx={{
          zIndex: 1201,
          backgroundColor: themeColor,
          boxShadow: "-1px -4px 14px #000",
          height: '64px',
        }}>
          <Toolbar sx={{ justifyContent: isMobile ? "space-between" : "flex-start" }}>
            {logo && <img src={logo} alt="Logo" style={{ width: 120, ...customStyles.logo }} />}
            <Typography variant="h6" sx={{
              flexGrow: 1,
              textAlign: "center",
              marginLeft:"10%",
              fontWeight: "bold",
              fontSize: isMobile ? "1rem" : "1.5rem",
              //  marginLeft: '-80px', ...customStyles.title
            }}>
              {title}
            </Typography>
            {/* <Box sx={{ display: 'flex', justifyContent:"space-between",padding:2}}>
            <Tooltip title="Guide" placement="left"
            sx={{marginRight:'40px'}} 
              componentsProps={{
                tooltip: {
                  sx: {
                    bgcolor: '#f5f5f9',
                    color: 'rgba(0, 0, 0, 0.87)',
                    fontSize:'16px',
                    marginRight:'40px'
                  },
                },
              }}
              >
              <IconButton sx={{color: 'white'}} >
                <InfoIcon fontSize="medium" onClick={userGuide} />
                </IconButton>
                </Tooltip>
                {showLogout && (
                <Tooltip
                  placement="left"
                  title="Logout"
                  
                  componentsProps={{
                    tooltip: {
                      sx: {
                        bgcolor: '#f5f5f9',
                        color: 'rgba(0, 0, 0, 0.87)',
                        fontSize:'16px'
                      },
                    },
                  }}
        >
              
                <IconButton sx={{color: 'white'}} onClick={handleLogout}>
                <PowerSettingsNewIcon fontSize="medium"/>
                </IconButton>
                
                </Tooltip>
                )}
            </Box> */}
            <Box sx={{ display: 'flex', gap: 2, justifyContent: 'center', marginRight: 2 }}>
            {/* <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
              <Tooltip title="New Chat" placement="left-start"
                sx={{marginRight:"40px", position: 'absolute', right: '30px'}}
              componentsProps={{
                tooltip: {
                  sx: {
                    bgcolor: '#f5f5f9',
                    color: 'rgba(0, 0, 0, 0.87)',
                    fontSize:'16px',
                    marginRight:'40px',
                    position: 'absolute',
                     right: '30px'
                  },
                },
              }}
              >
                <IconButton sx={{color: 'white'}} >
                <RestoreIcon fontSize="large"  onClick={handleResetClick}/>
                </IconButton>
                </Tooltip>
               
              </Box> */}

              
              {/* <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
              <Tooltip title="Guide" placement="left-start"
                sx={{marginRight:"40px", position: 'absolute', right: '30px'}}
              componentsProps={{
                tooltip: {
                  sx: {
                    bgcolor: '#f5f5f9',
                    color: 'rgba(0, 0, 0, 0.87)',
                    fontSize:'16px',
                    marginRight:'40px',
                    position: 'absolute',
                     right: '30px'
                  },
                },
              }}
              >
                <IconButton sx={{color: 'white'}} >
                <InfoIcon fontSize="large" onClick={userGuide} />
                </IconButton>
                </Tooltip>
               
              </Box> */}
              
<Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
              <Typography sx={{fontSize: "16px",
fontStyle: "normal",
fontWeight: 500,
lineHeight: "20px",
marginTop:"20px"
}}>
  {name} 
  </Typography>
</Box>
              
              {showLogout && (
              <Box sx={{ display: 'flex', justifyContent:'flex-end', alignItems: 'center',padding:'10px', position: 'relative !important' }}>
                {/* <Tooltip
                  placement="left"
                  title="Account"
                  
                  componentsProps={{
                    tooltip: {
                      sx: {
                        bgcolor: '#f5f5f9',
                        color: 'rgba(0, 0, 0, 0.87)',
                        fontSize:'16px'
                      },
                    },
                  }}
        > */}
          {/* <IconButton sx={{color: 'white'}} onClick={handleLogout}>
                <PowerSettingsNewIcon fontSize="large"/>
                </IconButton> */}
              
                <IconButton sx={{color: 'white'}} onClick={handleMenuOpen} size="small"
                // onClick={handleLogout}
                >
                  <Avatar sx={{width:32,height:32}}/>
                
                </IconButton>
                
                {/* </Tooltip> */}
                <Menu
                anchorEl={anchorEl}
                open={Boolean(anchorEl)}
                onClose={handleMenuClose}
                onClick={handleMenuClose}
                slotProps={{
                  paper: {
                    elevation: 0,
                    //marginRight:'20px !important',
                    sx: {
                      overflow: 'visible',
                      position: 'absolute !important',
                      left: '91% !important',
                      filter: 'drop-shadow(0px 2px 8px rgba(0,0,0,0.32))',
                      mt: 1.5,
                      width: '150px',
                      // marginLeft:'530px',
                      '& .MuiAvatar-root': {
                        // width: 32,
                        height: 32,
                        // ml: -2.5,
                        // mr: 1,
                      },
                      '&::before': {
                        content: '""',
                        display: 'block',
                        position: 'absolute',
                        top: 0,
                        // right: 14,
                        // width: 10,
                        height: 10,
                        bgcolor: 'background.paper',
                        //transform: 'translateY(-50%) rotate(45deg)',
                        zIndex: 0,
                      },
                    },
                  },
                }}
                // PopperProps={{
                //   modifiers:[
                //     {
                //       name:'offset',
                //       options:{
                //         offset:[10,20],
                //       }
                //     },
                //     {
                //       name:'preventOverflow',
                //       options:{
                //         padding: 8,
                //       }
                //     }
                //   ]
                // }}
               // transformOrigin={{horizontal:'right',vertical:'top'}}
                //anchorOrigin={{horizontal:'right',vertical:'bottom'}}
                >
                  <MenuItem sx={{fontSize:'16px',display:"flex",justifyContent:"flex-start"}} onClick={handleLogout}>
                  <ListItemIcon >
            <Logout fontSize="small" />
          </ListItemIcon>
          Logout
                  </MenuItem>
                </Menu>
                {/* <AccountCircleIcon/> */}
              </Box>
              )}
              
            </Box>
          </Toolbar>
        </AppBar>
        <container sx={{}}>{children}</container>
        </Box>
        </ThemeProvider>
     </>
 )
}

export default Layout;
