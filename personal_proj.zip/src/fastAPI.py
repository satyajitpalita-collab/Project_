from fastapi import FastAPI
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
import logging
import pandas as pd
from typing import Any

app = FastAPI()

# Configure logging
logging.basicConfig(
    level=logging.INFO,  # Set log level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
    format="%(asctime)s - %(levelname)s - %(message)s",  # Log format
)

# Define allowed origins
origins = [
    "http://localhost:8000",  # React App
    "http://127.0.0.1:8000",  # Alternate localhost
]

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Origins that are allowed to make requests
    allow_credentials=True,  # Allow cookies or authorization headers
    allow_methods=["*"],  # Allow all HTTP methods
    allow_headers=["*"],  # Allow all HTTP headers
)

class InputData(BaseModel):
    text: str

@app.post("/echo/")
async def echo(input_data: InputData):
    # Log the incoming request
    logging.info(f"Received request with data: {input_data}")
    #return {"message": "SELECT emps.title, emps.employee_ID, mgrs.employee_ID AS MANAGER_ID,  mgrs.title AS 'MANAGER TITLE' FROM employees AS emps LEFT OUTER JOIN employees AS mgrs ON emps.manager_ID = mgrs.employee_ID ORDER BY mgrs.employee_ID NULLS FIRST, emps.employee_ID;","isSQL" : "true"}
    return {"message": "WITH RECURSIVE managers (indent, employee_ID, manager_ID, employee_title) AS (  SELECT '' AS indent, employee_ID, manager_ID, title AS employee_title FROM employees WHERE title = 'President' UNION ALL SELECT indent || '--- ', employees.employee_ID,employees.manager_ID,employees.title FROM employees JOIN managers ON employees.manager_ID = managers.employee_ID) SELECT indent || employee_title AS Title employee_ID, manager_ID FROM managers;","isSQL" : "true"}


@app.put("/echo/")
async def echo(input_data: InputData):
    # Log the incoming request
    logging.info(f"Received request with put data: {input_data}")
    #return {"message": "SELECT emps.title, emps.employee_ID, mgrs.employee_ID AS MANAGER_ID,  mgrs.title AS 'MANAGER TITLE' FROM employees AS emps LEFT OUTER JOIN employees AS mgrs ON emps.manager_ID = mgrs.employee_ID ORDER BY mgrs.employee_ID NULLS FIRST, emps.employee_ID;","isSQL" : "true"}
    return {"message": "WITH RECURSIVE managers (indent, employee_ID, manager_ID, employee_title) AS (  SELECT '' AS indent, employee_ID, manager_ID, title AS employee_title FROM employees WHERE title = 'President' UNION ALL SELECT indent || '--- ', employees.employee_ID,employees.manager_ID,employees.title FROM employees JOIN managers ON employees.manager_ID = managers.employee_ID) SELECT indent || employee_title AS Title employee_ID, manager_ID FROM managers;","isSQL" : "true"}


# Pydantic model for accepting SQL query from the user
class QueryRequest(BaseModel):
    sql_query: str
    
# Sample SQL-like DataFrame (simulated result of an SQL query)
def execute_sql(query: str) -> pd.DataFrame:
    # Simulated data for the sake of this example
    data = {
        'id': [1, 2, 3, 4],
        'name': ['Alice', 'Bob', 'Charlie', 'David'],
        'age': [25, 30, 35, 40]
    }
    df = pd.DataFrame(data)

    # Here, you can simulate querying the DataFrame based on the SQL query string.
    # For example, a simple query "SELECT * FROM table" can return all rows.
    if query.lower() == "select * from table":
        return df

    return pd.DataFrame()  # Return an empty DataFrame if query doesn't match

# POST endpoint to execute SQL query and return results as JSON
@app.post("/executeSQL/")
async def execute_sql_api(request: QueryRequest) -> Any:
    query = request.sql_query
    logging.info(f"Received request with data: {query}")
    df = execute_sql(query)
    
    # Convert DataFrame to JSON and return
    return df.to_dict(orient="records")

@app.get("/health/")
async def health_string():
    # Log the incoming request
    logging.info(f"Health request")
    return {"message"}
    
# To run the app, save this to a file (e.g., main.py) and use:
# uvicorn main:app --reload

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
    
    
    