
const runtimeEnv = typeof window !== "undefined" && window.ENV;

const source = runtimeEnv ? window.ENV : process.env;

const AUTH_MODE=source.REACT_APP_AUTH_MODE

const checkSSO= AUTH_MODE==="sso"
const oktaConfig = checkSSO ? {
  // oidc: {
    clientId: source.REACT_APP_OKTA_CLIENT_ID,
    issuer: source.REACT_APP_OKTA_ISSUER_ID,
    redirectUri: window.location.origin + "/login/callback",
    scopes: ["openid", "profile", "email", "groups", "filteredgroups"],
    pkce: true,
  // },
}:null;

export const config={
  oktaConfig:oktaConfig
}
// export default oktaConfig;
