import { useTheme } from "@emotion/react";

export const INACTIVITY_TIME = 3 * 60 * 60 * 1000;


export  const titleSql="The question can be answered using the semantic model since we have membership data in fact_rsttd_fncl_mbrshp table which can be joined with.";

export const API_STATUS= {
    NONE:"NONE",
    PENDING:"PENDING",
    SUCCESS:"SUCCESS",
    ERROR:"ERROR"
}

export const pmTable={
    "results": [
        {
            "MBU_CLASS": "Commercial Individual Blue",
            "STATE": "CA",
            "MEMBERSHIP": 268358.09677409
        },
        {
            "MBU_CLASS": "Commercial Individual Blue",
            "STATE": "CO",
            "MEMBERSHIP": 105745.32258057
        },
        {
            "MBU_CLASS": "Commercial Individual Blue",
            "STATE": "CT",
            "MEMBERSHIP": 86841.74193552
        },
        {
            "MBU_CLASS": "Commercial Individual Blue",
            "STATE": "GA",
            "MEMBERSHIP": 143001.67741934
        },
        {
            "MBU_CLASS": "Commercial Individual Blue",
            "STATE": "IN",
            "MEMBERSHIP": 109512.87096741
        },
        {
            "MBU_CLASS": "Commercial Individual Blue",
            "STATE": "KY",
            "MEMBERSHIP": 48639.77419341
        },
        {
            "MBU_CLASS": "Commercial Individual Blue",
            "STATE": "ME",
            "MEMBERSHIP": 32604.8709677
        },
        {
            "MBU_CLASS": "Commercial Individual Blue",
            "STATE": "MO",
            "MEMBERSHIP": 60214.64516122
        },
        {
            "MBU_CLASS": "Commercial Individual Blue",
            "STATE": "NH",
            "MEMBERSHIP": 44757.38709668
        },
        {
            "MBU_CLASS": "Commercial Individual Blue",
            "STATE": "NV",
            "MEMBERSHIP": 22438.87096777
        },
        {
            "MBU_CLASS": "Commercial Individual Blue",
            "STATE": "NY",
            "MEMBERSHIP": 24480.83870966
        },
        {
            "MBU_CLASS": "Commercial Individual Blue",
            "STATE": "OH",
            "MEMBERSHIP": 105315.54838677
        },
        {
            "MBU_CLASS": "Commercial Individual Blue",
            "STATE": "VA",
            "MEMBERSHIP": 138764.74193541
        },
        {
            "MBU_CLASS": "Commercial Individual Blue",
            "STATE": "WI",
            "MEMBERSHIP": 83900.90322567
        },
        {
            "MBU_CLASS": "Commercial Individual Green",
            "STATE": "FL",
            "MEMBERSHIP": 8421.41935476
        },
        {
            "MBU_CLASS": "Commercial Individual Green",
            "STATE": "MD",
            "MEMBERSHIP": 1137.58064516
        },
        {
            "MBU_CLASS": "Commercial Individual Green",
            "STATE": "TX",
            "MEMBERSHIP": 37778.64516105
        },
        {
            "MBU_CLASS": "Large Group",
            "STATE": "CA",
            "MEMBERSHIP": 715175.29032504
        },
        {
            "MBU_CLASS": "Large Group",
            "STATE": "CO",
            "MEMBERSHIP": 40216.48387096
        },
        {
            "MBU_CLASS": "Large Group",
            "STATE": "CT",
            "MEMBERSHIP": 38378.70967752
        },
        {
            "MBU_CLASS": "Large Group",
            "STATE": "GA",
            "MEMBERSHIP": 85753.32258138
        },
        {
            "MBU_CLASS": "Large Group",
            "STATE": "IN",
            "MEMBERSHIP": 83162.29032246
        },
        {
            "MBU_CLASS": "Large Group",
            "STATE": "KY",
            "MEMBERSHIP": 146916.0645165
        },
        {
            "MBU_CLASS": "Large Group",
            "STATE": "ME",
            "MEMBERSHIP": 11851.4516129
        },
        {
            "MBU_CLASS": "Large Group",
            "STATE": "MO",
            "MEMBERSHIP": 52648.25806479
        },
        {
            "MBU_CLASS": "Large Group",
            "STATE": "NH",
            "MEMBERSHIP": 41689.38709686
        },
        {
            "MBU_CLASS": "Large Group",
            "STATE": "NV",
            "MEMBERSHIP": 35150.6129031
        },
        {
            "MBU_CLASS": "Large Group",
            "STATE": "NY",
            "MEMBERSHIP": 164649.32258055
        },
        {
            "MBU_CLASS": "Large Group",
            "STATE": "OH",
            "MEMBERSHIP": 184868.61290302
        },
        {
            "MBU_CLASS": "Large Group",
            "STATE": "VA",
            "MEMBERSHIP": 120844.77419397
        },
        {
            "MBU_CLASS": "Large Group",
            "STATE": "WI",
            "MEMBERSHIP": 65336.80645172
        },
        {
            "MBU_CLASS": "National",
            "STATE": "CA",
            "MEMBERSHIP": 27298.83870962
        },
        {
            "MBU_CLASS": "National",
            "STATE": "CT",
            "MEMBERSHIP": 2815.5806451
        },
        {
            "MBU_CLASS": "National",
            "STATE": "GA",
            "MEMBERSHIP": 42653.87096811
        },
        {
            "MBU_CLASS": "National",
            "STATE": "IN",
            "MEMBERSHIP": 4740.06451614
        },
        {
            "MBU_CLASS": "National",
            "STATE": "KY",
            "MEMBERSHIP": 189.8064516
        },
        {
            "MBU_CLASS": "National",
            "STATE": "MO",
            "MEMBERSHIP": 982.45161292
        },
        {
            "MBU_CLASS": "National",
            "STATE": "NH",
            "MEMBERSHIP": 1242.32258065
        },
        {
            "MBU_CLASS": "National",
            "STATE": "NY",
            "MEMBERSHIP": 8608.93548377
        },
        {
            "MBU_CLASS": "National",
            "STATE": "OH",
            "MEMBERSHIP": 31109.99999992
        },
        {
            "MBU_CLASS": "National",
            "STATE": "VA",
            "MEMBERSHIP": 1875.93548387
        },
        {
            "MBU_CLASS": "National",
            "STATE": "WI",
            "MEMBERSHIP": 9.0
        },
        {
            "MBU_CLASS": "Small Group",
            "STATE": "CA",
            "MEMBERSHIP": 573988.3548388
        },
        {
            "MBU_CLASS": "Small Group",
            "STATE": "CO",
            "MEMBERSHIP": 53847.99999992
        },
        {
            "MBU_CLASS": "Small Group",
            "STATE": "CT",
            "MEMBERSHIP": 47896.48387098
        },
        {
            "MBU_CLASS": "Small Group",
            "STATE": "GA",
            "MEMBERSHIP": 53254.35483893
        },
        {
            "MBU_CLASS": "Small Group",
            "STATE": "IN",
            "MEMBERSHIP": 77117.38709665
        },
        {
            "MBU_CLASS": "Small Group",
            "STATE": "KY",
            "MEMBERSHIP": 74221.80645151
        },
        {
            "MBU_CLASS": "Small Group",
            "STATE": "ME",
            "MEMBERSHIP": 21314.93548385
        },
        {
            "MBU_CLASS": "Small Group",
            "STATE": "MO",
            "MEMBERSHIP": 72412.32258056
        },
        {
            "MBU_CLASS": "Small Group",
            "STATE": "NH",
            "MEMBERSHIP": 42379.7096774
        },
        {
            "MBU_CLASS": "Small Group",
            "STATE": "NV",
            "MEMBERSHIP": 23658.12903229
        },
        {
            "MBU_CLASS": "Small Group",
            "STATE": "NY",
            "MEMBERSHIP": 33834.16129037
        },
        {
            "MBU_CLASS": "Small Group",
            "STATE": "OH",
            "MEMBERSHIP": 131672.29032243
        },
        {
            "MBU_CLASS": "Small Group",
            "STATE": "VA",
            "MEMBERSHIP": 127492.93548372
        },
        {
            "MBU_CLASS": "Small Group",
            "STATE": "WI",
            "MEMBERSHIP": 30287.90322581
        }
    ],
    "type": "data",
    "columns": [
        "MBU_CLASS",
        "STATE",
        "MEMBERSHIP"
    ]
}
export const spec={
    "spec": {
        "title": "Commercial Revenue by State and Month for 2025",
        "mark": "rect",
        "encoding": {
            "x": {
                "field": "INCRD_YEAR_MNTH_NBR",
                "type": "ordinal",
                "title": "Month",
                "sort": null,
                "axis": {
                    "labelSeparation": 25
                }
            },
            "y": {
                "field": "SRVCAREA_STATE_SHRT_DESC",
                "type": "nominal",
                "title": "State",
                "sort": null
            },
            "color": {
                "field": "TOTAL_REVENUE",
                "type": "quantitative",
                "title": "Total Revenue"
            }
        },
        "data": {
            "values": [
                {
                    "SRVCAREA_STATE_SHRT_DESC": "CA",
                    "INCRD_YEAR_MNTH_NBR": "202510",
                    "TOTAL_REVENUE": 1118667782.0574791,
                    "MIN_PERIOD": "202510",
                    "MAX_PERIOD": "202510",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "CA",
                    "INCRD_YEAR_MNTH_NBR": "202509",
                    "TOTAL_REVENUE": 1110484216.7851462,
                    "MIN_PERIOD": "202509",
                    "MAX_PERIOD": "202509",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "CA",
                    "INCRD_YEAR_MNTH_NBR": "202508",
                    "TOTAL_REVENUE": 1105545721.7072418,
                    "MIN_PERIOD": "202508",
                    "MAX_PERIOD": "202508",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "CA",
                    "INCRD_YEAR_MNTH_NBR": "202507",
                    "TOTAL_REVENUE": 1116541343.137609,
                    "MIN_PERIOD": "202507",
                    "MAX_PERIOD": "202507",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "CA",
                    "INCRD_YEAR_MNTH_NBR": "202506",
                    "TOTAL_REVENUE": 1121701311.941847,
                    "MIN_PERIOD": "202506",
                    "MAX_PERIOD": "202506",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "CA",
                    "INCRD_YEAR_MNTH_NBR": "202505",
                    "TOTAL_REVENUE": 1065779946.3511475,
                    "MIN_PERIOD": "202505",
                    "MAX_PERIOD": "202505",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "CA",
                    "INCRD_YEAR_MNTH_NBR": "202504",
                    "TOTAL_REVENUE": 1087485921.4921458,
                    "MIN_PERIOD": "202504",
                    "MAX_PERIOD": "202504",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "CA",
                    "INCRD_YEAR_MNTH_NBR": "202503",
                    "TOTAL_REVENUE": 1088337159.8072937,
                    "MIN_PERIOD": "202503",
                    "MAX_PERIOD": "202503",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "CA",
                    "INCRD_YEAR_MNTH_NBR": "202502",
                    "TOTAL_REVENUE": 1056179489.1820997,
                    "MIN_PERIOD": "202502",
                    "MAX_PERIOD": "202502",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "CA",
                    "INCRD_YEAR_MNTH_NBR": "202501",
                    "TOTAL_REVENUE": 1110442745.8739233,
                    "MIN_PERIOD": "202501",
                    "MAX_PERIOD": "202501",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "CO",
                    "INCRD_YEAR_MNTH_NBR": "202510",
                    "TOTAL_REVENUE": 118020716.93658286,
                    "MIN_PERIOD": "202510",
                    "MAX_PERIOD": "202510",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "CO",
                    "INCRD_YEAR_MNTH_NBR": "202509",
                    "TOTAL_REVENUE": 120029379.20480822,
                    "MIN_PERIOD": "202509",
                    "MAX_PERIOD": "202509",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "CO",
                    "INCRD_YEAR_MNTH_NBR": "202508",
                    "TOTAL_REVENUE": 119906281.8853309,
                    "MIN_PERIOD": "202508",
                    "MAX_PERIOD": "202508",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "CO",
                    "INCRD_YEAR_MNTH_NBR": "202507",
                    "TOTAL_REVENUE": 123397045.94899343,
                    "MIN_PERIOD": "202507",
                    "MAX_PERIOD": "202507",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "CO",
                    "INCRD_YEAR_MNTH_NBR": "202506",
                    "TOTAL_REVENUE": 110141767.44301426,
                    "MIN_PERIOD": "202506",
                    "MAX_PERIOD": "202506",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "CO",
                    "INCRD_YEAR_MNTH_NBR": "202505",
                    "TOTAL_REVENUE": 110536157.66375208,
                    "MIN_PERIOD": "202505",
                    "MAX_PERIOD": "202505",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "CO",
                    "INCRD_YEAR_MNTH_NBR": "202504",
                    "TOTAL_REVENUE": 121324161.6742812,
                    "MIN_PERIOD": "202504",
                    "MAX_PERIOD": "202504",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "CO",
                    "INCRD_YEAR_MNTH_NBR": "202503",
                    "TOTAL_REVENUE": 125351225.40393256,
                    "MIN_PERIOD": "202503",
                    "MAX_PERIOD": "202503",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "CO",
                    "INCRD_YEAR_MNTH_NBR": "202502",
                    "TOTAL_REVENUE": 115973198.71943519,
                    "MIN_PERIOD": "202502",
                    "MAX_PERIOD": "202502",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "CO",
                    "INCRD_YEAR_MNTH_NBR": "202501",
                    "TOTAL_REVENUE": 125890925.49140345,
                    "MIN_PERIOD": "202501",
                    "MAX_PERIOD": "202501",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "CT",
                    "INCRD_YEAR_MNTH_NBR": "202510",
                    "TOTAL_REVENUE": 164066763.8261916,
                    "MIN_PERIOD": "202510",
                    "MAX_PERIOD": "202510",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "CT",
                    "INCRD_YEAR_MNTH_NBR": "202509",
                    "TOTAL_REVENUE": 160273665.16749448,
                    "MIN_PERIOD": "202509",
                    "MAX_PERIOD": "202509",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "CT",
                    "INCRD_YEAR_MNTH_NBR": "202508",
                    "TOTAL_REVENUE": 155625789.26697186,
                    "MIN_PERIOD": "202508",
                    "MAX_PERIOD": "202508",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "CT",
                    "INCRD_YEAR_MNTH_NBR": "202507",
                    "TOTAL_REVENUE": 160714698.54261515,
                    "MIN_PERIOD": "202507",
                    "MAX_PERIOD": "202507",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "CT",
                    "INCRD_YEAR_MNTH_NBR": "202506",
                    "TOTAL_REVENUE": 142083230.40998375,
                    "MIN_PERIOD": "202506",
                    "MAX_PERIOD": "202506",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "CT",
                    "INCRD_YEAR_MNTH_NBR": "202505",
                    "TOTAL_REVENUE": 140535786.01070428,
                    "MIN_PERIOD": "202505",
                    "MAX_PERIOD": "202505",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "CT",
                    "INCRD_YEAR_MNTH_NBR": "202504",
                    "TOTAL_REVENUE": 155787558.3292536,
                    "MIN_PERIOD": "202504",
                    "MAX_PERIOD": "202504",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "CT",
                    "INCRD_YEAR_MNTH_NBR": "202503",
                    "TOTAL_REVENUE": 151647770.0322802,
                    "MIN_PERIOD": "202503",
                    "MAX_PERIOD": "202503",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "CT",
                    "INCRD_YEAR_MNTH_NBR": "202502",
                    "TOTAL_REVENUE": 151474089.21418458,
                    "MIN_PERIOD": "202502",
                    "MAX_PERIOD": "202502",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "CT",
                    "INCRD_YEAR_MNTH_NBR": "202501",
                    "TOTAL_REVENUE": 148126386.44649413,
                    "MIN_PERIOD": "202501",
                    "MAX_PERIOD": "202501",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "FL",
                    "INCRD_YEAR_MNTH_NBR": "202510",
                    "TOTAL_REVENUE": 4860579.042496137,
                    "MIN_PERIOD": "202510",
                    "MAX_PERIOD": "202510",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "FL",
                    "INCRD_YEAR_MNTH_NBR": "202509",
                    "TOTAL_REVENUE": 1823200.614600544,
                    "MIN_PERIOD": "202509",
                    "MAX_PERIOD": "202509",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "FL",
                    "INCRD_YEAR_MNTH_NBR": "202508",
                    "TOTAL_REVENUE": -3511026.710801248,
                    "MIN_PERIOD": "202508",
                    "MAX_PERIOD": "202508",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "FL",
                    "INCRD_YEAR_MNTH_NBR": "202507",
                    "TOTAL_REVENUE": 4352694.735600196,
                    "MIN_PERIOD": "202507",
                    "MAX_PERIOD": "202507",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "FL",
                    "INCRD_YEAR_MNTH_NBR": "202506",
                    "TOTAL_REVENUE": 4554527.290303962,
                    "MIN_PERIOD": "202506",
                    "MAX_PERIOD": "202506",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "FL",
                    "INCRD_YEAR_MNTH_NBR": "202505",
                    "TOTAL_REVENUE": 4757327.911300459,
                    "MIN_PERIOD": "202505",
                    "MAX_PERIOD": "202505",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "FL",
                    "INCRD_YEAR_MNTH_NBR": "202504",
                    "TOTAL_REVENUE": 4471907.07950208,
                    "MIN_PERIOD": "202504",
                    "MAX_PERIOD": "202504",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "FL",
                    "INCRD_YEAR_MNTH_NBR": "202503",
                    "TOTAL_REVENUE": 4395597.190901851,
                    "MIN_PERIOD": "202503",
                    "MAX_PERIOD": "202503",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "FL",
                    "INCRD_YEAR_MNTH_NBR": "202502",
                    "TOTAL_REVENUE": 4419961.904698702,
                    "MIN_PERIOD": "202502",
                    "MAX_PERIOD": "202502",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "FL",
                    "INCRD_YEAR_MNTH_NBR": "202501",
                    "TOTAL_REVENUE": 3688012.162901845,
                    "MIN_PERIOD": "202501",
                    "MAX_PERIOD": "202501",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "GA",
                    "INCRD_YEAR_MNTH_NBR": "202510",
                    "TOTAL_REVENUE": 205820805.56173134,
                    "MIN_PERIOD": "202510",
                    "MAX_PERIOD": "202510",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "GA",
                    "INCRD_YEAR_MNTH_NBR": "202509",
                    "TOTAL_REVENUE": 202419622.7350673,
                    "MIN_PERIOD": "202509",
                    "MAX_PERIOD": "202509",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "GA",
                    "INCRD_YEAR_MNTH_NBR": "202508",
                    "TOTAL_REVENUE": 207385912.56980634,
                    "MIN_PERIOD": "202508",
                    "MAX_PERIOD": "202508",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "GA",
                    "INCRD_YEAR_MNTH_NBR": "202507",
                    "TOTAL_REVENUE": 206003283.14470595,
                    "MIN_PERIOD": "202507",
                    "MAX_PERIOD": "202507",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "GA",
                    "INCRD_YEAR_MNTH_NBR": "202506",
                    "TOTAL_REVENUE": 185849570.66158676,
                    "MIN_PERIOD": "202506",
                    "MAX_PERIOD": "202506",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "GA",
                    "INCRD_YEAR_MNTH_NBR": "202505",
                    "TOTAL_REVENUE": 193273404.4354991,
                    "MIN_PERIOD": "202505",
                    "MAX_PERIOD": "202505",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "GA",
                    "INCRD_YEAR_MNTH_NBR": "202504",
                    "TOTAL_REVENUE": 215625266.80091017,
                    "MIN_PERIOD": "202504",
                    "MAX_PERIOD": "202504",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "GA",
                    "INCRD_YEAR_MNTH_NBR": "202503",
                    "TOTAL_REVENUE": 178890641.77297962,
                    "MIN_PERIOD": "202503",
                    "MAX_PERIOD": "202503",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "GA",
                    "INCRD_YEAR_MNTH_NBR": "202502",
                    "TOTAL_REVENUE": 204965950.732145,
                    "MIN_PERIOD": "202502",
                    "MAX_PERIOD": "202502",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "GA",
                    "INCRD_YEAR_MNTH_NBR": "202501",
                    "TOTAL_REVENUE": 203078018.60629454,
                    "MIN_PERIOD": "202501",
                    "MAX_PERIOD": "202501",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "IN",
                    "INCRD_YEAR_MNTH_NBR": "202510",
                    "TOTAL_REVENUE": 153654403.14529112,
                    "MIN_PERIOD": "202510",
                    "MAX_PERIOD": "202510",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "IN",
                    "INCRD_YEAR_MNTH_NBR": "202509",
                    "TOTAL_REVENUE": 164304993.37293127,
                    "MIN_PERIOD": "202509",
                    "MAX_PERIOD": "202509",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "IN",
                    "INCRD_YEAR_MNTH_NBR": "202508",
                    "TOTAL_REVENUE": 165309690.8656119,
                    "MIN_PERIOD": "202508",
                    "MAX_PERIOD": "202508",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "IN",
                    "INCRD_YEAR_MNTH_NBR": "202507",
                    "TOTAL_REVENUE": 167807419.86759713,
                    "MIN_PERIOD": "202507",
                    "MAX_PERIOD": "202507",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "IN",
                    "INCRD_YEAR_MNTH_NBR": "202506",
                    "TOTAL_REVENUE": 177674486.6737046,
                    "MIN_PERIOD": "202506",
                    "MAX_PERIOD": "202506",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "IN",
                    "INCRD_YEAR_MNTH_NBR": "202505",
                    "TOTAL_REVENUE": 178914203.48312566,
                    "MIN_PERIOD": "202505",
                    "MAX_PERIOD": "202505",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "IN",
                    "INCRD_YEAR_MNTH_NBR": "202504",
                    "TOTAL_REVENUE": 175950043.34873787,
                    "MIN_PERIOD": "202504",
                    "MAX_PERIOD": "202504",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "IN",
                    "INCRD_YEAR_MNTH_NBR": "202503",
                    "TOTAL_REVENUE": 142651444.25271538,
                    "MIN_PERIOD": "202503",
                    "MAX_PERIOD": "202503",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "IN",
                    "INCRD_YEAR_MNTH_NBR": "202502",
                    "TOTAL_REVENUE": 152006241.4650213,
                    "MIN_PERIOD": "202502",
                    "MAX_PERIOD": "202502",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "IN",
                    "INCRD_YEAR_MNTH_NBR": "202501",
                    "TOTAL_REVENUE": 160257378.97654194,
                    "MIN_PERIOD": "202501",
                    "MAX_PERIOD": "202501",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "KY",
                    "INCRD_YEAR_MNTH_NBR": "202510",
                    "TOTAL_REVENUE": 167642658.9062777,
                    "MIN_PERIOD": "202510",
                    "MAX_PERIOD": "202510",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "KY",
                    "INCRD_YEAR_MNTH_NBR": "202509",
                    "TOTAL_REVENUE": 174085363.5538483,
                    "MIN_PERIOD": "202509",
                    "MAX_PERIOD": "202509",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "KY",
                    "INCRD_YEAR_MNTH_NBR": "202508",
                    "TOTAL_REVENUE": 160893844.9403904,
                    "MIN_PERIOD": "202508",
                    "MAX_PERIOD": "202508",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "KY",
                    "INCRD_YEAR_MNTH_NBR": "202507",
                    "TOTAL_REVENUE": 164183248.55565664,
                    "MIN_PERIOD": "202507",
                    "MAX_PERIOD": "202507",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "KY",
                    "INCRD_YEAR_MNTH_NBR": "202506",
                    "TOTAL_REVENUE": 169220546.6936747,
                    "MIN_PERIOD": "202506",
                    "MAX_PERIOD": "202506",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "KY",
                    "INCRD_YEAR_MNTH_NBR": "202505",
                    "TOTAL_REVENUE": 159507779.68243995,
                    "MIN_PERIOD": "202505",
                    "MAX_PERIOD": "202505",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "KY",
                    "INCRD_YEAR_MNTH_NBR": "202504",
                    "TOTAL_REVENUE": 170059710.21221912,
                    "MIN_PERIOD": "202504",
                    "MAX_PERIOD": "202504",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "KY",
                    "INCRD_YEAR_MNTH_NBR": "202503",
                    "TOTAL_REVENUE": 169843273.37832242,
                    "MIN_PERIOD": "202503",
                    "MAX_PERIOD": "202503",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "KY",
                    "INCRD_YEAR_MNTH_NBR": "202502",
                    "TOTAL_REVENUE": 171221049.64242983,
                    "MIN_PERIOD": "202502",
                    "MAX_PERIOD": "202502",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "KY",
                    "INCRD_YEAR_MNTH_NBR": "202501",
                    "TOTAL_REVENUE": 166025215.42665017,
                    "MIN_PERIOD": "202501",
                    "MAX_PERIOD": "202501",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "MD",
                    "INCRD_YEAR_MNTH_NBR": "202510",
                    "TOTAL_REVENUE": 631966.950699223,
                    "MIN_PERIOD": "202510",
                    "MAX_PERIOD": "202510",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "MD",
                    "INCRD_YEAR_MNTH_NBR": "202509",
                    "TOTAL_REVENUE": 191185.701300022,
                    "MIN_PERIOD": "202509",
                    "MAX_PERIOD": "202509",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "MD",
                    "INCRD_YEAR_MNTH_NBR": "202508",
                    "TOTAL_REVENUE": -138016.149099844,
                    "MIN_PERIOD": "202508",
                    "MAX_PERIOD": "202508",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "MD",
                    "INCRD_YEAR_MNTH_NBR": "202507",
                    "TOTAL_REVENUE": 365988.620499838,
                    "MIN_PERIOD": "202507",
                    "MAX_PERIOD": "202507",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "MD",
                    "INCRD_YEAR_MNTH_NBR": "202506",
                    "TOTAL_REVENUE": 379164.721400304,
                    "MIN_PERIOD": "202506",
                    "MAX_PERIOD": "202506",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "MD",
                    "INCRD_YEAR_MNTH_NBR": "202505",
                    "TOTAL_REVENUE": 392591.980800019,
                    "MIN_PERIOD": "202505",
                    "MAX_PERIOD": "202505",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "MD",
                    "INCRD_YEAR_MNTH_NBR": "202504",
                    "TOTAL_REVENUE": 342704.572100174,
                    "MIN_PERIOD": "202504",
                    "MAX_PERIOD": "202504",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "MD",
                    "INCRD_YEAR_MNTH_NBR": "202503",
                    "TOTAL_REVENUE": 287483.389200097,
                    "MIN_PERIOD": "202503",
                    "MAX_PERIOD": "202503",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "MD",
                    "INCRD_YEAR_MNTH_NBR": "202502",
                    "TOTAL_REVENUE": 275437.090499816,
                    "MIN_PERIOD": "202502",
                    "MAX_PERIOD": "202502",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "MD",
                    "INCRD_YEAR_MNTH_NBR": "202501",
                    "TOTAL_REVENUE": 166930.861099975,
                    "MIN_PERIOD": "202501",
                    "MAX_PERIOD": "202501",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "ME",
                    "INCRD_YEAR_MNTH_NBR": "202510",
                    "TOTAL_REVENUE": 47756249.368484676,
                    "MIN_PERIOD": "202510",
                    "MAX_PERIOD": "202510",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "ME",
                    "INCRD_YEAR_MNTH_NBR": "202509",
                    "TOTAL_REVENUE": 48632829.4664991,
                    "MIN_PERIOD": "202509",
                    "MAX_PERIOD": "202509",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "ME",
                    "INCRD_YEAR_MNTH_NBR": "202508",
                    "TOTAL_REVENUE": 46206867.38649132,
                    "MIN_PERIOD": "202508",
                    "MAX_PERIOD": "202508",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "ME",
                    "INCRD_YEAR_MNTH_NBR": "202507",
                    "TOTAL_REVENUE": 45294514.82190744,
                    "MIN_PERIOD": "202507",
                    "MAX_PERIOD": "202507",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "ME",
                    "INCRD_YEAR_MNTH_NBR": "202506",
                    "TOTAL_REVENUE": 44159900.711910516,
                    "MIN_PERIOD": "202506",
                    "MAX_PERIOD": "202506",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "ME",
                    "INCRD_YEAR_MNTH_NBR": "202505",
                    "TOTAL_REVENUE": 44834249.11198999,
                    "MIN_PERIOD": "202505",
                    "MAX_PERIOD": "202505",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "ME",
                    "INCRD_YEAR_MNTH_NBR": "202504",
                    "TOTAL_REVENUE": 44941020.70929699,
                    "MIN_PERIOD": "202504",
                    "MAX_PERIOD": "202504",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "ME",
                    "INCRD_YEAR_MNTH_NBR": "202503",
                    "TOTAL_REVENUE": 44803764.56880523,
                    "MIN_PERIOD": "202503",
                    "MAX_PERIOD": "202503",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "ME",
                    "INCRD_YEAR_MNTH_NBR": "202502",
                    "TOTAL_REVENUE": 45230005.39209106,
                    "MIN_PERIOD": "202502",
                    "MAX_PERIOD": "202502",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "ME",
                    "INCRD_YEAR_MNTH_NBR": "202501",
                    "TOTAL_REVENUE": 43679705.71841059,
                    "MIN_PERIOD": "202501",
                    "MAX_PERIOD": "202501",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "MO",
                    "INCRD_YEAR_MNTH_NBR": "202510",
                    "TOTAL_REVENUE": 102754360.64539663,
                    "MIN_PERIOD": "202510",
                    "MAX_PERIOD": "202510",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "MO",
                    "INCRD_YEAR_MNTH_NBR": "202509",
                    "TOTAL_REVENUE": 103021159.3960364,
                    "MIN_PERIOD": "202509",
                    "MAX_PERIOD": "202509",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "MO",
                    "INCRD_YEAR_MNTH_NBR": "202508",
                    "TOTAL_REVENUE": 101648156.90630002,
                    "MIN_PERIOD": "202508",
                    "MAX_PERIOD": "202508",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "MO",
                    "INCRD_YEAR_MNTH_NBR": "202507",
                    "TOTAL_REVENUE": 110323747.43074536,
                    "MIN_PERIOD": "202507",
                    "MAX_PERIOD": "202507",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "MO",
                    "INCRD_YEAR_MNTH_NBR": "202506",
                    "TOTAL_REVENUE": 115392316.24622303,
                    "MIN_PERIOD": "202506",
                    "MAX_PERIOD": "202506",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "MO",
                    "INCRD_YEAR_MNTH_NBR": "202505",
                    "TOTAL_REVENUE": 123534213.44408973,
                    "MIN_PERIOD": "202505",
                    "MAX_PERIOD": "202505",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "MO",
                    "INCRD_YEAR_MNTH_NBR": "202504",
                    "TOTAL_REVENUE": 120181797.05564594,
                    "MIN_PERIOD": "202504",
                    "MAX_PERIOD": "202504",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "MO",
                    "INCRD_YEAR_MNTH_NBR": "202503",
                    "TOTAL_REVENUE": 89358205.8062882,
                    "MIN_PERIOD": "202503",
                    "MAX_PERIOD": "202503",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "MO",
                    "INCRD_YEAR_MNTH_NBR": "202502",
                    "TOTAL_REVENUE": 98345381.55778395,
                    "MIN_PERIOD": "202502",
                    "MAX_PERIOD": "202502",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "MO",
                    "INCRD_YEAR_MNTH_NBR": "202501",
                    "TOTAL_REVENUE": 114639524.39480756,
                    "MIN_PERIOD": "202501",
                    "MAX_PERIOD": "202501",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "NH",
                    "INCRD_YEAR_MNTH_NBR": "202510",
                    "TOTAL_REVENUE": 85477139.5680859,
                    "MIN_PERIOD": "202510",
                    "MAX_PERIOD": "202510",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "NH",
                    "INCRD_YEAR_MNTH_NBR": "202509",
                    "TOTAL_REVENUE": 85161903.65271445,
                    "MIN_PERIOD": "202509",
                    "MAX_PERIOD": "202509",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "NH",
                    "INCRD_YEAR_MNTH_NBR": "202508",
                    "TOTAL_REVENUE": 82773602.70466946,
                    "MIN_PERIOD": "202508",
                    "MAX_PERIOD": "202508",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "NH",
                    "INCRD_YEAR_MNTH_NBR": "202507",
                    "TOTAL_REVENUE": 81447029.0198984,
                    "MIN_PERIOD": "202507",
                    "MAX_PERIOD": "202507",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "NH",
                    "INCRD_YEAR_MNTH_NBR": "202506",
                    "TOTAL_REVENUE": 79495616.23871194,
                    "MIN_PERIOD": "202506",
                    "MAX_PERIOD": "202506",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "NH",
                    "INCRD_YEAR_MNTH_NBR": "202505",
                    "TOTAL_REVENUE": 82195761.7279291,
                    "MIN_PERIOD": "202505",
                    "MAX_PERIOD": "202505",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "NH",
                    "INCRD_YEAR_MNTH_NBR": "202504",
                    "TOTAL_REVENUE": 82288458.51119247,
                    "MIN_PERIOD": "202504",
                    "MAX_PERIOD": "202504",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "NH",
                    "INCRD_YEAR_MNTH_NBR": "202503",
                    "TOTAL_REVENUE": 76153505.04620425,
                    "MIN_PERIOD": "202503",
                    "MAX_PERIOD": "202503",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "NH",
                    "INCRD_YEAR_MNTH_NBR": "202502",
                    "TOTAL_REVENUE": 77581350.51769792,
                    "MIN_PERIOD": "202502",
                    "MAX_PERIOD": "202502",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "NH",
                    "INCRD_YEAR_MNTH_NBR": "202501",
                    "TOTAL_REVENUE": 79081587.46867962,
                    "MIN_PERIOD": "202501",
                    "MAX_PERIOD": "202501",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "NV",
                    "INCRD_YEAR_MNTH_NBR": "202510",
                    "TOTAL_REVENUE": 47231451.96949717,
                    "MIN_PERIOD": "202510",
                    "MAX_PERIOD": "202510",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "NV",
                    "INCRD_YEAR_MNTH_NBR": "202509",
                    "TOTAL_REVENUE": 47263174.76520072,
                    "MIN_PERIOD": "202509",
                    "MAX_PERIOD": "202509",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "NV",
                    "INCRD_YEAR_MNTH_NBR": "202508",
                    "TOTAL_REVENUE": 47609213.81768476,
                    "MIN_PERIOD": "202508",
                    "MAX_PERIOD": "202508",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "NV",
                    "INCRD_YEAR_MNTH_NBR": "202507",
                    "TOTAL_REVENUE": 48741550.35499088,
                    "MIN_PERIOD": "202507",
                    "MAX_PERIOD": "202507",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "NV",
                    "INCRD_YEAR_MNTH_NBR": "202506",
                    "TOTAL_REVENUE": 47601231.58940385,
                    "MIN_PERIOD": "202506",
                    "MAX_PERIOD": "202506",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "NV",
                    "INCRD_YEAR_MNTH_NBR": "202505",
                    "TOTAL_REVENUE": 44757380.393106595,
                    "MIN_PERIOD": "202505",
                    "MAX_PERIOD": "202505",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "NV",
                    "INCRD_YEAR_MNTH_NBR": "202504",
                    "TOTAL_REVENUE": 45034746.54539409,
                    "MIN_PERIOD": "202504",
                    "MAX_PERIOD": "202504",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "NV",
                    "INCRD_YEAR_MNTH_NBR": "202503",
                    "TOTAL_REVENUE": 47602997.34440176,
                    "MIN_PERIOD": "202503",
                    "MAX_PERIOD": "202503",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "NV",
                    "INCRD_YEAR_MNTH_NBR": "202502",
                    "TOTAL_REVENUE": 46276855.88629763,
                    "MIN_PERIOD": "202502",
                    "MAX_PERIOD": "202502",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "NV",
                    "INCRD_YEAR_MNTH_NBR": "202501",
                    "TOTAL_REVENUE": 46887307.83711085,
                    "MIN_PERIOD": "202501",
                    "MAX_PERIOD": "202501",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "NY",
                    "INCRD_YEAR_MNTH_NBR": "202510",
                    "TOTAL_REVENUE": 209801074.79903653,
                    "MIN_PERIOD": "202510",
                    "MAX_PERIOD": "202510",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "NY",
                    "INCRD_YEAR_MNTH_NBR": "202509",
                    "TOTAL_REVENUE": 208912250.81558064,
                    "MIN_PERIOD": "202509",
                    "MAX_PERIOD": "202509",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "NY",
                    "INCRD_YEAR_MNTH_NBR": "202508",
                    "TOTAL_REVENUE": 205677032.9345932,
                    "MIN_PERIOD": "202508",
                    "MAX_PERIOD": "202508",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "NY",
                    "INCRD_YEAR_MNTH_NBR": "202507",
                    "TOTAL_REVENUE": 212603216.0388373,
                    "MIN_PERIOD": "202507",
                    "MAX_PERIOD": "202507",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "NY",
                    "INCRD_YEAR_MNTH_NBR": "202506",
                    "TOTAL_REVENUE": 200980539.45744446,
                    "MIN_PERIOD": "202506",
                    "MAX_PERIOD": "202506",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "NY",
                    "INCRD_YEAR_MNTH_NBR": "202505",
                    "TOTAL_REVENUE": 192064425.0543266,
                    "MIN_PERIOD": "202505",
                    "MAX_PERIOD": "202505",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "NY",
                    "INCRD_YEAR_MNTH_NBR": "202504",
                    "TOTAL_REVENUE": 206283771.93590096,
                    "MIN_PERIOD": "202504",
                    "MAX_PERIOD": "202504",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "NY",
                    "INCRD_YEAR_MNTH_NBR": "202503",
                    "TOTAL_REVENUE": 209590711.5655793,
                    "MIN_PERIOD": "202503",
                    "MAX_PERIOD": "202503",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "NY",
                    "INCRD_YEAR_MNTH_NBR": "202502",
                    "TOTAL_REVENUE": 203815074.83203426,
                    "MIN_PERIOD": "202502",
                    "MAX_PERIOD": "202502",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "NY",
                    "INCRD_YEAR_MNTH_NBR": "202501",
                    "TOTAL_REVENUE": 205027559.64598796,
                    "MIN_PERIOD": "202501",
                    "MAX_PERIOD": "202501",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "OH",
                    "INCRD_YEAR_MNTH_NBR": "202510",
                    "TOTAL_REVENUE": 264752256.70291424,
                    "MIN_PERIOD": "202510",
                    "MAX_PERIOD": "202510",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "OH",
                    "INCRD_YEAR_MNTH_NBR": "202509",
                    "TOTAL_REVENUE": 265416467.53205782,
                    "MIN_PERIOD": "202509",
                    "MAX_PERIOD": "202509",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "OH",
                    "INCRD_YEAR_MNTH_NBR": "202508",
                    "TOTAL_REVENUE": 268062741.7123306,
                    "MIN_PERIOD": "202508",
                    "MAX_PERIOD": "202508",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "OH",
                    "INCRD_YEAR_MNTH_NBR": "202507",
                    "TOTAL_REVENUE": 275583334.1449539,
                    "MIN_PERIOD": "202507",
                    "MAX_PERIOD": "202507",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "OH",
                    "INCRD_YEAR_MNTH_NBR": "202506",
                    "TOTAL_REVENUE": 262246062.70947596,
                    "MIN_PERIOD": "202506",
                    "MAX_PERIOD": "202506",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "OH",
                    "INCRD_YEAR_MNTH_NBR": "202505",
                    "TOTAL_REVENUE": 252255209.49898747,
                    "MIN_PERIOD": "202505",
                    "MAX_PERIOD": "202505",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "OH",
                    "INCRD_YEAR_MNTH_NBR": "202504",
                    "TOTAL_REVENUE": 273058559.34754497,
                    "MIN_PERIOD": "202504",
                    "MAX_PERIOD": "202504",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "OH",
                    "INCRD_YEAR_MNTH_NBR": "202503",
                    "TOTAL_REVENUE": 252470891.34788284,
                    "MIN_PERIOD": "202503",
                    "MAX_PERIOD": "202503",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "OH",
                    "INCRD_YEAR_MNTH_NBR": "202502",
                    "TOTAL_REVENUE": 258598227.1919104,
                    "MIN_PERIOD": "202502",
                    "MAX_PERIOD": "202502",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "OH",
                    "INCRD_YEAR_MNTH_NBR": "202501",
                    "TOTAL_REVENUE": 264021000.79577532,
                    "MIN_PERIOD": "202501",
                    "MAX_PERIOD": "202501",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "TX",
                    "INCRD_YEAR_MNTH_NBR": "202510",
                    "TOTAL_REVENUE": 18311011.125101496,
                    "MIN_PERIOD": "202510",
                    "MAX_PERIOD": "202510",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "TX",
                    "INCRD_YEAR_MNTH_NBR": "202509",
                    "TOTAL_REVENUE": 6858100.058709858,
                    "MIN_PERIOD": "202509",
                    "MAX_PERIOD": "202509",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "TX",
                    "INCRD_YEAR_MNTH_NBR": "202508",
                    "TOTAL_REVENUE": -6449759.019308803,
                    "MIN_PERIOD": "202508",
                    "MAX_PERIOD": "202508",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "TX",
                    "INCRD_YEAR_MNTH_NBR": "202507",
                    "TOTAL_REVENUE": 16868918.326690953,
                    "MIN_PERIOD": "202507",
                    "MAX_PERIOD": "202507",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "TX",
                    "INCRD_YEAR_MNTH_NBR": "202506",
                    "TOTAL_REVENUE": 17579279.21961172,
                    "MIN_PERIOD": "202506",
                    "MAX_PERIOD": "202506",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "TX",
                    "INCRD_YEAR_MNTH_NBR": "202505",
                    "TOTAL_REVENUE": 17498122.690699127,
                    "MIN_PERIOD": "202505",
                    "MAX_PERIOD": "202505",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "TX",
                    "INCRD_YEAR_MNTH_NBR": "202504",
                    "TOTAL_REVENUE": 16936339.21448781,
                    "MIN_PERIOD": "202504",
                    "MAX_PERIOD": "202504",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "TX",
                    "INCRD_YEAR_MNTH_NBR": "202503",
                    "TOTAL_REVENUE": 16438563.304688858,
                    "MIN_PERIOD": "202503",
                    "MAX_PERIOD": "202503",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "TX",
                    "INCRD_YEAR_MNTH_NBR": "202502",
                    "TOTAL_REVENUE": 16405032.298997376,
                    "MIN_PERIOD": "202502",
                    "MAX_PERIOD": "202502",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "TX",
                    "INCRD_YEAR_MNTH_NBR": "202501",
                    "TOTAL_REVENUE": 13262772.50529951,
                    "MIN_PERIOD": "202501",
                    "MAX_PERIOD": "202501",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "VA",
                    "INCRD_YEAR_MNTH_NBR": "202510",
                    "TOTAL_REVENUE": 244316009.06076187,
                    "MIN_PERIOD": "202510",
                    "MAX_PERIOD": "202510",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "VA",
                    "INCRD_YEAR_MNTH_NBR": "202509",
                    "TOTAL_REVENUE": 243084890.76688668,
                    "MIN_PERIOD": "202509",
                    "MAX_PERIOD": "202509",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "VA",
                    "INCRD_YEAR_MNTH_NBR": "202508",
                    "TOTAL_REVENUE": 242971381.95051682,
                    "MIN_PERIOD": "202508",
                    "MAX_PERIOD": "202508",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "VA",
                    "INCRD_YEAR_MNTH_NBR": "202507",
                    "TOTAL_REVENUE": 243958497.10095724,
                    "MIN_PERIOD": "202507",
                    "MAX_PERIOD": "202507",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "VA",
                    "INCRD_YEAR_MNTH_NBR": "202506",
                    "TOTAL_REVENUE": 245426045.22132695,
                    "MIN_PERIOD": "202506",
                    "MAX_PERIOD": "202506",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "VA",
                    "INCRD_YEAR_MNTH_NBR": "202505",
                    "TOTAL_REVENUE": 218106216.45036978,
                    "MIN_PERIOD": "202505",
                    "MAX_PERIOD": "202505",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "VA",
                    "INCRD_YEAR_MNTH_NBR": "202504",
                    "TOTAL_REVENUE": 244048425.4770232,
                    "MIN_PERIOD": "202504",
                    "MAX_PERIOD": "202504",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "VA",
                    "INCRD_YEAR_MNTH_NBR": "202503",
                    "TOTAL_REVENUE": 247463817.36678463,
                    "MIN_PERIOD": "202503",
                    "MAX_PERIOD": "202503",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "VA",
                    "INCRD_YEAR_MNTH_NBR": "202502",
                    "TOTAL_REVENUE": 240500664.31459302,
                    "MIN_PERIOD": "202502",
                    "MAX_PERIOD": "202502",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "VA",
                    "INCRD_YEAR_MNTH_NBR": "202501",
                    "TOTAL_REVENUE": 241422258.3445689,
                    "MIN_PERIOD": "202501",
                    "MAX_PERIOD": "202501",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "WI",
                    "INCRD_YEAR_MNTH_NBR": "202510",
                    "TOTAL_REVENUE": 117482518.37591337,
                    "MIN_PERIOD": "202510",
                    "MAX_PERIOD": "202510",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "WI",
                    "INCRD_YEAR_MNTH_NBR": "202509",
                    "TOTAL_REVENUE": 116040683.1881208,
                    "MIN_PERIOD": "202509",
                    "MAX_PERIOD": "202509",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "WI",
                    "INCRD_YEAR_MNTH_NBR": "202508",
                    "TOTAL_REVENUE": 120622417.4720225,
                    "MIN_PERIOD": "202508",
                    "MAX_PERIOD": "202508",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "WI",
                    "INCRD_YEAR_MNTH_NBR": "202507",
                    "TOTAL_REVENUE": 123239626.43761766,
                    "MIN_PERIOD": "202507",
                    "MAX_PERIOD": "202507",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "WI",
                    "INCRD_YEAR_MNTH_NBR": "202506",
                    "TOTAL_REVENUE": 116770179.72716606,
                    "MIN_PERIOD": "202506",
                    "MAX_PERIOD": "202506",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "WI",
                    "INCRD_YEAR_MNTH_NBR": "202505",
                    "TOTAL_REVENUE": 131484058.1840099,
                    "MIN_PERIOD": "202505",
                    "MAX_PERIOD": "202505",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "WI",
                    "INCRD_YEAR_MNTH_NBR": "202504",
                    "TOTAL_REVENUE": 120591856.62482905,
                    "MIN_PERIOD": "202504",
                    "MAX_PERIOD": "202504",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "WI",
                    "INCRD_YEAR_MNTH_NBR": "202503",
                    "TOTAL_REVENUE": 115949047.74310687,
                    "MIN_PERIOD": "202503",
                    "MAX_PERIOD": "202503",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "WI",
                    "INCRD_YEAR_MNTH_NBR": "202502",
                    "TOTAL_REVENUE": 111289281.2698083,
                    "MIN_PERIOD": "202502",
                    "MAX_PERIOD": "202502",
                    "PERIOD_COUNT": "1"
                },
                {
                    "SRVCAREA_STATE_SHRT_DESC": "WI",
                    "INCRD_YEAR_MNTH_NBR": "202501",
                    "TOTAL_REVENUE": 112498015.27460916,
                    "MIN_PERIOD": "202501",
                    "MAX_PERIOD": "202501",
                    "PERIOD_COUNT": "1"
                }
            ]
        }
    }
}