import axios from "axios";
import { useAppUrl } from "../helpers/hooks/hooks";
import { apiCall } from "../helpers/interceptors";


export const IQPIlogin = (payload,params) => {
    const {API_BASE_URL} =useAppUrl();
    const chatHeaders = {
        "Content-Type": "application/x-www-form-urlencoded"
      };
    
    return axios({
        method: "post",
        url: `${API_BASE_URL}${params}`,
        data: payload,
        headers: chatHeaders,
      });
  };

export const IQPIfetch = (token,params) => {
    const {API_BASE_URL} =useAppUrl();
    const chatHeaders = {
        "Authorization": `Bearer ${token}`
      };
    console.log('from IQPI',token)
    return axios({
      method: "get",
      url: `${API_BASE_URL}${params}`,
    //   data: payload,
      headers: chatHeaders,
    });
  };

export const IQPIpost = (payload,token,params) => {
    const {API_BASE_URL} =useAppUrl();
    const chatHeaders = {
        "Authorization": `Bearer ${token}`
      };
    console.log('from IQPI',token)
    return axios({
        method: "post",
        url: `${API_BASE_URL}${params}`,
        data: payload,
        headers: chatHeaders,
      });
  };

export const IQPIdelete = (id,token,params) => {
    const {API_BASE_URL} =useAppUrl();
    const chatHeaders = {
        "Authorization": `Bearer ${token}`
      };
    console.log('from IQPI',token)
    return axios({
        method: "delete",
        url: `${API_BASE_URL}${params}`,
        data: id,
        headers: chatHeaders,
      });
  };

export const IQPIput= (token,params,queryparams,payload)=>{
    const {API_BASE_URL} =useAppUrl();
    const chatHeaders = {
        'Content-Type': 'application/json',
        "Authorization": `Bearer ${token}`,
        "Disable-Loader": true
      };
    console.log('from IQPI',token)
    return axios({
        method: "put",
        url: `${API_BASE_URL}${params}`,
        data: payload,
        params: queryparams,
        headers: chatHeaders,
      });
};

export const IQPIsqlrun=(token,params,queryparams)=>{
    const {API_BASE_URL} =useAppUrl();
    const chatHeaders = {
        'Content-Type': 'application/json',
        "Authorization": `Bearer ${token}`,
        "Disable-Loader": true
      };
    console.log('from IQPI',token)
    return axios({
        method: "post",
        url: `${API_BASE_URL}${params}`,
        //data: payload,
        params: queryparams,
        headers: chatHeaders,
      });
};

export const IQPIsummary=(params,payload)=>{
    const {API_BASE_URL} =useAppUrl();
    const chatHeaders = {
        'Content-Type': 'application/json',
        "Disable-Loader": true
      };
    //console.log('from IQPI',token)
    return axios({
        method: "post",
        url: `${API_BASE_URL}${params}`,
        data: JSON.stringify(payload),
        //params: queryparams,
        headers: chatHeaders,
      });
};

export const AgentThread=()=>{
  const {API_BASE_URL} =useAppUrl();
  // try { 
   
    const chatHeaders = {
      'Content-Type': 'application/json',
    };
 // console.log('from IQPI',token)
  return axios({
    method: "get",
    url: `${API_BASE_URL}/create-thread/`,
  //   data: payload,
    headers: chatHeaders,
  });
    // const response = await  apiCall.get("/create-thread/")  
    // return response?.data; // This will become the `payload` of the fulfilled action
  // } catch (error) {
  //   throw Error('Error'); // This will become the `payload` of the rejected action
  // }
}
export const IQPIClearCache= (token,params,queryparams)=>{
  const {API_BASE_URL} =useAppUrl();
  const chatHeaders = {
      'Content-Type': 'application/json',
      "Authorization": `Bearer ${token}`,
      "Disable-Loader": true
    };
  console.log('from IQPI',token)
  return axios({
      method: "put",
      url: `${API_BASE_URL}${params}`,
     // data: payload,
      params: queryparams,
      headers: chatHeaders,
    });
};

export const getThreadFromThreadId=(threadId)=>{ 
  return apiCall.get(`/get-thread/${threadId}`)
}




  
